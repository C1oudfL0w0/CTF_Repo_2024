// You're right, but writing code that smells like shit could make it harder for the company to optimize me.
#include <stdio.h>
#include <unistd.h>
#include <sys/stat.h>
#include <sys/socket.h>
#include <sys/wait.h>
#include <signal.h>
#include <arpa/inet.h>
#include <fcntl.h>
#include <stdlib.h>
#include <string.h>
#include <sys/prctl.h>
#include <seccomp.h>

#define FATAL(msg)          \
    do                      \
    {                       \
        perror(msg);        \
        exit(EXIT_FAILURE); \
    } while (0)

#define KEY_SIZE 64
#define KEY_PATH "sandbox.key"
#define SANDBOX_PATH "sandbox-workdir"
#define PORT 2077
#define BUFFER_SIZE 1024

int s = 0;
unsigned char key[KEY_SIZE];

int read_random_data(unsigned char *buf, size_t size)
{
    int urandom = open("/dev/urandom", O_RDONLY);
    if (urandom == -1)
        return -1;
    if (read(urandom, buf, size) != size)
        return -1;
    close(urandom);
    return 0;
}

int set_up_strict_mode(unsigned int level)
{
    scmp_filter_ctx ctx;
    ctx = seccomp_init(SCMP_ACT_ALLOW);
    if (ctx == NULL)
        FATAL("seccomp_init");

    if (seccomp_rule_add(ctx, SCMP_ACT_KILL, SCMP_SYS(openat2), 0) != 0)
    {
        perror("seccomp_rule_add");
        seccomp_release(ctx);
        return 1;
    }

    if (seccomp_rule_add(ctx, SCMP_ACT_KILL, SCMP_SYS(chroot), 0) != 0)
    {
        perror("seccomp_rule_add");
        seccomp_release(ctx);
        return 1;
    }

    if (seccomp_rule_add(ctx, SCMP_ACT_KILL, SCMP_SYS(chmod), 0) != 0)
    {
        perror("seccomp_rule_add");
        seccomp_release(ctx);
        return 1;
    }

    if (seccomp_rule_add(ctx, SCMP_ACT_KILL, SCMP_SYS(fchmod), 0) != 0)
    {
        perror("seccomp_rule_add");
        seccomp_release(ctx);
        return 1;
    }

    if (seccomp_rule_add(ctx, SCMP_ACT_KILL, SCMP_SYS(chown), 0) != 0)
    {
        perror("seccomp_rule_add");
        seccomp_release(ctx);
        return 1;
    }

    if (seccomp_rule_add(ctx, SCMP_ACT_KILL, SCMP_SYS(fchown), 0) != 0)
    {
        perror("seccomp_rule_add");
        seccomp_release(ctx);
        return 1;
    }

    if (seccomp_rule_add(ctx, SCMP_ACT_KILL, SCMP_SYS(lchown), 0) != 0)
    {
        perror("seccomp_rule_add");
        seccomp_release(ctx);
        return 1;
    }

    if (seccomp_rule_add(ctx, SCMP_ACT_KILL, SCMP_SYS(symlink), 0) != 0)
    {
        perror("seccomp_rule_add");
        seccomp_release(ctx);
        return 1;
    }

    if (level >= 2)
    {
        if (seccomp_rule_add(ctx, SCMP_ACT_KILL, SCMP_SYS(ioctl), 0) != 0)
        {
            perror("seccomp_rule_add");
            seccomp_release(ctx);
            return 1;
        }

        if (seccomp_rule_add(ctx, SCMP_ACT_KILL, SCMP_SYS(ptrace), 0) != 0)
        {
            perror("seccomp_rule_add");
            seccomp_release(ctx);
            return 1;
        }

        if (seccomp_rule_add(ctx, SCMP_ACT_KILL, SCMP_SYS(mount), 0) != 0)
        {
            perror("seccomp_rule_add");
            seccomp_release(ctx);
            return 1;
        }
    }

    if (level >= 3)
    {
        if (setgid(65534) != 0)
        {
            perror("setgid");
            return 1;
        }
        if (setuid(65534) != 0)
        {
            perror("setuid");
            return 1;
        }

        if (seccomp_rule_add(ctx, SCMP_ACT_KILL, SCMP_SYS(setuid), 0) != 0)
        {
            perror("seccomp_rule_add");
            seccomp_release(ctx);
            return 1;
        }

        if (seccomp_rule_add(ctx, SCMP_ACT_KILL, SCMP_SYS(setgid), 0) != 0)
        {
            perror("seccomp_rule_add");
            seccomp_release(ctx);
            return 1;
        }

        if (seccomp_rule_add(ctx, SCMP_ACT_KILL, SCMP_SYS(setsid), 0) != 0)
        {
            perror("seccomp_rule_add");
            seccomp_release(ctx);
            return 1;
        }

        if (seccomp_rule_add(ctx, SCMP_ACT_KILL, SCMP_SYS(setfsuid), 0) != 0)
        {
            perror("seccomp_rule_add");
            seccomp_release(ctx);
            return 1;
        }

        if (seccomp_rule_add(ctx, SCMP_ACT_KILL, SCMP_SYS(setfsgid), 0) != 0)
        {
            perror("seccomp_rule_add");
            seccomp_release(ctx);
            return 1;
        }

        if (seccomp_rule_add(ctx, SCMP_ACT_KILL, SCMP_SYS(setresuid), 0) != 0)
        {
            perror("seccomp_rule_add");
            seccomp_release(ctx);
            return 1;
        }

        if (seccomp_rule_add(ctx, SCMP_ACT_KILL, SCMP_SYS(setresgid), 0) != 0)
        {
            perror("seccomp_rule_add");
            seccomp_release(ctx);
            return 1;
        }

        if (seccomp_rule_add(ctx, SCMP_ACT_KILL, SCMP_SYS(setpgid), 0) != 0)
        {
            perror("seccomp_rule_add");
            seccomp_release(ctx);
            return 1;
        }

        if (seccomp_rule_add(ctx, SCMP_ACT_KILL, SCMP_SYS(setreuid), 0) != 0)
        {
            perror("seccomp_rule_add");
            seccomp_release(ctx);
            return 1;
        }

        if (seccomp_rule_add(ctx, SCMP_ACT_KILL, SCMP_SYS(setregid), 0) != 0)
        {
            perror("seccomp_rule_add");
            seccomp_release(ctx);
            return 1;
        }
    }

    if (level >= 4)
    {
        if (seccomp_rule_add(ctx, SCMP_ACT_KILL, SCMP_SYS(getpid), 0) != 0)
        {
            perror("seccomp_rule_add");
            seccomp_release(ctx);
            return 1;
        }

        if (seccomp_rule_add(ctx, SCMP_ACT_KILL, SCMP_SYS(getppid), 0) != 0)
        {
            perror("seccomp_rule_add");
            seccomp_release(ctx);
            return 1;
        }

        if (seccomp_rule_add(ctx, SCMP_ACT_KILL, SCMP_SYS(fork), 0) != 0)
        {
            perror("seccomp_rule_add");
            seccomp_release(ctx);
            return 1;
        }

        if (seccomp_rule_add(ctx, SCMP_ACT_KILL, SCMP_SYS(chdir), 0) != 0)
        {
            perror("seccomp_rule_add");
            seccomp_release(ctx);
            return 1;
        }

        if (seccomp_rule_add(ctx, SCMP_ACT_KILL, SCMP_SYS(link), 0) != 0)
        {
            perror("seccomp_rule_add");
            seccomp_release(ctx);
            return 1;
        }

        if (seccomp_rule_add(ctx, SCMP_ACT_KILL, SCMP_SYS(creat), 0) != 0)
        {
            perror("seccomp_rule_add");
            seccomp_release(ctx);
            return 1;
        }
    }

    if (seccomp_load(ctx) != 0)
    {
        perror("seccomp_load");
        seccomp_release(ctx);
        return 1;
    }

    seccomp_release(ctx);

    return 0;
}

void init()
{
    if (read_random_data(key, sizeof(key)) != 0)
        FATAL("read random data");

    int fd = open(KEY_PATH, O_WRONLY | O_CREAT | O_TRUNC, 0644);
    if (fd == -1)
        FATAL("open key file");
    for (int i = 0; i < sizeof(key); i++)
    {
        char buf[3];
        snprintf(buf, sizeof(buf), "%02x", key[i]);
        if (write(fd, buf, 2) != 2)
            FATAL("write key file");
    }
    close(fd);

    mkdir(SANDBOX_PATH, 0700);
    if (chdir(SANDBOX_PATH) != 0)
        FATAL("chdir");
}

void handle_connection(int c)
{
    prctl(PR_SET_PDEATHSIG, SIGTERM);
    unsigned char chall[KEY_SIZE];
    read_random_data(chall, sizeof(chall));
    send(c, chall, sizeof(chall), MSG_NOSIGNAL | MSG_DONTWAIT);
    unsigned int size;
    if (recv(c, &size, sizeof(size), 0) != sizeof(size))
        return;
    if (size > 64 * 1024 * 1024)
        return;

    unsigned int options;
    if (recv(c, &options, sizeof(options), 0) != sizeof(options))
        return;

    unsigned int strict_mode_level = options & 0xf;
    int redirect_stdout = (options >> 4) & 1;
    int redirect_stderr = (options >> 5) & 1;

    unsigned char *buf = malloc(size);
    if (buf == NULL)
        return;

    unsigned int read_size = 0;
    while (read_size < size)
    {
        ssize_t n = recv(c, buf + read_size, size - read_size, 0);
        if (n <= 0)
        {
            free(buf);
            return;
        }
        read_size += n;
    }

    for (unsigned int i = 0; i < KEY_SIZE; i++)
    {
        if ((buf[i] ^ chall[i]) != key[i])
        {
            free(buf);
            return;
        }
    }

    unsigned char *data = buf + KEY_SIZE;

    for (unsigned int i = 0; i < size - KEY_SIZE; i++)
    {
        data[i] ^= key[i % KEY_SIZE];
    }

    unsigned char dir_name[KEY_SIZE * 2 + 1];
    unsigned char dir_random[KEY_SIZE];
    read_random_data(dir_random, sizeof(dir_random));
    for (size_t i = 0; i < KEY_SIZE; i++)
    {
        snprintf(dir_name + i * 2, 3, "%02x", dir_random[i]);
    }

    mkdir(dir_name, 0755);
    if (chdir(dir_name) != 0)
    {
        free(buf);
        return;
    }

    int fd = open("prog", O_WRONLY | O_CREAT | O_TRUNC, 0755);
    if (fd == -1)
    {
        free(buf);
        return;
    }

    if (write(fd, data, size - KEY_SIZE) != size - KEY_SIZE)
    {
        close(fd);
        free(buf);
        return;
    }

    free(buf);
    close(fd);

    chmod("prog", 0755);

    int pipefd[2];
    if (pipe(pipefd) == -1)
    {
        return;
    }
    int pid = fork();
    if (pid == -1)
    {
        return;
    }
    if (pid == 0)
    {
        prctl(PR_SET_PDEATHSIG, SIGTERM);
        close(pipefd[0]);
        if (chroot(".") != 0)
            exit(1);
        if (chdir("/") != 0)
            exit(1);
        if (set_up_strict_mode(strict_mode_level) != 0)
            exit(1);
        if (redirect_stdout)
        {
            if (dup2(pipefd[1], 1) == -1)
            {
                exit(1);
            }
        }
        if (redirect_stderr)
        {
            if (dup2(pipefd[1], 2) == -1)
            {
                exit(1);
            }
        }
        execl("/prog", "/prog", NULL);
        exit(0);
    }
    else
    {
        close(pipefd[1]);
        unsigned int bytes_read = 0;
        unsigned char buffer[BUFFER_SIZE];
        while ((bytes_read = read(pipefd[0], buffer, BUFFER_SIZE - 1)) > 0)
        {
            send(c, buffer, bytes_read, MSG_NOSIGNAL | MSG_DONTWAIT);
        }
        close(pipefd[0]);
        int status;
        waitpid(pid, &status, 0);
        send(c, "EOF", 3, MSG_NOSIGNAL | MSG_DONTWAIT);
        chdir("..");
        char rm_cmd[512];
        snprintf(rm_cmd, sizeof(rm_cmd), "rm -rf %s", dir_name);
        system(rm_cmd);
    }
}

void handle_signal(int signal)
{
    if (signal == SIGINT)
    {
        close(s);
        exit(0);
    } 

    if (signal == SIGCHLD)
    {
        wait(NULL);
    }
}

int main()
{
    init();

    s = socket(AF_INET, SOCK_STREAM, 0);
    if (s == -1)
        FATAL("socket");

    struct sockaddr_in addr;
    memset(&addr, 0, sizeof(addr));
    addr.sin_family = AF_INET;
    addr.sin_addr.s_addr = inet_addr("127.0.0.1");
    addr.sin_port = htons(PORT);

    if (bind(s, (struct sockaddr *)&addr, sizeof(addr)) == -1)
        FATAL("bind");

    if (listen(s, 5) == -1)
        FATAL("listen");

    signal(SIGINT, handle_signal);
    signal(SIGCHLD, handle_signal);

    while (1)
    {
        int c = accept(s, NULL, NULL);
        if (c == -1)
            FATAL("accept");

        int pid = fork();
        if (pid == -1)
            FATAL("fork");

        if (pid == 0)
        {
            close(s);
            handle_connection(c);
            shutdown(c, SHUT_RDWR);
            close(c);
            exit(0);
        }
    }

    return 0;
}