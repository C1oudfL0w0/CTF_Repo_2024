public class Test {
    public static void main(String[] args) {
        String keyword = "渗透";
        String sql = String.format("SELECT * FROM member WHERE intro LIKE %s;",keyword);
        System.out.println(sql);
    }
}
