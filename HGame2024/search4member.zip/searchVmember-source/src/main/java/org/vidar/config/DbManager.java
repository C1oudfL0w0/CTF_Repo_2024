package org.vidar.config;


import com.zaxxer.hikari.HikariConfig;
import com.zaxxer.hikari.HikariDataSource;
import org.h2.tools.RunScript;
import org.noear.solon.annotation.Component;
import org.noear.solon.annotation.Init;
import org.noear.solon.annotation.Inject;

import javax.sql.DataSource;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.sql.Connection;
import java.sql.SQLException;

@Component
public class DbManager {
    @Inject("${project.home}")
    public String home;
    DataSource dataSource;

    @Init
    public void init() throws SQLException, FileNotFoundException {
        HikariConfig config = new HikariConfig();
        String dbPath = home + "h2";
        config.setJdbcUrl(("jdbc:h2:" + dbPath));
        config.setUsername("username");
        config.setPassword("password");
        dataSource = new HikariDataSource(config);

        Connection connection = dataSource.getConnection();
        RunScript.execute(connection, new FileReader(home+"init.sql"));

        connection.close();
    }

    public DataSource getDataSource() {
        return dataSource;
    }

}
