import { Hono } from 'https://deno.land/x/hono@v4.3.0/mod.ts'
import { serveStatic, jwt } from 'https://deno.land/x/hono@v4.3.0/middleware.ts'
import { sign } from 'https://deno.land/x/hono@v4.3.0/utils/jwt/jwt.ts'
import { MongoClient } from 'npm:mongodb@6.6.0'
import { randomBytes } from 'node:crypto'
import assert from 'node:assert'

function createToken(length: number) {
  return randomBytes(length).toString('hex')
}

const secret = createToken(32)

const client = new MongoClient('mongodb://127.0.0.1:27017')
await client.connect()
const db = client.db('messy')

interface User {
  _id: string
  username: string
  password: string
}
const users = db.collection<User>('users')

interface Todo {
  _id: string
  user: string
  title: string
  completed: boolean
}
const todos = db.collection<Todo>('todos')

const app = new Hono()

app.use('/', serveStatic({ root: './static' }))

app.post('/api/login', async (c) => {
  const { username, password } = await c.req.json()
  assert(typeof username === 'string')
  assert(typeof password === 'string')
  const user = await users.findOne({ username, password })
  assert(user)
  const token = await sign({ user: user.username }, secret)
  return c.json({ token })
})

app.use('/api/*', jwt({ secret }))

app.patch('/api/login', async (c) => {
  const { user } = c.get('jwtPayload')
  const delta = await c.req.json()
  const newname = delta['username']
  assert.notEqual(newname, 'admin')
  await users.updateOne({ username: user }, [{ $set: delta }])
  if (newname) {
    await todos.updateMany({ user }, [{ $set: { user: delta['username'] } }])
  }
  return c.json(0)
})

app.get('/api/todo', async (c) => {
  const { user } = c.get('jwtPayload')
  const list = await todos.find({ user }).toArray()
  return c.json(list)
})

app.post('/api/todo', async (c) => {
  const { user } = c.get('jwtPayload')
  const { title } = await c.req.json()
  assert(typeof title === 'string')
  await todos.insertOne({ _id: createToken(16), user, title, completed: false })
  return c.json(0)
})

app.get('/api/todo/:id', async (c) => {
  const { user } = c.get('jwtPayload')
  const todo = await todos.findOne({ _id: c.req.param('id'), user })
  return c.json(todo)
})

app.patch('/api/todo/:id', async (c) => {
  const { user } = c.get('jwtPayload')
  const delta = await c.req.json()
  assert(!('_id' in delta))
  assert(!('user' in delta))
  const { matchedCount } = await todos.updateOne({ _id: c.req.param('id'), user }, [
    { $set: delta }
  ])
  assert(matchedCount)
  return c.json(0)
})

app.delete('/api/todo/:id', async (c) => {
  const { user } = c.get('jwtPayload')
  const { deletedCount } = await todos.deleteOne({
    _id: c.req.param('id'),
    user
  })
  assert(deletedCount)
  return c.json(0)
})

Deno.serve({ hostname: '0.0.0.0', port: 1898 }, app.fetch)
