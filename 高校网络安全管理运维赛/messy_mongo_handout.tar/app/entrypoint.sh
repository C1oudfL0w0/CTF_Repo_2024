mongod >/dev/null 2>&1 &
echo "Waiting for mongod to start..."
while ! mongosh --eval 'db' >/dev/null 2>&1; do
  sleep 1
done
echo "MongoDB started, initializing..."
mongosh <<EOF
use messy
db.createCollection('users', {
  validator: {
    \$jsonSchema: {
      bsonType: 'object',
      required: ['_id', 'password'],
      properties: {
        _id: { bsonType: 'string' },
        username: { bsonType: 'string' },
        password: { bsonType: 'string' }
      }
    }
  }
})
db.users.createIndex({ username: 1 }, { unique: true })
db.createCollection('todos', {
  validator: {
    \$jsonSchema: {
      bsonType: 'object',
      required: ['_id', 'user', 'title', 'completed'],
      properties: {
        _id: { bsonType: 'string' },
        user: { bsonType: 'string' },
        title: { bsonType: 'string' },
        completed: { bsonType: 'bool' }
      }
    }
  }
})
db.todos.insertOne({ _id: '$(openssl rand -hex 16)', user: 'admin', title: 'Secretly keep my flag is $FLAG!', completed: false })
db.users.insertOne({ _id: '$(openssl rand -hex 16)', username: 'ctfer', password: 'helloctfer!' })
db.todos.insertOne({ _id: '$(openssl rand -hex 16)', user: 'ctfer', title: 'Try to hack and get the flag', completed: false })
EOF
deno run --allow-sys --allow-read --deny-env --allow-net=127.0.0.1:27017,0.0.0.0:1898 index.ts