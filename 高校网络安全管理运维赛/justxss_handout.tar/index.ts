import { fastify } from 'fastify'
import assert from 'node:assert'
import { readFile } from 'node:fs/promises'
import { setTimeout } from 'node:timers/promises'
import { launch } from 'puppeteer-core'

const flag = await readFile('/flag', 'utf8')
console.log('[+] flag loaded')

const browser = await launch({
  executablePath: '/usr/bin/chromium',
  headless: true,
  pipe: true,
  args: ['--no-sandbox']
})
console.log('[+] browser launched')

let visiting = false

async function visit(url: string) {
  if (visiting) return
  url = new URL(url).toString()
  const { protocol } = new URL(url)
  if (!['http:', 'https:'].includes(protocol)) return

  console.log(`[+] visiting ${url}`)
  visiting = true
  try {
    const page = await browser.newPage()
    try {
      await page.goto('http://localhost:1898', { waitUntil: 'domcontentloaded' })
      await page.setCookie({
        name: 'flag',
        value: encodeURIComponent(flag)
      })
      await page.goto(url)
      await setTimeout(5000)
    } catch (err) {
      console.log(err)
    }
    await page.close()
  } catch (err) {
    console.log(err)
  }
  visiting = false
}

const index = await readFile('index.html', 'utf8')

const app = fastify({ logger: true })

app.get('/', (req, rep) => {
  const nonce = Math.random().toString().split('.')[1]
  rep.header('Content-Type', 'text/html')
  rep.header(
    'Content-Security-Policy',
    `default-src none; script-src 'nonce-${nonce}' 'unsafe-eval'; style-src 'nonce-${nonce}'; img-src data:`
  )
  rep.send(index.replaceAll('$NONCE', nonce))
})

app.post('/visit', async (req) => {
  const { url } = req.body as { url: string }
  assert(typeof url === 'string', 'Invalid URL')
  visit(url)
  return 0
})

app.listen({ port: 1898, host: '0.0.0.0' })
console.log('[+] server started')
