const express = require('express')
const fs = require('fs')
var bodyParser = require('body-parser');
const app = express()
app.use(bodyParser.urlencoded({
    extended: true
}));
app.use(bodyParser.json());

app.post('/plz', (req, res) => {

    venom = req.body.venom

    if (Object.keys(venom).length < 3 && venom.welcome == 159753) {
        try {
            if(venom.hasOwnProperty("text")){
                res.send(venom.text)
            }else{
                res.send("no text detected")
            }
        } catch {
            if (venom.text=="flag") {
                let flag=fs.readFileSync("/flag");
                res.send("Congratulations:"+flag);
            } else {
                res.end("Nothing here!")
            }
        }
    } else {
        res.end("happy game");
    }
})



app.get('/',
function(req, res, next) {
    res.send('<title>oldjs</title><a>Hack me plz</a><br><form action="/plz" method="POST">text:<input type="text" name="venom[text]" value="ezjs"><input type="submit" value="Hack"></form>  ');
});

app.listen(80, () => {
  console.log(`listening at port 80`)
}) 