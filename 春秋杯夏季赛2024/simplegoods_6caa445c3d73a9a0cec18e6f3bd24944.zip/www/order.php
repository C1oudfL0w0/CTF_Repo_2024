<?php
    define('IN', true);     //定位该文件是入口文件
    require 'conn.php';
    session_start();

    if(!isset($_SESSION['user']))
    {
        echo '<script>alert("请先登录!");location="login.html"</script>';
        die();
    }else{
        $id = $_SESSION['user'];
		$sql = $conn->prepare("SELECT * FROM `member` WHERE `mem_id`='$id'");
		$sql->execute();
    	$fetch = $sql->fetch();
        if($fetch["role"]!=1){
            echo '<script>alert("只有管理员有权访问！");location="home.php"</script>';
            die();
        }
    }
    function get_goods_name($goods_id,$conn){
        $sql_query_name = "SELECT * FROM `goods` WHERE `id`=?";
        $query = $conn->prepare($sql_query_name);
        $query->execute(array($goods_id));
        $fetch = $query->fetch();
        return $fetch['name'];
    }
?>
<!DOCTYPE html>
<html>
<head>
    <title>会员中心</title>
    <meta charset="UTF-8">
    <link rel="icon" href="./static/img/icon.svg">
    <link rel="stylesheet" href="./static/css/bootstrap.min.css">
    <script src="./static/js/jquery.min.js"></script>
    <script src="./static/js/popper.min.js"></script>
    <script src="./static/js/bootstrap.min.js"></script>
    <script src="./static/js/moment-with-locales.min.js"></script>
    <link  href="./static/css/font-awesome.min.css">
</head>
<style type="text/css">
	.logo{
		color:white;
		font-family:"Microsoft YaHei",微软雅黑,"MicrosoftJhengHei",华文细黑,STHeiti,MingLiu;
		font-weight: bold;
		font-size: 20px;
	}
	#sidebar-wrapper {
	color:white;
    z-index: 1;
    position: absolute;
    width: 20%;
    height: 150%;
    overflow-y: hidden;
    background: #1f4a57;
    opacity: 0.9;
    display: flex;
    align-items: top;
	}

	.sidebar-nav {
    padding: 0;
    list-style: none;
    width: 100%;
    text-align: center;
    margin-top:114px;
    font-family: "Helvetica Neue",Helvetica,Arial,sans-serif;
	}
	.sidebar-nav li {
	margin-top:0px;
    line-height: 40px;
    width: 100%;
    padding: 10px;
	}
	.sidebar-nav li a {
    display: block;
    text-decoration: none;
    color: #bebdbd;
    font-size:17px;
	}
	.sidebar-nav li a:hover {
    display: block;
    text-decoration: none;
    color: white;
	}
	.co{
		background-color: #17a2b8!important;
	}
	.cont
	{
		width:75%;
		margin-left:22%;
		margin-top:2%;
	}
	.date{
        position:relative;
        width:100%;
    }
    .breadcrumb{
    	background-color: transparent;
    	padding: 0px;
    	color:#39a7a9;
    }
    .breadcrumb-item.active {
    color: #39a7a9;
	}
	.breadcrumb-item+.breadcrumb-item::before {
    display: inline-block;
    padding-right: .5rem;
    color:#39a7a9;
    content: ">";
    }
    .card{
        width:50px;
        height:50px;
    }
</style>
<body>
<nav class="navbar navbar-expand-sm bg-primary navbar-dark co">
      <span class="logo" href="#">会员中心</span>
  <ul class="navbar-nav ml-auto">
  <p class="navbar-text navbar-right" style="color:yellow">金币余额：<?php echo $fetch['coin']?>&nbsp;&nbsp;&nbsp;&nbsp;</p>
    <li class="nav-item dropdown active">
      <a class="nav-link dropdown-toggle" href="#" id="navbardrop" data-toggle="dropdown">
        <?php $id = $_SESSION['user'];
				$sql = $conn->prepare("SELECT * FROM `member` WHERE `mem_id`='$id'");
				$sql->execute();
				$fetch = $sql->fetch();
                echo $fetch['username'];?>
      </a>
      <div class="dropdown-menu">
        <a class="dropdown-item" href="logout.php">注销</a>
      </div>
    </li>
  </ul>
</nav>
<div id="sidebar-wrapper">
      <ul class="sidebar-nav">
      <li><a href="home.php">个人信息</a></li>
        <li><a href="market.php">商品中心</a></li>
        <li><a href="order.php" style="color:white;">订单管理</a></li>
      </ul>
</div>
<div class="cont">
	<nav class="breadcrumb">
  	<a class="breadcrumb-item" href="#">Orders</a>
  	<span class="breadcrumb-item active">index</span>
</nav>

	<table class="table table-hover">
<thead>
 <tr>
        <th>订单号</th>
        <th>商品名</th>
        <th>商品数量</th>
        <th>操作</th>
    </tr>
</thead>
<tbody>
<?php

    $sql_query_orders = "SELECT * FROM `order`";
    foreach ($conn->query($sql_query_orders) as $row) {
        echo "<tr>";
        echo "<td>".$row['order_id']."</td>";
        echo "<td>".get_goods_name((int)($row['goods_id']),$conn)."</td>";
        echo "<td>".$row['goods_num']."</td>";
        echo '<td><button class="btn btn-info" type="button" onclick="toCheck('.$row['order_id'].')">查看</button></td>';
        echo '<td><button class="btn btn-info" type="button" onclick="toCancel('.$row['order_id'].')">退款</button></td>';
        echo "</tr>";
        }
?>
</tbody>
</table>
</div>
<script>
    function toManage(id){
        window.location="order_api.php?method=manage&id="+id;
    }
    function toCheck(id){
        window.location="goods_api.php?method=check&id="+id;
    }
    function toTest(id){
        window.location="test_api.php?method=test&id="+id;
    }
    function toDelete(id){
        window.location="delete.php?method=delete&id="+id;
    }
    function toCancel(id){
    	window.location="refund.php?method=cancel&id="+id;
    }
</script>
</html>

<?php include_once("init.php");?>