<?php
    define('IN', true);     //定位该文件是入口文件
    session_start();
    require_once 'conn.php';

    if ($_POST['username'] != "" && $_POST['password'] != "") {
        $username = $_POST['username'];
        // md5 encrypted
        $password = md5($_POST['password']);
        // $password = $_POST['password'];
        $sql = "SELECT * FROM `member` WHERE `username`=? AND `password`=? ";
        $query = $conn->prepare($sql);
        $query->execute(array($username, $password));
        $row = $query->rowCount();
        $fetch = $query->fetch();
        if ($row > 0) {
            $_SESSION['user'] = $fetch['mem_id'];
            header("location: home.php");
        } else {
            echo "
				<script>alert('Invalid username or password')</script>
				<script>window.location = 'login.html'</script>
				";
        }
    } else {
        echo "
				<script>alert('Please complete the required field!')</script>
				<script>window.location = 'login.html'</script>
			";
    }

?>

<?php include_once("init.php");?>