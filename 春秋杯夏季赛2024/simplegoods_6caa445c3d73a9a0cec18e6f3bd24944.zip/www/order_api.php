<?php
    define('IN', true);     //定位该文件是入口文件
    session_start();
    require_once 'conn.php';
    
    if(!isset($_SESSION['user']))
    {
        echo '<script>alert("请先登录!");location="login.html"</script>';
        die();
    }else{
        $id = $_SESSION['user'];
        // $id = 1;
        // session_write_close();
		$sql = $conn->prepare("SELECT * FROM `member` WHERE `mem_id`='$id'");
		$sql->execute();
    	$fetch = $sql->fetch();
        if($fetch["role"]!=1){
            echo '<script>alert("Permission access denied!");location="home.php"</script>';
            die();
        }
    }

    if(ISSET($_GET['method'])&&ISSET($_GET['id'])){
        $method = $_GET['method'];
        $goods_id = $_GET['id'];
        if($method=="buy"){
            $sql_query_price="SELECT * FROM `goods` WHERE `id`=?";
            $query = $conn->prepare($sql_query_price);
            $query->execute(array($goods_id));
            $row = $query->rowCount();
            $fetch_good = $query->fetch();
            if ($row > 0) {
                if($fetch['coin']>=$fetch_good['price']){
                    $sql_add_order="INSERT INTO `order`(goods_id,user_id,goods_num) values(?,?,?)";
                    $insert = $conn->prepare($sql_add_order);
                    $insert->execute(array($goods_id,$fetch['mem_id'],1));
                    $sql_de_coin="UPDATE member set coin=coin-? where mem_id=?";
                    $sub =  $conn->prepare($sql_de_coin);
                    $sub->execute(array($fetch_good['price'],$fetch['mem_id']));
                }else{
                    echo "
				<script>alert('余额不足！')</script>
				<script>window.location = 'market.php'</script>
				";
                }
            }else{
                echo "
				<script>alert('商品不存在!')</script>
				<script>window.location = 'market.php'</script>
				";
            };
        }else{
            echo "
				<script>alert('调用方法错误！')</script>
				<script>window.location = 'login.html'</script>
				";
        }
        
    }else{
        echo "
				<script>alert('No params!')</script>
				<script>window.location = 'login.html'</script>
				";
    }
?>
<?php include_once("init.php");?>