<?php
    define('IN', true);     //定位该文件是入口文件
    session_start();
    require_once 'conn.php';
    
    if(!isset($_SESSION['user']))
    {
        echo '<script>alert("请先登录!");location="login.html"</script>';
        die();
    }else{
        $id = $_SESSION['user'];
        // $id = 1;
        session_write_close();
		$sql = $conn->prepare("SELECT * FROM `member` WHERE `mem_id`='$id'");
		$sql->execute();
    	$fetch = $sql->fetch();
        if($fetch["role"]!=1){
            echo '<script>alert("Permission access denied!");location="home.php"</script>';
            die();
        }
    }

    if(ISSET($_GET['method'])&&ISSET($_GET['id'])){
        $method = $_GET['method'];
        $order_id = $_GET['id'];
        if($method=="cancel"){
            $sql_cancel_order="SELECT * FROM `order` WHERE `order_id`=?";
            $query = $conn->prepare($sql_cancel_order);
            $query->execute(array($order_id));
            $row = $query->rowCount();
            $fetch_order = $query->fetch();
            if ($row > 0) {
                $sql_query_price="SELECT * FROM `goods` WHERE `id`=?";
                $query = $conn->prepare($sql_query_price);
                $query->execute(array($fetch_order["goods_id"]));
                $fetch_good = $query->fetch();
                $price = $fetch_good["price"];
                // 更新coin
                $sql_update_coin="UPDATE member set coin=coin+? where mem_id=?";
                $update =  $conn->prepare($sql_update_coin);
                $update->execute(array($fetch_good['price'],$fetch['mem_id']));
                // usleep(100000);
                usleep(rand(50000,200000));
                // 删除订单
                $sql_delete_order="DELETE FROM `order` WHERE `order_id`=?";
                $query = $conn->prepare($sql_delete_order);
                $query->execute(array($order_id));
                Header("Location:order.php");

            }else{
                echo "
				<script>alert('订单错误！')</script>
				<script>window.location = 'market.php'</script>
				";
            }

        }else{
            echo "
				<script>alert('调用方法错误！')</script>
				<script>window.location = 'market.php'</script>
				";
        }
        
    }else{
        echo "
				<script>alert('No params!')</script>
				<script>window.location = 'market.php'</script>
				";
    }
?>
<?php include_once("init.php");?>