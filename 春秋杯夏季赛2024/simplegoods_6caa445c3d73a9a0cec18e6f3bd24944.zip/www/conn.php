<?php
	$dbms='mysql';     //数据库类型
    $host='127.0.0.1'; //数据库主机名
    $dbName='flag';    //使用的数据库
    $user='db';      //数据库连接用户名
    $pass='db';          //对应的密码
    $dsn="$dbms:host=$host;dbname=$dbName";
    
    
    try {
        $dbh = new PDO($dsn, $user, $pass); //初始化一个PDO对象
        // echo "连接成功<br/>";
        $dbh = null;
    } catch (PDOException $e) {
        die ("Error!: " . $e->getMessage() . "<br/>");
    }
    //默认这个不是长连接，如果需要数据库长连接，需要最后加一个参数：array(PDO::ATTR_PERSISTENT => true) 变成这样：
    $conn = new PDO($dsn, $user, $pass,array(PDO::ATTR_PERSISTENT => false));
?>

<?php include_once("init.php");?>