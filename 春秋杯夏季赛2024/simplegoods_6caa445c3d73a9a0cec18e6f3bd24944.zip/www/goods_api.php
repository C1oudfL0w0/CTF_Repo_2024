<?php
    define('IN', true);     //定位该文件是入口文件
    session_start();
    require_once 'conn.php';
    
    if(!isset($_SESSION['user']))
    {
        echo '<script>alert("请先登录!");location="login.html"</script>';
        die();
    }else{
        $id = $_SESSION['user'];
        // $id = 1;
        // session_write_close();
		$sql = $conn->prepare("SELECT * FROM `member` WHERE `mem_id`='$id'");
		$sql->execute();
    	$fetch = $sql->fetch();
        if($fetch["role"]!=1){
            echo '<script>alert("Permission access denied!");location="home.php"</script>';
            die();
        }
    }

    if(ISSET($_REQUEST['method'])&&ISSET($_REQUEST['id'])){
        $method = $_REQUEST['method'];
        $goods_id = $_REQUEST['id'];
        if($method=="buy"){
            $sql_query_price="SELECT * FROM `goods` WHERE `id`=?";
            $query = $conn->prepare($sql_query_price);
            $query->execute(array($goods_id));
            $row = $query->rowCount();
            $fetch_good = $query->fetch();
            if ($row > 0) {
                if($fetch['coin']>=$fetch_good['price']){
                    $sql_add_order="INSERT INTO `order`(goods_id,user_id,goods_num) values(?,?,?)";
                    $insert = $conn->prepare($sql_add_order);
                    $insert->execute(array($goods_id,$fetch['mem_id'],1));
                    // 扣除余额
                    // sleep(1);
                    $sql_de_coin="UPDATE member set coin=coin-? where mem_id=?";
                    $sub =  $conn->prepare($sql_de_coin);
                    $sub->execute(array($fetch_good['price'],$fetch['mem_id']));
                    header("Location:order.php");
                }else{
                    echo "
				<script>alert('余额不足！')</script>
				<script>window.location = 'market.php'</script>
				";
                }
            }else{
                echo "
				<script>alert('商品不存在!')</script>
				<script>window.location = 'market.php'</script>
				";
            };
        }else if($method=="check"){
            $sql_query_order = "SELECT * FROM `order` WHERE `order_id`=?";
            $id = $_GET['id'];
            $query = $conn->prepare($sql_query_order);
            $query->execute(array($id));
            $row = $query->rowCount();
            $fetch = $query->fetch();
            // var_dump($fetch);
            if($row>0){
                $sql_query_goods = "SELECT * FROM goods WHERE `id`=?";
                $query = $conn->prepare($sql_query_goods);
                $query->execute(array($fetch['goods_id']));
                $row = $query->rowCount();
                $fetch = $query->fetch();
                if($row>0){
                    echo "
                    <script>alert('".$fetch['content']."')</script>
                    <script>window.location = 'order.php'</script>
                    ";
                }

            }else{
                echo "
                    <script>alert('订单错误！')</script>
                    <script>window.location = 'market.php'</script>
                    ";
            }
        }else if($method=="add"){
            $goods_id = $_REQUEST['id'];
            $goods_name = $_REQUEST['goods_name'];
            $goods_price = $_REQUEST['goods_price'];
            $goods_description = $_REQUEST['goods_description'];
        
            $sql = "INSERT INTO goods (id, `name`, price, content) VALUES (:goods_id, :goods_name, :goods_price, :goods_description)";
            $stmt = $conn->prepare($sql);
        
            $stmt->bindParam(':goods_id', $goods_id);
            $stmt->bindParam(':goods_name', $goods_name);
            $stmt->bindParam(':goods_price', $goods_price);
            $stmt->bindParam(':goods_description', $goods_description);
        
            $stmt->execute();
        
            echo "
                <script>alert('商品已成功添加！')</script>
                <script>window.location = 'market.php'</script>
                ";
        }else{
                echo "
                    <script>alert('调用方法错误！')</script>
                    <script>window.location = 'market.php'</script>
                    ";
        }
    }else{
        echo "
				<script>alert('No params!')</script>
				<script>window.location = 'market.php'</script>
				";
    }
?>

<?php include_once("init.php");?>