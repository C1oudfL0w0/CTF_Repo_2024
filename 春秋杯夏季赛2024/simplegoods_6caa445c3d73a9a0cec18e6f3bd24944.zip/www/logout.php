<?php
define('IN', true);     //定位该文件是入口文件
session_start();
session_destroy();
header('location: login.html');
?>

<?php include_once("init.php");?>