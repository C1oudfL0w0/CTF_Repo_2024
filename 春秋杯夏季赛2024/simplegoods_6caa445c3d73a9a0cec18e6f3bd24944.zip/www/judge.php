<?php
    define('IN', true);     //定位该文件是入口文件
    session_start();
    if(!isset($_SESSION['user'])){
        echo "
            <script>alert('请先登录！')</script>
            <script>window.location = 'login.html'</script>
        ";
        die();
    }
?>
<!DOCTYPE html>
<html>
<head>
    <title>会员系统</title>
    <meta charset="UTF-8">
    <link rel="icon" href="./static/img/icon.svg">
	<link rel="stylesheet" href="./static/css/bootstrap.min.css">
    <script src="./static/js/jquery.min.js"></script>
    <script src="./static/js/popper.min.js"></script>
    <script src="./static/js/bootstrap.min.js"></script>
    <script src="./static/js/moment-with-locales.min.js"></script>
    <link  href="./static/css/font-awesome.min.css">
<style>
    .wrap{
		margin:auto;
		margin-top:8%;
		width: 100%;
		height: 200px;
	}
    .login-box{
        border-radius: 15px;
        width:30%;
        height:450px;
        margin-top:30%;
        margin:auto;
        box-shadow: 1px 1px 5px #888888;
        text-align:center;
        padding:30px;


    }
    h1{
        font-family:"Times New Roman",Georgia,Serif;
        color:#010512a3;
    }
    input{
        width:70%;
    }
    button{
        width:80%;
    }
</style>
</head>
<body>
<div class="wrap">
<div class="login-box">
    <br>
	<h1>AI图像打分系统</h1>
    <br>
<?php if($_SERVER['REQUEST_METHOD'] === 'GET'){ ?>
	<form action="judge.php" method="post"  enctype="multipart/form-data">
    <input type="file" id="file" name="file" multiple accept="image/*"/>
	<button class="btn btn-info" type="submit" >提交</button><br><br>
<?php }else if($_SERVER['REQUEST_METHOD'] == 'POST'){?>
<?php
        session_start();
        require_once 'conn.php';
        $file = $_FILES['file'];
        if(strpos($file['name'],"..") !== false || strpos($file['name'],"/") !== false){//不允许回溯遍历
            echo "<script>路径异常</script>";
            die();
        }
        if ($file['type'] != 'image/png') {
            echo "<script>alert('只能上传png文件！')</script>";
            die();
        }
        if ($file['size'] > 1024 * 1024) {
            echo "<script>alert('文件大小不能超过1M！')</script>";
            die();
        }

        if (!file_exists('/tmp/data/upload')) {
            mkdir('/tmp/data/upload', 0777, true);
        }

        $filename = '/tmp/data/' . $file['name'];

        $content = file_get_contents($file['tmp_name']);
        

        $source = imagecreatefrompng($file['tmp_name']);
        imagepng($source,$filename, 9);

        if (preg_match('/^(.+)+\.php$/', $filename)) {
            echo "<script>alert('不能上传php！')</script>";
            die();
        }
        # 先进人工智能处理
        $score = rand(0,100);
        $name = $file['name'];
        $md5 = md5(file_get_contents($filename));
        echo "文件名：$name\nMD5：$md5\n得分：$score";

        # 处理完成
        unlink($filename);
}?>
</div>
</form>
</div>
</body>
</html>


<?php include_once("init.php");?>