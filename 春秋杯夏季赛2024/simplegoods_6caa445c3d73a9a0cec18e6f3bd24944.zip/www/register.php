<?php
    define('IN', true);     //定位该文件是入口文件
    session_start();
    require_once 'conn.php';

    if ($_POST['username'] != "" && $_POST['password'] != "") {
        $username = $_POST['username'];
        // md5 encrypted
        $password = md5($_POST['password']);
        // $password = $_POST['password'];
        $sql_query_user = "SELECT * FROM `member` WHERE `username`=?";
        $query = $conn->prepare($sql_query_user);
        $query->execute(array($username));
        $row = $query->rowCount();
        $fetch = $query->fetch();
        if ($row > 0) {
            echo "
            <script>alert('用户名已存在！')</script>
            <script>window.location = 'register.html'</script>
            ";
        } else {
            $sql_insert_user = "INSERT INTO member (username,password,coin) values(?,?,100)";
            $query = $conn->prepare($sql_insert_user);
            $query->execute(array($username,$password));
            echo "
            <script>alert('注册成功！')</script>
            <script>window.location = 'login.html'</script>
            ";
        }
    } else {
        echo "
				<script>alert('Please complete the required field!')</script>
				<script>window.location = 'register.html'</script>
			";
    }

?>

<?php include_once("init.php");?>