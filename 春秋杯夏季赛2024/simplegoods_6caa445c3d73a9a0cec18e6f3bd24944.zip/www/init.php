<?php
if (!defined('IN'))
    die('bad request');
?>