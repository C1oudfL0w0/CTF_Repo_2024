<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\System\\Providers\\SystemServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\System\\Providers\\SystemServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);