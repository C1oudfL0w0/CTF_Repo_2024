<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Mp\\Providers\\MpServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Mp\\Providers\\MpServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);