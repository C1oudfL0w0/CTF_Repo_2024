<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Order\\Providers\\OrderServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Order\\Providers\\OrderServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);