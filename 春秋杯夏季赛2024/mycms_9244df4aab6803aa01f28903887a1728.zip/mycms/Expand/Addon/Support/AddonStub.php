<?php


namespace Expand\Addon\Support;


use Nwidart\Modules\Support\Stub;

class AddonStub extends Stub
{

    protected static $basePath = 'Expand/Addon/Commands/stubs';

}
