<?php


namespace Expand\Addon\Repository;


use Nwidart\Modules\Contracts\RepositoryInterface;

interface AddonRepositoryInterface extends RepositoryInterface
{

}
