<?php

return [
    'admin.addon.nav' => '导航',
    'admin/addon/nav' => '导航管理',
    'admin/addon/nav/create' => '添加导航',
    'admin/addon/nav/edit' => '编辑导航',
    'admin/addon/nav/destroy' => '删除导航',
    'admin/addon/nav/config' => '导航配置',
];
