<?php

return [
    'navs' => [
        \Addons\Nav\Pipeline\NavsPipeLine::class
    ]
];
