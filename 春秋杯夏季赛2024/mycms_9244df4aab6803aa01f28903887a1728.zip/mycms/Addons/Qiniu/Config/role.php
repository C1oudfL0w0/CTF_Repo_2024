<?php

return [
    'admin.addon.qiniu' => '七牛云存储',
    'admin/addon/qiniu/config' => '七牛云配置',
];
