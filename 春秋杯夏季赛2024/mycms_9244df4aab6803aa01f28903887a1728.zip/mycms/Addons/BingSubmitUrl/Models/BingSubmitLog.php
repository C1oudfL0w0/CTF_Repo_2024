<?php


namespace Addons\BingSubmitUrl\Models;


use App\Models\MyModel;

class BingSubmitLog extends MyModel
{
    protected $table = 'my_bing_submit_log';
}
