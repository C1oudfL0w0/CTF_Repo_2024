<?php

return [
    'url:article/admin/create:POST:200' => [
        '\Addons\BingSubmitUrl\Events\BingSubmitUrlEvent'
    ],
];
