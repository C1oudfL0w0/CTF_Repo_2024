<?php

return [
    'name' => 'BingSubmitUrl'
];
