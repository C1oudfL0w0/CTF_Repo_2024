<?php

return [
    'admin.addon.bing_submit_url' => '必应资源提交',
    'admin/addon/bing_submit_url' => '资源提交列表',
    'admin/addon/bing_submit_url/config' => '资源提交配置',
    'admin/addon/bing_submit_url/create' => '提交资源网址',
];
