<?php


namespace Addons\FriendLink\Models;


use App\Models\MyModel;

class FriendLink extends MyModel
{

    protected $table = 'my_friend_link';

}
