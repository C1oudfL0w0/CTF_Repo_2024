<?php

return [
    'name' => 'FriendLink'
];
