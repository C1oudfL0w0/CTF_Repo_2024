<?php

return [
    'admin.addon.friend_link' => '友情链接',
    'admin/addon/friend_link' => '链接列表',
    'admin/addon/friend_link/create' => '创建链接',
    'admin/addon/friend_link/edit' => '编辑链接',
    'admin/addon/friend_link/destroy' => '删除链接',
    'admin/addon/friend_link/config' => '链接配置',
];
