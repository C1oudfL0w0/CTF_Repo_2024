<?php

return [
    'friend_link' => [
        \Addons\FriendLink\Pipeline\FriendLinkPipeLine::class
    ]
];
