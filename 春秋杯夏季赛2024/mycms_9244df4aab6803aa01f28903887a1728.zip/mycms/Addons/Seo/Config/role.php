<?php

return [
    'admin.addon.seo' => 'SEO插件',
    'admin/addon/seo/config' => 'SEO配置',
];
