<?php

return [
    'admin.addon.sitemap' => '网站地图',
    'admin/addon/sitemap' => '生成地图',
];
