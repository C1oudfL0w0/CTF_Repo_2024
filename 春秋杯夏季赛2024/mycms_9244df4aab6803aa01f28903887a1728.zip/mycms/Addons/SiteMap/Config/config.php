<?php

return [
    'name' => 'SiteMap'
];
