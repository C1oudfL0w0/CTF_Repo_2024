<?php

return [
    'admin.addon.directmail' => '阿里云邮件推送',
    'admin/addon/directmail' => '邮件发信管理',
    'admin/addon/directmail/edit' => '编辑邮件配置',
    'admin/addon/directmail/create' => '添加邮件配置',
    'admin/addon/directmail/destroy' => '删除邮件配置',
    'admin/addon/directmail/logs' => '邮件发送记录',
];
