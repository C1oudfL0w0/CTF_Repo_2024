<?php

return array(
    'name' => 'DirectMail',
);
