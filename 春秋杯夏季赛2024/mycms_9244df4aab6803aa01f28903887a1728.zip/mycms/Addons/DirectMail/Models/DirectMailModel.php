<?php

namespace Addons\DirectMail\Models;

use App\Models\MyModel;

class DirectMailModel extends MyModel
{
    protected $table = 'my_direct_mail';

    public $timestamps = false;
}
