<?php

return [
    'url:article/admin/create:POST:200' => [
        '\Addons\LinkSubmit\Events\LinkSubmitEvent'
    ],
    'url:article/admin/edit:POST:200' => [
        '\Addons\LinkSubmit\Events\LinkSubmitEvent'
    ],
];
