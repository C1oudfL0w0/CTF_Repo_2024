<?php

return [
    'admin.addon.link_submit' => '百度资源提交',
    'admin/addon/link_submit' => '资源提交列表',
    'admin/addon/link_submit/config' => '资源提交配置',
    'admin/addon/link_submit/create' => '提交资源网址',
];
