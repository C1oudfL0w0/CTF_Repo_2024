<?php


namespace Addons\LinkSubmit\Models;


use App\Models\MyModel;

class LinkSubmit extends MyModel
{

    protected $table = 'my_link_submit_log';

}
