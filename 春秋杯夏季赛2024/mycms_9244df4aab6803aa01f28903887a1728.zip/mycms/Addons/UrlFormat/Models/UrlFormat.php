<?php


namespace Addons\UrlFormat\Models;


use App\Models\MyModel;

class UrlFormat extends MyModel
{

    protected $table = 'my_url_format';

}
