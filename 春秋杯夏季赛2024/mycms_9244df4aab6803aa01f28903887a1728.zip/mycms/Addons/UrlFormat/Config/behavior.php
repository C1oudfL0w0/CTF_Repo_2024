<?php

return [
    'tag:url_format_single:GET:200' => [
        '\Addons\UrlFormat\Events\ViewEvent',
    ],
];
