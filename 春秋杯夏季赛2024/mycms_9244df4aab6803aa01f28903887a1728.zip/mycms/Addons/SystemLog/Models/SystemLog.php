<?php


namespace Addons\SystemLog\Models;


use App\Models\MyModel;

class SystemLog extends MyModel
{

    protected $table = 'my_system_log';

}
