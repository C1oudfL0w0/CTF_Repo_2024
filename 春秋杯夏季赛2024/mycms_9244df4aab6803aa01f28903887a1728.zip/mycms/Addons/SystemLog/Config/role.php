<?php

return [
    'admin.addon.system_log' => '系统日志',
    'admin/addon/system_log' => '日志列表',
    'admin/addon/system_log/show' => '日志详情',
];
