<?php

return [
    'admin.addon.ads' => '广告插件',
    'admin/addon/ads' => '广告列表',
    'admin/addon/ads/edit' => '编辑广告',
    'admin/addon/ads/create' => '添加广告',
    'admin/addon/ads/destroy' => '删除广告',
    'admin/addon/ads/review' => '预览广告',
    'admin/addon/ads/config' => '配置广告',
];
