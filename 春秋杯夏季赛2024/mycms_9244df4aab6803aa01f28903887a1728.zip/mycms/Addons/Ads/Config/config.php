<?php

return [
    'name' => 'Ads',

    'types' => [

        'link' => '超链接',

        'image' => '图片',

        'script' => '代码',

        //'html' => '富文本',

    ]
];
