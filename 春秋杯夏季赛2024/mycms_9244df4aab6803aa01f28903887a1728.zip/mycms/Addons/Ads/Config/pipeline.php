<?php

return [
    'ad' => [
        \Addons\Ads\Pipeline\AdPipeline::class
    ]
];
