<?php


namespace Addons\Ads\Models;


use App\Models\MyModel;

class Ads extends MyModel
{

    protected $table = 'my_ads';

}
