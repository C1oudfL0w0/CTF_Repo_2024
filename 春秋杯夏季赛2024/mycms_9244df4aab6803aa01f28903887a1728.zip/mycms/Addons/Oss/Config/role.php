<?php

return [
    'admin.addon.oss' => '阿里云OSS',
    'admin/addon/oss/config' => 'OSS配置',
];
