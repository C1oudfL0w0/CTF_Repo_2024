<?php

return [
    'name' => 'MsgBoard'
];
