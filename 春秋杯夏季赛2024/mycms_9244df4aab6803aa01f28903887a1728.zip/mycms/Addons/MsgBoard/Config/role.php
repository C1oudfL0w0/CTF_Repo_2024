<?php

return [
    'admin.addon.msg_board' => '留言板',
    'admin/addon/msg_board' => '留言管理',
    'admin/addon/msg_board/edit' => '留言处理',
];
