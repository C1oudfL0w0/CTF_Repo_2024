<?php

namespace Addons\MsgBoard\Models;

use App\Models\MyModel;

class MsgBoardModel extends MyModel
{
    protected $table = 'my_message_board';
}
