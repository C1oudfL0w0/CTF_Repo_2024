<?php

return [
    'admin.addon.alisms' => '阿里云短信',
    'admin/addon/alisms' => '短信模板管理',
    'admin/addon/alisms/edit' => '编辑短信模板',
    'admin/addon/alisms/create' => '添加短信模板',
    'admin/addon/alisms/destroy' => '删除短信模板',
    'admin/addon/alisms/logs' => '短信发送记录',
];
