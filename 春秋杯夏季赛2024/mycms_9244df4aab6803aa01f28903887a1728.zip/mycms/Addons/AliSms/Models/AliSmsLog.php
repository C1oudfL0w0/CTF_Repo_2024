<?php


namespace Addons\AliSms\Models;


use App\Models\MyModel;

class AliSmsLog extends MyModel
{
    protected $table = 'my_ali_sms_log';
}
