<?php


namespace Addons\AliSms\Models;


use App\Models\MyModel;

class AliSms extends MyModel
{

    protected $table = 'my_ali_sms';

}
