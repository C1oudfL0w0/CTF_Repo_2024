<?php

return [
    'admin.addon.upgrade' => '系统更新',
    'admin/addon/upgrade' => '更新记录',
    'admin/addon/upgrade/version' => '检测更新',
];
