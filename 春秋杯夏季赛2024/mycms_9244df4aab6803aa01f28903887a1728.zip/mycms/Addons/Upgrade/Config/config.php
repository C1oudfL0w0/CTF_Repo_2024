<?php

return [
    'name' => 'Upgrade',
    'version_url' => 'https://www.mycms.net.cn/upgrade/version'
];
