<?php


namespace Addons\Upgrade\Models;


use App\Models\MyModel;

class UpgradeLog extends MyModel
{
    protected $table = 'my_upgrade_log';
}
