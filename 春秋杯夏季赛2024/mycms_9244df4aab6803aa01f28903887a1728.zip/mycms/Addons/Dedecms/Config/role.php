<?php

return [
    'admin.addon.dede' => '织梦数据',
    'admin/addon/dede' => '织梦数据列表',
    'admin/addon/dede/config' => '数据库配置',
    'admin/addon/dede/import/article' => '导入织梦文章',
    'admin/addon/dede/import/goods' => '导入织梦商品',
];
