<?php

return [
    'name' => 'Dedecms'
];
