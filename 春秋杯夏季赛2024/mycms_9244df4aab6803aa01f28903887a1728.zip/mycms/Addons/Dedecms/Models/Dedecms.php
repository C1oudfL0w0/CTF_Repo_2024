<?php


namespace Addons\Dedecms\Models;


use App\Models\MyModel;

class Dedecms extends MyModel
{
    protected $table = 'my_dedecms';
}
