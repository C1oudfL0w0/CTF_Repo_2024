<?php

return [

    'platform' => [

        'wechat' => '微信公众平台'
    ]
];
