<?php


namespace App\Models;

class Addon extends MyModel
{
    protected $table = 'my_addon';

}
