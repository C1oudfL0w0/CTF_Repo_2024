<?php
/**
 * Created by IntelliJ IDEA.
 * User: Jimersy Lee
 * Date: 2016-9-26
 * Time: 上午 1:06
 */

namespace Think;


class AjaxReturnEvent extends Exception{

}