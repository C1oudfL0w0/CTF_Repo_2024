<?php
return array(
	//'配置项'=>'配置值'
    "UNIT_TEST_NAME"=>"UnitTest"
);