function requestArticle() {
    const articleNum = document.getElementById("articleNum").value;
    const statusMessage = document.getElementById("statusMessage");
    const articlesDiv = document.getElementById("articles");

    fetch("/article", {
        method: 'POST',
        credentials: "same-origin",
        headers: {
            "Content-Type": "application/json",
        },
        body: JSON.stringify({ index: articleNum }),
    })
        .then((response) => {
            if (!response.ok) {
                return response.json().then((err) => {
                    throw err;
                });
            }
            return response.json();
        })
        .then((article) => {
            if (articlesDiv && statusMessage) {
                articlesDiv.innerHTML = `<p>${article.line1}</p><p>${article.line2}</p>`;
                statusMessage.textContent = "加载成功";
            }
        })
        .catch((error) => {
            if (statusMessage) {
                statusMessage.textContent = "加载失败";

                articlesDiv.innerHTML = error.message || "未知错误";
            }
            console.error("Error:", error);
        });
}
