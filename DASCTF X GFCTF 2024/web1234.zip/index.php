<?php
error_reporting(0);
include "class.php";

$Config = unserialize(file_get_contents("/tmp/Config"));

foreach($_POST as $key=>$value){
    if(!is_array($value)){
        $param[$key] = addslashes($value);
    }
}

if($_GET['uname'] === $Config->uname && md5(md5($_GET['passwd'])) === $Config->passwd){
    $Admin = new Admin($Config);
    if($_POST['m'] === 'edit'){
        
        $avatar['fname'] = $_FILES['avatar']['name'];
        $avatar['fdata'] = file_get_contents($_FILES['avatar']['tmp_name']);
        $nickname = $param['nickname'];
        $sex = $param['sex'];
        $mail = $param['mail'];
        $telnum = $param['telnum'];

        $Admin->editconf($avatar, $nickname, $sex, $mail, $telnum);
    }elseif($_POST['m'] === 'reset') {
        $Admin->resetconf();
    }
}else{
    die("pls login! :)");
}