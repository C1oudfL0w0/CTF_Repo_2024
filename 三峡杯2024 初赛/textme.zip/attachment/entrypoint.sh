#!/bin/bash

FLAG=${FLAG:="flag{test}"}
echo $FLAG > /flag
unset FLAG

./textme