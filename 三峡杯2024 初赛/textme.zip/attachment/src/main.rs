use std::path::PathBuf;

use crate::auth::Claims;
use auth::{AuthError, KEYS};
use axum::{
    http::StatusCode,
    response::{Html, IntoResponse, Response},
    routing::{get, post},
    Form, Router,
};
use jsonwebtoken::encode;
use jsonwebtoken::Header;
use once_cell::sync::Lazy;
use serde::Deserialize;
use tera::Context;
pub mod auth;

#[tokio::main]
async fn main() {
    tracing_subscriber::fmt::init();

    let app = Router::new()
        .route("/", get(root))
        .route("/text", post(text))
        .route("/login", post(login))
        .route("/read", post(authorization));

    let listener = tokio::net::TcpListener::bind("0.0.0.0:80").await.unwrap();
    axum::serve(listener, app).await.unwrap();
}

async fn root() -> &'static str {
    "Hello, World!"
}

#[derive(Deserialize, Debug)]
#[allow(dead_code)]
struct ReceiveLogin {
    name: String,
}

async fn login(Form(data): Form<ReceiveLogin>) -> Response {
    if data.name != "admin" {
        let claims = Claims::new(data.name);
        let token: Result<String, AuthError> = encode(&Header::default(), &claims, &KEYS.encoding)
            .map_err(|_| AuthError::TokenCreation);

        match token {
            Ok(token) => (StatusCode::OK, Html::from(token)).into_response(),
            Err(e) => e.into_response(),
        }
    } else {
        (StatusCode::OK, Html::from("NONONO".to_owned())).into_response()
    }
}

#[derive(Deserialize, Debug)]
#[allow(dead_code)]
struct ReceiveText {
    text: String,
}

const BLACK_LIST: [&str; 7] = ["{{", "}}", "FLAG", "REPLACE", "+", "__TERA_ONE_OFF", "SET"];

async fn text(Form(data): Form<ReceiveText>) -> (StatusCode, Html<String>) {
    let text = data.text;
    let check_text = text.to_ascii_uppercase();
    for word in BLACK_LIST.iter() {
        if check_text.contains(word) {
            return (StatusCode::BAD_REQUEST, Html::from("Hakcer!".to_owned()));
        }
    }
    if text.len() > 3000 {
        return (StatusCode::BAD_REQUEST, Html::from("Too long!".to_owned()));
    }

    let mut context = Context::new();
    let content = tera::Tera::one_off(&text, &mut context, true);

    match content {
        Ok(content) => (StatusCode::OK, Html::from(content)),
        Err(e) => (StatusCode::BAD_REQUEST, Html::from(e.to_string())),
    }
}

#[derive(Deserialize, Debug)]
#[allow(dead_code)]
struct ReceivePath {
    path: String,
}
const PATH_PREFIX: Lazy<PathBuf> = Lazy::new(|| PathBuf::new().join("./static"));

async fn authorization(claims: Claims, Form(data): Form<ReceivePath>) -> Response {
    if claims.username != "admin" {
        return (StatusCode::OK, Html::from("NONONO".to_owned())).into_response();
    }

    if data.path.contains("..") {
        return (StatusCode::BAD_REQUEST, Html::from("Hakcer!".to_owned())).into_response();
    }

    let path = PATH_PREFIX.join(&data.path);
    if !path.exists() {
        return (StatusCode::BAD_REQUEST, Html::from("Not found!".to_owned())).into_response();
    }
    let file_content = std::fs::read(path);

    match file_content {
        Ok(content) => (StatusCode::OK, content).into_response(),
        Err(e) => (StatusCode::BAD_REQUEST, Html::from(e.to_string())).into_response(),
    }
}
