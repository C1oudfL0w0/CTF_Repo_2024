<?php  
namespace DB;

define('DB_DSN', 'mysql:dbname=easycode;host=localhost;charset=utf8');
define('DB_USER', 'root');
define('DB_PASSWORD', 'root');
define('DB_DATABASE', 'easycode');
define('DB_PORT', '3306');
define('CHARSET', 'utf-8');

// 默认分页大小
define('DEFAULT_PAGE_SIZE', '5');
