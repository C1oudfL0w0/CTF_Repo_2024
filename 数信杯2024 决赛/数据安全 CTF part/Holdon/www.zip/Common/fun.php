<?php

require BASE_PATH . "/Lib/FileSessionHandler.php";


$handler = new FileSessionHandler();

session_set_save_handler(
    array($handler, 'open'),
    array($handler, 'close'),
    array($handler, 'read'),
    array($handler, 'write'),
    array($handler, 'destroy'),
    array($handler, 'gc')
);


ini_set('session.save_path',realpath(BASE_PATH.'/session'));




session_start();

// 注册自动加载
if(!file_exists('user_aotu_load'))
{
	function user_aotu_load($className)
	{
		$classPath = 'Lib';
		if(strrpos($className, 'Controller') !== FALSE )
		{
			$classPath = 'Controller';
		}
		else if(strrpos($className, 'Model') !== FALSE )
		{
			$classPath = 'Model';
		}
		$classPath = BASE_PATH . "/{$classPath}/{$className}.php";
		if(file_exists($classPath))
		{
			include $classPath;
		}
	}
	spl_autoload_register('user_aotu_load');
}



// 路由控制跳转至控制器
if(!empty($_REQUEST['r']))
{
	$r = explode('/', $_REQUEST['r']);
	list($controller,$action) = $r;
	$controller = "{$controller}Controller";
	$action = "action{$action}";


	if(class_exists($controller))
	{
		if(method_exists($controller,$action))
		{
			//
		}
		else
		{
			$action = "actionIndex";
		}
	}
	else
	{
		$controller = "LoginController";
        $action = "actionIndex";
	}
    $data = call_user_func(array( (new $controller), $action));
} else {
    header("Location:index.php?r=Login/Index");
}
