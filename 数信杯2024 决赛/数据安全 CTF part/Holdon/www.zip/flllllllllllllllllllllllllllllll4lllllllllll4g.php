<?php
$flag = "flag{test}";