<?php 

class DBConnect
{
    private static $_instance = null;

    public static function getInstance() 
    {
       if(is_null(self::$_instance))
		{
			// D('tableName');
			self::$_instance = new PDO( DB_DSN, DB_USER, DB_PASSWORD);
		}
		return self::$_instance;
    }
}


class DBTool
{
	private $sqlCache;
	private $tableName;
	private $connect;
    private $safe;
	public function __construct( $tableName = '')
	{
		// 连接数据库
		$this->tableName = $tableName;
		$this->connect = DBConnect::getInstance();
		$this->sqlCache = [];
	}

    //参数化
    public function prepare($sql,$param)
    {
        $result = $this->connect->prepare($sql);
        $result->bindParam(1,$param);
        $result->execute();
        echo 123;
        return $result;
    }

    public function query($sql)
    {
        $res = $this->connect->query($sql);
        return $res;
    }

    public function fetch($result, $column_name)
    {
        $data = $result->fetch();
        return $data[$column_name];
    }

    public function getPassword( $username = '')
    {
        $sql = "select * from user where username=?";
        $res = self::prepare($sql,$username);
        return self::fetch($res,"password");
    }

    public function __destruct()
    {
        // TODO: Implement __destruct() method.
        unset($this->connect);
    }
}
