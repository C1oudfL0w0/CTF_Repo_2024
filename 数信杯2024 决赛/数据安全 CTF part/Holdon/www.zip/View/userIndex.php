<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>about</title>
    <link rel="stylesheet" href="https://cdn.staticfile.org/twitter-bootstrap/3.3.7/css/bootstrap.min.css">
    <script src="https://cdn.staticfile.org/jquery/2.1.1/jquery.min.js"></script>
    <script src="https://cdn.staticfile.org/twitter-bootstrap/3.3.7/js/bootstrap.min.js"></script>
    <style>
        .fakeimg {
            height: 200px;
            background: #aaa;
        }
    </style>
</head>
<body>
<div class="jumbotron text-center" style="margin-bottom:0">
    <h1>EasyCode</h1>
</div>

<nav class="navbar navbar-inverse">
    <div class="container-fluid">
    </div>
</nav>
<div class="container">
    <div class="row">
        <div class="col-sm-4">
            <h2>关于我</h2>
            <h5>我的照片:</h5>
            <div class="fakeimg"><?php
                if(!isset($img_file)) {
                    $img_file = '/../favicon.ico';
                }

                $img_dir = dirname(__FILE__) . $img_file;
                $img_base64 = imgToBase64($img_dir);
                echo '<img src="' . $img_base64 . '">';       //图片形式展示
                ?></div>
        </div>
    </div>
</div>

</body>
</html>
<?php
function imgToBase64($img_file) {

    $img_base64 = '';
    $file_content = base64_encode(readfile($img_file));
    $img_base64 = 'data:image/' . "jpg" . ';base64,' . $file_content;
    $_SESSION["img"] = $img_file;
    return $img_base64;
}
?>
