<?php 
error_reporting(0);

#flag in web root path,but u don't know the file name;
define('BASE_PATH', __DIR__);
define('BASR_URL', "{$_SERVER['SERVER_NAME']}/");
require BASE_PATH . '/Common/config.php';
require BASE_PATH . '/Common/fun.php';
