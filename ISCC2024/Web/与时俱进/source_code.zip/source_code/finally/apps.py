from django.apps import AppConfig


class FinallyConfig(AppConfig):
    name = 'finally'
