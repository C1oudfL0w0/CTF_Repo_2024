import os
import time

from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.backends import default_backend
from cryptography.hazmat.primitives.asymmetric import padding

from django.http import FileResponse, Http404


def save_file(file, user_name, title, option, dis=''):
    file_path = os.path.join(os.getcwd(), 'user_file')
    file_name = os.listdir(file_path)
    count = 0
    for name in file_name:
        if user_name == name[:len(user_name)]:
            count += 1
    file_dir = os.path.join(file_path, f'{user_name}_{count}_{str(option)}.exe')
    with open(file_dir, 'wb') as f:
        f.write((title + '\n').encode('utf-8'))
        f.write((dis + '\n').encode('utf-8'))
        f.write(file)
    return file_dir


def count_result(file):
    f = open(file, 'r', encoding='utf-8')
    N, F = 0, 0
    mylist = f.read().splitlines()
    for line in mylist:
        blk, result = line.split(',')
        if result == '0' or result == 'Normal':
            N += 1
        else:
            F += 1
    return N, F


def load_private_key_from_pem(file_path):
    with open(file_path, 'rb') as f:
        private_key = serialization.load_pem_private_key(
            f.read(),
            password=None,
            backend=default_backend()
        )
    return private_key


def load_public_key_from_pem(file_path):
    with open(file_path, 'rb') as f:
        public_key = serialization.load_pem_public_key(
            f.read(),
            backend=default_backend()
        )
    return public_key


def get_encode(public_key, plaintext):
    plaintext = plaintext.encode('utf-8')
    ciphertext = b""

    # 计算最大可以加密的明文长度
    max_length = public_key.key_size // 8 - 11

    # 分块加密
    for i in range(0, len(plaintext), max_length):
        block = plaintext[i:i + max_length]
        encrypted_block = public_key.encrypt(block, padding.PKCS1v15())
        ciphertext += encrypted_block

    return ciphertext
