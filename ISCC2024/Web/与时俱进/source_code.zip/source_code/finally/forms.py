# 引入表单类
from django import forms
# 引入 User 模型
from django.contrib.auth.models import User


# 登录表单，继承了 forms.Form 类
class UserLoginForm(forms.Form):
    username = forms.CharField()
    password = forms.CharField()


class UserRegisterForm(forms.ModelForm):
    password = forms.CharField()
    password1 = forms.CharField()

    class Meta:
        model = User
        fields = ('username', 'email')

    # 对两次输入的密码是否一致进行检查
    def clean_password(self):
        data = self.cleaned_data
        if data.get('password') == data.get('password1'):
            return data.get('password')
        else:
            raise forms.ValidationError("密码输入不一致,请重试。")


class UserCustomForm(forms.Form):
    title = forms.CharField(label='title', max_length=30)
    dis = forms.CharField(label='content')
    file = forms.FileField(label='UploadFile')
    opt = forms.MultipleChoiceField(label='optionsRadiosinline')

