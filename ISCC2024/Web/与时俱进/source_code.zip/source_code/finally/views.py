import os
import re

import json
from django.db.models import Count
from django.shortcuts import render, redirect
from django.contrib.auth import authenticate, login, logout
from django.http import HttpResponse, StreamingHttpResponse, Http404
from .forms import UserLoginForm, UserRegisterForm, UserCustomForm
from django.contrib import messages
from django.contrib.auth.models import User
from . import function


def index(request):
    return render(request, 'index.html')


# @csrf_protect
def login_user(request):
    if request.method == 'POST':
        user_login_form = UserLoginForm(data=request.POST)
        if user_login_form.is_valid():
            # .cleaned_data 清洗出合法数据
            data = user_login_form.cleaned_data
            # 检验账号、密码是否正确匹配数据库中的某个用户
            # 如果均匹配则返回这个 user 对象
            user = authenticate(username=data['username'], password=data['password'])
            if user:
                # 将用户数据保存在 session 中，即实现了登录动作
                login(request, user)
                # return render(request, "index.html", {'username': data['username'], 'admin': 1})
                return redirect('/')
            else:
                # return HttpResponse("账号或密码输入有误。请重新输入~")
                return render(request, 'login.html', {'errors': ['账号或密码输入有误。请重新输入~']})
        else:
            # return HttpResponse("账号或密码输入不合法")
            return render(request, 'login.html', {'errors': ['账号或密码输入不合法']})
    elif request.method == 'GET':
        user_login_form = UserLoginForm()
        context = {'form': user_login_form}
        return render(request, 'login.html', context)
    else:
        return HttpResponse("请使用GET或POST请求数据")


def logout_user(request):
    logout(request)
    # return render(request, 'index.html')
    return redirect('/')


def register(request):
    if request.method == 'POST':
        user_register_form = UserRegisterForm(data=request.POST)
        data = request.POST
        if data['password'] == data['password1']:
            #     # 检验账号、密码是否正确匹配数据库中的某个用户
            #     # 如果均匹配则返回这个 user 对象
            user = authenticate(username=data['username'], password=data['password'], password1=data['password1'])
            if user:
                return render(request, 'register.html', {'errors': ['账户已存在']})
            # new_user = user_register_form.save(commit=False)
            # # 设置密码
            # new_user.set_password(data['password'])
            # new_user.save()
            # # 保存好数据后立即登录并返回博客列表页面
            new_user = User.objects.create(username=data['username'], password=data['password'])
            login(request, new_user)
            messages.success(request, '注册成功！')
            # render(request, 'register.html', {'errors': ['注册成功！']})
            return redirect('/')
        else:
            # return HttpResponse("账号或密码输入有误。请重新输入~")
            return render(request, 'register.html', {'errors': ['账号或密码输入有误。请重新输入~']})
    elif request.method == 'GET':
        user_register_form = UserRegisterForm()
        context = {'form': user_register_form}
        return render(request, 'register.html', context)
    else:
        return HttpResponse("请使用GET或POST请求数据")


def custom(request):
    user_custom_form = UserCustomForm()
    context = {'form': user_custom_form}
    if request.method == 'POST':
        post_data = request.POST
        title_data = post_data['title']

        option_data = 1 if post_data['optionsRadiosinline'] == 'option1' else 2
        file = request.FILES.get('UploadFile').read()
        if 'content' not in post_data:
            file_dir = function.save_file(file, request.user.username, title_data, option_data)
        else:
            file_dir = function.save_file(file, request.user.username, title_data, option_data, post_data['content'])
        messages.success(request, '上传成功！')
        # function.log_function(file_dir)
        return redirect('/custom')

    elif request.method == 'GET':
        user_custom_form = UserCustomForm()
        context = {'form': user_custom_form}
        return render(request, 'custom.html', context)
    else:
        return HttpResponse("请使用GET或POST请求数据")


def history(request):
    # context = {'posts': [{'author': request.user.username}, ]}
    context = function.get_all_user_file(request.user.username)
    return render(request, 'history.html', context)


def introduce(request):
    return render(request, 'introduction.html')


def bfs123(request):
    # 下载目录下的source_code.tar.gz文件
    try:
        response = StreamingHttpResponse(open('source_code.zip', 'rb'))
        response['content_type'] = "application/octet-stream"
        response['Content-Disposition'] = 'attachment; filename=' + os.path.basename('source_code.zip')
        return response
    except Exception:
        return HttpResponse("404")


def decode(request):
    if request.method == 'POST':
        post_data = request.POST.get('ciphertext', None)
        if re.match(r'^\d+$', post_data) is None:
            return HttpResponse("503")
        if post_data:
            private_key = function.load_private_key_from_pem('private_key.pem')
            ciphertext = int(post_data, 10).to_bytes(64, 'big')
            result, msg = function.get_decode(private_key, ciphertext)
            if result:
                try:
                    message = json.loads(msg)
                    if message.get('flag', None):
                        function.handel_job(message.get('msg', None))
                        return HttpResponse("200")
                except Exception:
                    return HttpResponse("400")
            else:
                return HttpResponse("400")

    return HttpResponse("200")
