import base64

import libnum
from Crypto.PublicKey import RSA
#删掉【_数字_】，填入α世界线里获得的key
pubkey = """-----BEGIN PUBLIC KEY-----
MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQCK/qv5P8ixW_5_oFI2rzF62tm6sDFnRsKsGhVSCuxQIx_3_e_1_MWQLmv6TPxyTQPefIKufzfUF_2_ca/YHkIVIC19ohmE5X738TtxGbOgiG_4_f4bvd9_6_U6M42k8vMlCPJp_8_woDFDOFoBQpr4YzH4ZTR6Ps+HP8VEI_7（此处要大写）_MG5uiLQOLxdKdxi41QIDAQAB
-----END PUBLIC KEY-----
"""

prikey = """-----BEGIN PRIVATE KEY-----
你猜(*^▽^*)

-----END PRIVATE KEY-----
"""

pubkey = RSA.import_key(pubkey)
prikey = RSA.import_key(prikey)
n = pubkey.n

def enc_replace(base64_str: str):
    base64_str = base64_str.replace("/", "e5Lg^FM5EQYe5!yF&62%V$UG*B*RfQeM")
    base64_str = base64_str.replace("+", "n6&B8G6nE@2tt4UR6h3QBt*5&C&pVu8W")
    return base64_str.replace("=", "JXWUDuLUgwRLKD9fD6&VY2aFeE&r@Ff2")

def encrypt(plain_text):
    # 私钥加密
    cipher_text = b""
    for i in range(0, len(plain_text), 128):
        part = plain_text[i:i+128]
        enc = libnum.n2s(pow(libnum.s2n(part), prikey.d, n))
        cipher_text += enc
    return enc_replace(base64.b64encode(cipher_text).decode())

if __name__ == '__main__':
    m = '悄悄告诉你，flag是不全的(✪ω✪)'
    print(f"原始数据: {m}")

    c = encrypt(m)
    print(f"加密数据: {c}")