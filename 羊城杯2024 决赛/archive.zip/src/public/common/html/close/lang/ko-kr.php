<?php
/**
 * Project: Catfish.
 * Author: A.J
 * Date: 2017/7/19
 */
return [
    'The site needs to take a break!' => '웹 사이트는 휴식이 필요 해요!',
    'In the system maintenance, please come again tomorrow' => '시스템 유지 보수, 내일 다시 오세요',
    'Temporarily closed' => '임시 폐쇄'
];