ALTER TABLE `catfish_posts` ADD `fujian` TEXT NULL AFTER `status` ;
ALTER TABLE `catfish_posts` ADD `fujianurl` TEXT NULL AFTER `fujian` ;