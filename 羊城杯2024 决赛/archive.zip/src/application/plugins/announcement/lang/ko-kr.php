<?php
/**
 * Project: Catfish.
 * Author: A.J
 * Date: 2016/12/6
 */
return [
    'Announcement' => '공고',
    'The Announcement Plugin displays a bulletin at the top of the Home page' => '공고 플러그인 홈페이지 제일 위에 있는 한 가지 공고 보이기',
    'Notice content' => '공고의 내용이',
    'Save' => '저장'
];