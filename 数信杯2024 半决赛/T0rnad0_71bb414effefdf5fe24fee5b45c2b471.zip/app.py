import json

import tornado.ioloop, tornado.web, tornado.options, os

settings = {'static_path': os.path.join(os.getcwd(), 'static')}


class Pollute:
    def __init__(self):
        pass


def merge(src, dst):
    for k, v in src.items():
        if hasattr(dst, '__getitem__'):
            if dst.get(k) and type(v) == dict:
                merge(v, dst.get(k))
            else:
                dst[k] = v
        elif hasattr(dst, k) and type(v) == dict:
            merge(v, getattr(dst, k))
        else:
            for x in ['eval', 'os', 'chr', 'class', 'compile', 'dir', 'exec', 'globals', 'help',
                      'input', 'local', 'memoryview', 'open', 'print', 'property', 'reload', 'object', 'reduce', 'repr',
                      'method', 'super', "flag", "file", "decode", "request", "builtins", "handler"]:
                if x in v:
                    return
            setattr(dst, k, v)


class IndexHandler(tornado.web.RequestHandler):

    def get(self):
        self.render("static/index.html")

    def post(self):
        msg = self.get_argument('json', '{}')
        j = json.loads(msg)
        p = Pollute()
        merge(j, p)
        self.write("SUCCESS")


def make_app():
    return tornado.web.Application([('/', IndexHandler)], **settings)


if __name__ == '__main__':
    app = make_app()
    app.listen(5000)
    tornado.ioloop.IOLoop.current().start()
