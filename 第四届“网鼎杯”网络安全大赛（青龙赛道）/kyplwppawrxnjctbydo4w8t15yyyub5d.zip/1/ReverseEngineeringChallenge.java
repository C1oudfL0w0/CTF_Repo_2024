import java.util.Scanner;

class ReverseEngineeringChallenge {
    public static void main(String args[]) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter password: ");
        String userInput = scanner.next();
        if (checkPassword(userInput)) {
            System.out.println("Access granted.");
        } else {
            System.out.println("Access denied!");
        }
    }

    public static boolean checkPassword(String password) {
        return password.length() == 20 &&
                password.charAt(0) == 'f' &&
                password.charAt(11) == '_' &&
                password.charAt(1) == 'l' &&
                password.charAt(6) == '0' &&
                password.charAt(3) == 'g' &&
                password.charAt(8) == '4' &&
                password.charAt(4) == '{' &&
                password.charAt(9) == '_' &&
                password.charAt(7) == '2' &&
                password.charAt(10) == '_' &&
                password.charAt(2) == 'a' &&
                password.charAt(12) == '_' &&
                password.charAt(5) == '2' &&
                password.charAt(17) == 'B' &&
                password.charAt(14) == '_' &&
                password.charAt(18) == '!' &&
                password.charAt(16) == '_' &&
                password.charAt(19) == '}' &&
                password.charAt(15) == 'D' &&
                password.charAt(13) == 'W';
    }
}
