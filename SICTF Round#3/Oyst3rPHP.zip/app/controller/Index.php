<?php
namespace app\controller;
use app\BaseController;

class Index extends BaseController
{

    public function index()
    {
		echo "RT，一个很简单的Web，给大家送一点分,再送三只生蚝，过年一起吃生蚝哈";
        echo "<img src='../Oyster.png'"."/>";
		
        
		$payload = base64_decode(@$_POST['payload']);
        $right = @$_GET['left'];
        $left = @$_GET['right'];
        
		$key = (string)@$_POST['key'];
        if($right !== $left && md5($right) == md5($left)){
            
			echo "Congratulations on getting your first oyster";
			echo "<img src='../Oyster1.png'"."/>";
            
			if(preg_match('/.+?THINKPHP/is', $key)){
                die("Oysters don't want you to eat");
            }
            if(stripos($key, '603THINKPHP') === false){
                die("！！！Oysters don't want you to eat！！！");
            }
			
			echo "WOW！！！Congratulations on getting your second oyster";
			echo "<img src='../Oyster2.png'"."/>";
            
			@unserialize($payload);
			//最后一个生蚝在根目录，而且里面有Flag？？？咋样去找到它呢？？？它的名字是什么？？？
			//在源码的某处注释给出了提示，这就看你是不是真懂Oyst3rphp框架咯！！！
			//小Tips：细狗函数┗|｀O′|┛ 嗷~~
        }
    }
	
	public function doLogin()
    {
    /*emmm我也不知道这是what，瞎写的*/
        if ($this->request->isPost()) {
            $username = $this->request->post('username');
            $password = $this->request->post('password');

           
            if ($username == 'your_username' && $password == 'your_password') {
          
                $this->success('Login successful', 'index/index');
            } else {
              
                $this->error('Login failed');
            }
        }
    }
	
	

}
