#!/bin/bash

echo $DASFLAG > /this_is_flag
export DASFLAG=nonono
DASFLAG=nonono