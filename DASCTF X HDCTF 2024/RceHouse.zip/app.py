
import subprocess
import clickhouse_connect
from flask import *
import os

app = Flask(__name__)
client = clickhouse_connect.get_client(host='127.0.0.1', port=8123, username='default', password='')
@app.route("/status",methods=['POST'])
def status():
    if request.method=="POST":
        remote_addr = request.remote_addr
        print(remote_addr)
        if remote_addr=='127.0.0.1':
            command = ["clickhouse-client", "--query", request.args.get('param') ]
            result = subprocess.check_output(command, stderr=subprocess.STDOUT, text=True,shell=False)
            return result
        else:
            result=os.popen(f"clickhouse-client --query=\"select 'try harder'\"").read()
            return result
    else:
        result = os.popen(f"clickhouse-client --query=\"select 'try better'\"").read()
        return result
@app.route("/sql", methods=["POST"])
def sql():
    try:
        #此处是clickhouse的查询语法，不存在注入问题
        sql = 'SELECT * FROM ctf.users WHERE id = ' + request.form.get("id")
        res=client.command(sql)
        client.close()
        return res
    except Exception as e:
        return e;
@app.route("/upload",methods=['POST'])
def upload():
    if 'file' not in request.files:
        return redirect(request.url)

    file = request.files['file']
    if file.filename == '':
        return redirect(request.url)
    filename = "Boogipop"
    file_path ="/tmp/"+filename
    file.save(file_path)
    return file_path

if __name__=="__main__":
    app.run("0.0.0.0",5000,debug=False)