from flask import Flask, request, url_for, redirect, current_app
from jinja2.sandbox import SandboxedEnvironment
from Crypto.PublicKey import RSA
from pydantic import BaseModel
from io import BytesIO
import qrcode
import base64
import json
import jwt
import os

class SaferSandboxedEnvironment(SandboxedEnvironment):
    def is_safe_attribute(self, obj, attr: str, value) -> bool:
        return True

    def is_safe_callable(self, obj) -> bool:
        return False

class Info(BaseModel):
    name: str
    avatar: str
    signature: str
    def parse_avatar(self):
        self.avatar = base64.b64encode(open('avatars/'+self.avatar,'rb').read()).decode()

def safer_render_template(template_name, **kwargs):
    env = SaferSandboxedEnvironment(loader=current_app.jinja_env.loader)
    return env.from_string(open('templates/'+template_name).read()).render(**kwargs)

app = Flask(__name__)
rsakey = RSA.generate(1024)

@app.route("/createCard", methods=["GET", "POST"])
def create_card():
    if request.method == "GET":
        return safer_render_template("create.html")
    if request.form.get('style')!=None:
        open('templates/style.css','w').write(request.form.get('style'))
    info=Info(**request.form)
    if info.avatar not in os.listdir('avatars'):
        raise FileNotFoundError
    token = jwt.encode(dict(info), rsakey.exportKey(), algorithm="RS256")
    share_url = request.url_root + url_for('show_card', token=token)
    qr_img = BytesIO()
    qrcode.make(share_url).save(qr_img,'png')
    qr_img.seek(0)
    share_img = base64.b64encode(qr_img.getvalue()).decode()
    return safer_render_template("created.html", share_url=share_url, share_img=share_img)

@app.route("/showCard", methods=["GET"])
def show_card():
    token = request.args.get("token")
    data = jwt.decode(token, rsakey.publickey().exportKey(), algorithms=jwt.algorithms.get_default_algorithms())
    info = Info(**data)
    info.parse_avatar()
    return safer_render_template("show.html", info=info)

@app.route("/", methods=["GET"])
def index():
    return redirect(url_for('create_card'))


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=8888, debug=True)