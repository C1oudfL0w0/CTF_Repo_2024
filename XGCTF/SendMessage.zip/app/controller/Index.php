<?php

namespace app\controller;

use app\BaseController;
use think\facade\Db;
use ctfshow\common\Shm_cache;

class Index extends BaseController
{
    public function index()
    {
       $cache = new Shm_cache();
       if($cache->has(0)){
            $data = $cache->get(0);
       }

       if($data){
           return "OK";
       }else{
           return "Message not found";
       }
    }



}
