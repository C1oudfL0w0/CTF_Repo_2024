<?php
// 应用公共文件
declare (strict_types = 1);
namespace ctfshow\common;

interface Cache {

    public function set(int $key,String $data);

    public function get(int $key);

    public function clear();

    public function has(int $key);

    public function remove(int $key);
    
}

class Shm_cache implements Cache{
    private $resource;
    private $shm_key;
    private $location = "/tmp/ctfshow";
    private $project = "S";

    public function __construct(){
        $this->shm_key = ftok($this->location,$this->project);
        $this->resource = shm_attach($this->shm_key);
    }
    
    public function set(int $key,string $data){
        return shm_put_var($this->resource,$key,$data);
    }

    public function get(int $key){
        return shm_get_var($this->resource,$key);
    }

    public function clear(){
        return shm_remote($this->resource);
    }

    public function has(int $key){
        return shm_has_var($this->resource,$key);
    }

    public function remove(int $key){
        return shm_remove_var($this->resource,$key);
    }

    public function __destruct(){
        shm_detach($this->resource);
    }
}