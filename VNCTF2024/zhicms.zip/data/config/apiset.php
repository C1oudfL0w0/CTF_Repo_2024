<?php
       
$api=array(
              'appKey'=>'5da7e0019b989',
			  'appSecret'=>'3761fe4fe7dcb6afaa6aa757c70ff576',
			   'Apikey'=>'',
			    'siteid'=>'',
              'hash'=>'',
        );