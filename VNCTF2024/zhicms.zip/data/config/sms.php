<?php
       
$sms=array(
            'smsurl'=>'http://api.smsbao.com/sms?u=账号&p=密码',
            'reg_sms'=>'【短信签名】您的验证码是{randcode},如果不是本人操作请不必理会！',
      );