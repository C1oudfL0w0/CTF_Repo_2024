<?php
  
         
$Siteinfo=array(
              'sitename'=>'ZhiCms[Next版]',
              'hosturl'=>'',
              'logo'=>'public/web/images/logoh2014r.png',
              'ewm'=>'public/web/images/logoh2014r.png',
              'pid'=>'',
			   'appkey'=>'',
			    'secretKey'=>'',
				'apiurl'=>'https://open.zhicms.vip/',
				'code'=>'',
              'zhuan'=>'0',
              'download'=>'',

        );