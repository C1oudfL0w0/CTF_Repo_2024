from random import *
from string import *
import numpy as np
from secret import plaintext

ls = ascii_uppercase + '_.*'

def generate_str(length):
    s = ""
    for i in range(length):
        s += choice(ls)
    return s

def str2mat(s):
    res = np.zeros((len(s) // 6, 6),dtype=int)
    for i in range(0,len(s)):
        res[i // 6, i % 6] = ls.index(s[i])
    return res

def mat2str(mat):
    s = ""
    for i in range(len(mat) * 6):
        s += ls[mat[i // 6, i % 6]]
    return s

def encrypt(plaintext,key1,key2):
    mat_plaintext = str2mat(plaintext)
    mat_key1 = str2mat(key1)
    mat_key2 = str2mat(key2)

    enc_matrix = np.dot(mat_plaintext,mat_key1) % 29
    for i in range(len(enc_matrix)):
        for j in range(len(enc_matrix[i])):
            enc_matrix[i][j] = (enc_matrix[i][j] + mat_key2[0][j]) % 29

    return mat2str(enc_matrix)

if __name__ == "__main__":

    assert len(plaintext) == 72
    m = generate_str(48)
    key1 = generate_str(36)
    key2 = generate_str(6)
    c = encrypt(m, key1, key2)
    ciphertext = encrypt(plaintext, key1, key2)

    '''
    flag = "begin{" + hashlib.md5(plaintext.encode()).hexdigest() + "}"
    '''

    print(f"m = {m}")
    print(f"c = {c}")
    print(f"ciphertext = {ciphertext}")


'''
output:
m = VOWAS*TED.AE_UMLVFV*W*HSSSTZIZZZDAKCLXZKM_E*VR*Y
c = QLOKQGUWMUTGZSDINCQVIVOLISFB_FC.IC_OSPLOBGOVSCZY
ciphertext = MHDTBJSZXLHH.Z.VWGLXUV.SDQUPAMEPNVQVQZX_CBDZHM_IBZRGLJP_YSBDXN.VACLDGCO_
'''