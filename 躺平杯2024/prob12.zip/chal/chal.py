from Crypto.Util.number import *

p = getPrime(512)
q = getPrime(512)
n = p*q
e = bytes_to_long(b"too desperate!")
flag = bytes_to_long(b"flag{fake_flag}")

ct = pow(flag, e, n)

with open("data.txt","w") as f:
    f.write(f"ct = {ct}\nn = {n}\np_add_q = {((p+q)>>60)<<60}")

