# 迅睿CMS建站程序

迅睿CMS框架是一款PHP8高性能·简单易用的开发框架
支持的微信公众号，小程序，APP客户端，移动端网站，PC网站等多站式管理系统。



#### 运行环境
PHP7.3以上（支持PHP8）
MySQL5以上，推荐5.7及以上
Apache、Nginx、IIS等Web服务器都可以

#### 在线预览
http://demo4.xunruicms.com/admin.php


#### 安装教程

1. 将代码下载到网站的根目录
2. 运行环境检查程序 /test.php
3. 环境通过后，运行安装文件 /install.php
4. 切忌不要放在子目录安装
5. 默认后台入口文件是 /admin.php

#### 使用说明

1. 使用文档：https://www.xunruicms.com/doc/
2. 技术论坛：https://www.xunruicms.com/wenda/
3. 正式版程序下载：https://www.xunruicms.com/down/
