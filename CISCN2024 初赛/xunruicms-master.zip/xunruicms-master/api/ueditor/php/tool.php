<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/* 在后台设置的【完整】模式下，工具栏上的所有的功能按钮和下拉框 */

return '
  "undo","redo","|"
  ,"bold","italic","underline","fontborder","strikethrough","superscript","subscript","removeformat","formatmatch","autotypeset","blockquote","pasteplain","|"
  ,"forecolor","backcolor","insertorderedlist","insertunorderedlist","selectall","cleardoc","|"
  ,"rowspacingtop","rowspacingbottom","lineheight","|"
  , "customstyle","paragraph","fontfamily","fontsize","|"
  ,"directionalityltr","directionalityrtl","indent","|"
  ,"justifyleft","justifycenter","justifyright","justifyjustify","|"
  ,"touppercase","tolowercase","|"
  ,"link","unlink","anchor","|"
  ,"imagenone","imageleft","imageright","imagecenter", "|"
  ,"simpleupload","insertimage","emotion","scrawl","insertvideo","attachment","map","insertframe","insertcode","template","|"
  ,"horizontal","date","time","spechars","|"
  ,"inserttable","deletetable","insertparagraphbeforetable","insertrow","deleterow","insertcol","deletecol","mergecells","mergeright","mergedown","splittocells","splittorows","splittocols","charts","|"
  ,"print","preview","searchreplace","drafts"
';