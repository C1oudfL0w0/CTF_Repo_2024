此目录属于迅睿框架核心程序目录，禁止修改和新建文件，会引起系统的不稳定
二次开发注意：http://help.xunruicms.com/491.html