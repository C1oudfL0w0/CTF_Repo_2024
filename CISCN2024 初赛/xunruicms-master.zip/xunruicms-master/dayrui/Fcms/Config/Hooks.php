<?php
/**
 * 此文件已被废除，自定义钩子请写在更目录下的：config/hooks.php 文件中
 */