<?php namespace Phpcmf\Model;
/**
 * {{www.xunruicms.com}}
 * {{迅睿内容管理框架系统}}
 * 本文件是框架系统文件，二次开发时不可以修改本文件，可以通过继承类方法来重写此文件
 **/

class Site extends \Phpcmf\Model
{
    // 设置风格
    public function set_theme($name, $siteid) {

        $site = $this->table('site')->get($siteid);
        if (!$site) {
            return [];
        }

        $site['setting'] = dr_string2array($site['setting']);
        $site['setting']['config']['SITE_THEME'] = $name;

        $this->table('site')->update($siteid, [
            'setting' => dr_array2string($site['setting']),
        ]);
    }

    // 设置模板
    public function set_template($name, $siteid) {

        $site = $this->table('site')->get($siteid);
        if (!$site) {
            return [];
        }

        $site['setting'] = dr_string2array($site['setting']);
        $site['setting']['config']['SITE_TEMPLATE'] = $name;

        $this->table('site')->update($siteid, [
            'setting' => dr_array2string($site['setting']),
        ]);
    }

    // 获取网站配置
    public function config($siteid, $name = '', $data = []) {

        !$siteid && $siteid = SITE_ID;
        $site = $this->table('site')->get($siteid);
        if (!$site) {
            return [];
        }

        $site['setting'] = dr_string2array($site['setting']);
        $site['setting']['config']['SITE_NAME'] = $site['name'];
        $site['setting']['config']['SITE_DOMAIN'] = strtolower($site['domain']);

        if ($name && $data) {
            // 更新数据
            if ($data['SITE_NAME']) {
                $site['name'] = $data['SITE_NAME'];
            }
            if ($data['SITE_DOMAIN']) {
                $site['domain'] = $data['SITE_DOMAIN'];
            }
            $site['setting'][$name] = $data;
            $this->table('site')->update($siteid, [
                'name' => $site['name'],
                'domain' => strtolower($site['domain']),
                'setting' => dr_array2string($site['setting']),
            ]);
        }

        return $site['setting'];
    }

    // 存储网站配置
    public function save_config($siteid, $name, $data) {

        !$siteid && $siteid = SITE_ID;
        $site = $this->table('site')->get($siteid);
        if (!$site) {
            return [];
        }

        $site['setting'] = dr_string2array($site['setting']);
        $site['setting']['config']['SITE_NAME'] = $site['name'];
        $site['setting']['config']['SITE_DOMAIN'] = strtolower($site['domain']);

        // 更新数据
        if ($data['SITE_NAME']) {
            $site['name'] = $data['SITE_NAME'];
        }
        if ($data['SITE_DOMAIN']) {
            $site['domain'] = $data['SITE_DOMAIN'];
        }
        $site['setting'][$name] = $data;
        $this->table('site')->update($siteid, [
            'name' => $site['name'],
            'domain' => strtolower($site['domain']),
            'setting' => dr_array2string($site['setting']),
        ]);

        return $site['setting'];
    }

    // 设置网站单个配置
    public function config_value($siteid, $group, $value) {

        !$siteid && $siteid = SITE_ID;
        $site = $this->table('site')->get($siteid);
        if (!$site || !$value) {
            return;
        }

        $site['setting'] = dr_string2array($site['setting']);

        foreach ($value as $n => $v) {
            $site['setting'][$group][$n] = $v;
        }

        $this->table('site')->update($siteid, [
            'setting' => dr_array2string($site['setting']),
        ]);

        return;
    }

    // 新增
    public function create($data) {

        $this->db->table('site')->replace([
            'name' => $data['name'],
            'domain' => (string)$data['domain'],
            'setting' => dr_array2string([
                'webpath' => $data['webpath'],
            ]),
            'disabled' => 0,
            'displayorder' => 0,
        ]);

        $siteid = $this->db->insertID();

        \Phpcmf\Service::M('Table')->create_site($siteid);

        if ($siteid == 1) {
            return; // 安装不执行后面操作
        }

        if (is_file(MYPATH.'Config/Install_site.sql')) {
            $s = file_get_contents(MYPATH.'Config/Install_site.sql');
            $sql = str_replace('{dbprefix}', $this->prefix.$siteid.'_', $s);
            $this->query_all($sql);
        }

        // 创建
        if (is_file(MYPATH.'Config/Install.php')) {
            require MYPATH.'Config/Install.php';
        }

        // 应用插件
        $local = dr_dir_map(APPSPATH, 1);
        foreach ($local as $dir) {
            if (is_file(APPSPATH.$dir.'/install.lock')
                && is_file(APPSPATH.$dir.'/Config/App.php')
                && is_file(APPSPATH.$dir.'/Config/Install_site.sql')) {
                $cfg = require APPSPATH.$dir.'/Config/App.php';
                if ($cfg['type'] != 'module') {
                    // 这是插件
                    $sql = file_get_contents(APPSPATH.$dir.'/Config/Install_site.sql');
                    $this->query_all(str_replace('{dbprefix}',  $this->dbprefix($siteid.'_'), $sql));
                } else {
                    // 这是模块
                }
            }
        }

        \Phpcmf\Service::M('cache')->update_webpath('Web', $data['webpath'], [
            'SITE_ID' => $siteid
        ]);
    }

    // 变更主域名
    public function edit_domain($value) {

        $site = $this->config(1);
        $this->db->table('site')->where('id', 1)->update([
            'domain' => strtolower($value),
            'setting' => dr_array2string($site),
        ]);
        // 替换栏目编辑器域名
        $this->db->query('UPDATE `'.$this->dbprefix('1_share_category').'` SET `content`=REPLACE(`content`, \''.$site['config']['SITE_DOMAIN'].'\', \''.$value.'\')');
    }

    // 设置域名
    public function domain($value = []) {

        $data = [];
        $site = $this->config(SITE_ID);
        if ($value) {

            $site['webpath'] = $value['webpath'];
            $this->db->table('site')->where('id', SITE_ID)->update([
                'domain' => strtolower($value['site_domain'] ? $value['site_domain'] : $site['domain']),
                'setting' => dr_array2string($site),
            ]);
        }

        $data['webpath'] = $site['webpath'];
        $data['site_domain'] = strtolower($site['config']['SITE_DOMAIN']);

        // 识别手机域名
        if (isset($site['mobile']['mode']) && $site['mobile']['mode']) {
            $data['mobile_domain'] = $site['config']['SITE_DOMAIN'].'/'.trim($site['mobile']['dirname'] ? $site['mobile']['dirname'] : 'mobile');
        } else {
            $data['mobile_domain'] = $site['mobile']['domain'];
        }

        if ($site['client']) {
            foreach ($site['client'] as $c) {
                if ($c['name'] && $c['domain']) {
                    $data['client_'.$c['name']] = $c['domain'];
                }
            }
        }

        // 用户中心域名
        /*
        if (dr_is_app('member')) {
            $member = $this->db->table('member_setting')->where('name', 'domain')->get()->getRowArray();
            $member && $member['value'] = dr_string2array($member['value']);
            if ($value) {
                $member['value'][SITE_ID]['domain'] = $value['member_domain'];
                $member['value'][SITE_ID]['mobile_domain'] = $value['member_mobile_domain'];
                $this->db->table('member_setting')->replace([
                    'name' => 'domain',
                    'value' => dr_array2string($member['value'])
                ]);
            }
            $data['member_domain'] = $member['value'][SITE_ID]['domain'];
            $data['member_mobile_domain'] = $member['value'][SITE_ID]['mobile_domain'];
        }*/

        // 模块域名
        $my = [];
        $module = $this->table('module')->getAll();
        foreach ($module as $t) {
            if (!is_file(APPSPATH.ucfirst($t['dirname']).'/Config/App.php')) {
                continue;
            }
            $cfg = require APPSPATH.ucfirst($t['dirname']).'/Config/App.php';
            $t['site'] = dr_string2array($t['site']);
            $my[$t['dirname']] = [
                'share' => $t['share'],
                'name' => dr_lang($cfg['name']),
                'error' => '',
            ];
            if ($t['share']) {
                $my[$t['dirname']]['error'] = dr_lang('共享模块不支持绑定');
                continue;
            }
            if ($t['site'][SITE_ID]) {
                if ($value) {
                    $t['site'][SITE_ID]['domain'] = strtolower($value['module_'.$t['dirname']]);
                    $t['site'][SITE_ID]['mobile_domain'] = $value['module_mobile_'.$t['dirname']];
                    $t['site'][SITE_ID]['webpath'] = $value['webpath_'.$t['dirname']];
                    $this->db->table('module')->where('id', $t['id'])->update([
                        'site' => dr_array2string($t['site'])
                    ]);
                }
                $data['module_'.$t['dirname']] = strtolower($t['site'][SITE_ID]['domain']);
                $data['module_mobile_'.$t['dirname']] = strtolower($t['site'][SITE_ID]['mobile_domain']);
                $data['webpath_'.$t['dirname']] = $t['site'][SITE_ID]['webpath'];
            } else {
                $my[$t['dirname']]['error'] = dr_lang('当前站点未安装');
            }
        }

        return [$my, $data];
    }


    // 站点缓存缓存
    public function cache($siteid = null, $data = null, $module = null) {

        !$data && $data = $this->table('site')->where('disabled', 0)->order_by('displayorder ASC,id ASC')->getAll();
        $sso_domain = $client_name = $client_domain = $webpath = $app_domain = $site_domain = $config = $cache = [];
        if ($data) {
            $module_cache_file = []; // 删除多余的模块缓存文件
            foreach ($data as $t) {
                if ($t['id'] > 1 && !dr_is_app('sites')) {
                    break;
                }

                $t['setting'] = dr_string2array($t['setting']);
                $mobile_dirname = 'mobile';

                // 识别手机域名
                if (isset($t['setting']['mobile']['mode']) && $t['setting']['mobile']['mode']) {
                    $mobile_dirname = trim($t['setting']['mobile']['dirname'] ? $t['setting']['mobile']['dirname'] : 'mobile');
                    $mobile_domain = $t['domain'].'/'.$mobile_dirname;
                } else {
                    $mobile_domain = (string)$t['setting']['mobile']['domain'];
                }

                $config[$t['id']] = [
                    'SITE_NAME' => $t['name'],
                    'SITE_DOMAIN' => strtolower($t['domain']),
                    'SITE_LOGO' => $t['setting']['config']['logo'] ? dr_get_file($t['setting']['config']['logo']) : ROOT_THEME_PATH.'assets/logo-web.png',
                    'SITE_MOBILE' => $mobile_domain,
                    'SITE_MOBILE_DIR' => $mobile_dirname,
                    'SITE_AUTO' => (string)$t['setting']['mobile']['auto'],
                    'SITE_IS_MOBILE_HTML' => (string)$t['setting']['mobile']['tohtml'],
                    'SITE_MOBILE_NOT_PAD' => (string)$t['setting']['mobile']['not_pad'],
                    'SITE_CLOSE' => $t['setting']['config']['SITE_CLOSE'],
                    'SITE_THEME' => $t['setting']['config']['SITE_THEME'],
                    'SITE_TEMPLATE' => $t['setting']['config']['SITE_TEMPLATE'],
                    'SITE_REWRITE' => $t['setting']['seo']['SITE_REWRITE'],
                    'SITE_SEOJOIN' => $t['setting']['seo']['SITE_SEOJOIN'],
                    'SITE_LANGUAGE' => $t['setting']['config']['SITE_LANGUAGE'],
                    'SITE_TIMEZONE' => $t['setting']['config']['SITE_TIMEZONE'],
                    'SITE_TIME_FORMAT' => $t['setting']['config']['SITE_TIME_FORMAT'],
                    'SITE_INDEX_HTML' => (string)$t['setting']['config']['SITE_INDEX_HTML'],
                    'SITE_THUMB_WATERMARK' => (int)$t['setting']['watermark']['thumb'],
                ];
                unset($t['setting']['mobile']['auto'],
                    $t['setting']['mobile']['domain'],
                    $t['setting']['seo']['SITE_REWRITE'],
                    $t['setting']['seo']['SITE_SEOJOIN'],
                    $t['setting']['config']['SITE_THEME'],
                    $t['setting']['config']['SITE_TEMPLATE'],
                    $t['setting']['config']['SITE_LANGUAGE'],
                    $t['setting']['config']['SITE_TIME_FORMAT'],
                    $t['setting']['config']['SITE_NAME'],
                    $t['setting']['config']['SITE_TIMEZONE'],
                    $t['setting']['config']['SITE_DOMAIN'],
                    $t['setting']['config']['SITE_CLOSE']
                );
                // 本站的全部域名归属
                $site_domain[$t['domain']] = $t['id'];
                $sso_domain[] = $t['domain'];
                if ($config[$t['id']]['SITE_MOBILE']) {
                    $site_domain[$config[$t['id']]['SITE_MOBILE']] = $t['id'];
                    $client_domain[$t['domain']] = $config[$t['id']]['SITE_MOBILE'];
                    $sso_domain[] = $config[$t['id']]['SITE_MOBILE'];
                }
                // 自定义终端
                if ($t['setting']['client']) {
                    $_save = [];
                    foreach ($t['setting']['client'] as $c) {
                        $site_domain[$c['domain']] = $t['id'];
                        $_save[$c['name']] = $sso_domain[] = $c['domain'];
                    }
                    $cache[$t['id']]['client'] = $_save;
                }

                // 网站路径
                $webpath[$t['id']] = [
                    'site' => ROOTPATH,
                ];
                if ($t['id'] > 1 && $t['setting']['webpath']) {
                    $webpath[$t['id']]['site'] = dr_get_dir_path($t['setting']['webpath']);
                    if (!is_dir($webpath[$t['id']]['site'])) {
                        log_message('error', '多站点：站点【'.$t['id'].'】目录【'.$webpath[$t['id']]['site'].'】不存在');
                        unset($cache[$t['id']]);
                        continue;
                    }
                }

                // 自定义站点字段
                $field = \Phpcmf\Service::M('field')->get_mysite_field($t['id']);
                if ($field && $t['setting']['param']) {
                    $t['setting']['param'] = \Phpcmf\Service::L('Field')->app('')->format_value($field, $t['setting']['param'], 1);
                }

                // 删除首页静态文件
                unlink($webpath[$t['id']]['site'].'index.html');
                unlink($webpath[$t['id']]['site'].$mobile_dirname.'/index.html');

                $module_cache_file[] = 'module-'.$t['id'].'-content.cache'; // 删除多余的模块缓存文件
                $module_cache_file[] = 'module-'.$t['id'].'-share.cache'; // 删除多余的模块缓存文件
                $module_cache_file[] = 'module-'.$t['id'].'.cache'; // 删除多余的模块缓存文件
                $cache[$t['id']] = $t['setting'];
            }

            // 循环模块域名
            !$module && $module = $this->table('module')->getAll();
            if ($module) {
                foreach ($module as $t) {
                    if (!is_file(APPSPATH.ucfirst($t['dirname']).'/Config/App.php')) {
                        continue;
                    }
                    $t['site'] = dr_string2array($t['site']);
                    if (!$t['site']) {
                        // 表示没有进行站点安装
                        continue;
                    }
                    // 循环站点信息
                    foreach ($t['site'] as $sid => $v) {
                        if (!$t['share']) {
                            // 独立模块才有域名
                            $webpath[$sid][$t['dirname']] = $webpath[$sid]['site'];
                            if ($v['domain']) {
                                $site_domain[$v['domain']] = $sid;
                                $app_domain[$v['domain']] = $t['dirname'];
                                $sso_domain[] = $v['domain'];
                                // 网站路径
                                if ($v['webpath']) {
                                    $webpath[$sid][$t['dirname']] = dr_get_dir_path($v['webpath']);
                                }
                            }
                            if ($v['mobile_domain']) {
                                $site_domain[$v['mobile_domain']] = $sid;
                                $app_domain[$v['mobile_domain']] = $t['dirname'];
                                $client_domain[$v['domain']] = $v['mobile_domain'];
                                $sso_domain[] = $v['mobile_domain'];
                            }
                        }
                        $module_cache_file[] = 'module-'.$sid.'-'.$t['dirname'].'.cache'; // 删除多余的模块缓存文件
                    }
                }
            }
            // 删除多余的模块缓存文件
            if ($fp = @opendir(WRITEPATH.'data')) {
                while (FALSE !== ($file = readdir($fp))) {
                    $pos = strpos($file, 'module-');
                    if ($pos !== false && $pos === 0 && !dr_in_array($file, $module_cache_file)) {
                        unlink(WRITEPATH.'data/'.$file);
                    }
                }
                closedir($fp);
            }
        }

        \Phpcmf\Service::L('Cache')->set_file('site', $cache);
        \Phpcmf\Service::L('Config')->file(WRITEPATH.'config/site.php', '站点配置文件', 32)->to_require($config);
        \Phpcmf\Service::L('Config')->file(WRITEPATH.'config/domain_sso.php', '同步域名配置文件', 32)->to_require_one($sso_domain);
        \Phpcmf\Service::L('Config')->file(WRITEPATH.'config/domain_app.php', '项目域名配置文件', 32)->to_require_one($app_domain);
        \Phpcmf\Service::L('Config')->file(WRITEPATH.'config/domain_site.php', '站点域名配置文件', 32)->to_require_one($site_domain);
        \Phpcmf\Service::L('Config')->file(WRITEPATH.'config/domain_client.php', '客户端域名配置文件', 32)->to_require_one($client_domain);
        \Phpcmf\Service::L('Config')->file(WRITEPATH.'config/webpath.php', '入口文件目录配置文件', 32)->to_require($webpath);
    }
}