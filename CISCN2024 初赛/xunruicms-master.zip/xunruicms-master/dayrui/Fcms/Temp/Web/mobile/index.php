<?php

/**
 * Cms 移动端入口程序
 */

define('IS_MOBILE', 1);
define('FIX_WEB_DIR', '{FIX_WEB_DIR}');

// 执行主程序
require '../index.php';