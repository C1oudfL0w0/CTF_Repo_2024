<?php

return [

    'id' => '1000',
    'vip' => '0',
    'cms' => '4.6.2',
    'version' => '1.1',
    'license' => '',
    'updatetime' => '2024-02-21 16:01:45',
    'downtime' => '2024-05-17 17:22:46',

];
