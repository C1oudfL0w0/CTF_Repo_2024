<?php

return [

    'id' => '784',
    'vip' => '0',
    'cms' => '4.6.2',
    'version' => '2.13',
    'license' => '',
    'updatetime' => '2024-04-15 12:02:18',
    'downtime' => '2024-05-17 17:22:46',

];
