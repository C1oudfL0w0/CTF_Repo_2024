<?php

return [

    'type' => 'app',
    'name' => '用户系统',
    'author' => '迅睿云软件',
    'icon' => 'fa fa-user',
    'uri' => 'member/home/index'

];