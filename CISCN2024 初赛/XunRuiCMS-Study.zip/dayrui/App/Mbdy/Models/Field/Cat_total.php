{php $mymid=$value;}{count action=module module=$mymid catid=$fixid return=mmm}{$mmm_count}
调试数据：{$debug_count}
