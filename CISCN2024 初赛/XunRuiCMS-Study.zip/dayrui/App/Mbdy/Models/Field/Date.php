默认输出：{$value}
=======自定义时间=========
2020-10-30：{dr_date($time, 'Y-m-d')}
2020：{dr_date($time, 'Y')}
10：{dr_date($time, 'm')}
30：{dr_date($time, 'd')}
===========
友好的时间：{dr_fdate($time)}