默认输出：{$value}
自定义时间：{dr_date($time, 'Y-m-d')}
友好的时间：{dr_fdate($time)}

如果不行的话，用这种

默认输出：{$value}
自定义时间：{dr_date($value, 'Y-m-d')}
友好的时间：{dr_fdate($value)}