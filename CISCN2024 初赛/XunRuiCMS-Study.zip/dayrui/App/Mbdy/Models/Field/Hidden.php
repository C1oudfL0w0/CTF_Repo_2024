普通输出：{$value}
截取10个字输出：{dr_strcut($value, 10, '...')}