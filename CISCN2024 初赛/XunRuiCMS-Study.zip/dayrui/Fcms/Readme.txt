此目录属于迅睿框架核心程序目录，禁止修改和新建文件，会引起系统的不稳定
二次开发注意：http://help.xunruicms.com/491.html

Config          配置相关文件
Control         控制器文件
Core            核心文件及函数库
Field           自定义字段
Library         系统类库文件
Model           系统模型文件
Temp            临时文件夹
View            后台模板文件