<?php

// CI路由识别定向文件 兼容老版本
require FRAMEPATH.'Config/Routes.php';