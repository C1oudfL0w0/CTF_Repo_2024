
迅睿CMS官方下载地址：https://www.xunruicms.com/down/


#### 安装路径
将网站运行目录（主目录）设置为：public（如果没有就忽略设置）
安装环境监测：/test.php
程序安装地址：/install.php
后台登录地址：/admin****.php（****是随机的）
重置后台地址：https://www.xunruicms.com/doc/1097.html
首次使用方法：https://www.xunruicms.com/doc/631.html

#### 运行环境

Laravel内核：PHP8.0及以上
ThinkPHP内核：PHP7.4及以上
CodeIgniter内核：PHP7.4及以上
CodeIgniter72内核：PHP7.2及以上

MySQL数据库：MySQL5及以上，推荐5.7及以上


#### 内核切换方法
https://www.xunruicms.com/doc/1246.html