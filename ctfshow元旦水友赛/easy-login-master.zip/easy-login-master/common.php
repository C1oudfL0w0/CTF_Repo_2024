<?php

/*
# -*- coding: utf-8 -*-
# @Author: h1xa
# @Date:   2023-08-08 00:12:34
# @Last Modified by:   h1xa
# @Last Modified time: 2023-08-08 00:26:48
# @email: h1xa@ctfer.com
# @link: https://ctfer.com

*/

class user{
    public $id;
    public $username;
    private $password;

    public function __toString(){
        return $this->username;
    }


}

class cookie_helper{
    private $secret = "*************"; //敏感信息打码

    public  function getCookie($name){
        return $this->verify($_COOKIE[$name]);

    }

    public function setCookie($name,$value){
        $data = $value."|".md5($this->secret.$value);
        setcookie($name,$data);
    }

    private function verify($cookie){
        $data = explode('|',$cookie);
        if (count($data) != 2) {
            return null;
        }
        return md5($this->secret.$data[0])=== $data[1]?$data[0]:null;
    }
}


class mysql_helper{
    private $db;
    public $option = array(
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION
    );

    public function __construct(){
        $this->init();
    }

    public function __wakeup(){
        $this->init();
    }


    private function init(){
        $this->db = array(
            'dsn' => 'mysql:host=127.0.0.1;dbname=blog;port=3306;charset=utf8',
            'host' => '127.0.0.1',
            'port' => '3306',
            'dbname' => '****', //敏感信息打码
            'username' => '****',//敏感信息打码
            'password' => '****',//敏感信息打码
            'charset' => 'utf8',
        );
    }

    public function get_pdo(){
        try{
            $pdo = new PDO($this->db['dsn'], $this->db['username'], $this->db['password'], $this->option);
        }catch(PDOException $e){
            die('数据库连接失败:' . $e->getMessage());
        }
    
        return $pdo;
    }

}

class application{
    public $cookie;
    public $mysql;
    public $dispather;
    public $loger;
    public $debug=false;

    public function __construct(){
        $this->cookie = new cookie_helper();
        $this->mysql = new mysql_helper();
        $this->dispatcher = new dispatcher();
        $this->loger = new userLogger();
        $this->loger->setLogFileName("log.txt");
    }

    public function register($username,$password){
        $this->loger->user_register($username,$password);
        $pdo = $this->mysql;
        $sql = "insert into user(username,password) values(?,?)";
        $pdo = $this->mysql->get_pdo();
        $stmt = $pdo->prepare($sql);
        $stmt->execute(array($username,$password));
        return $pdo->lastInsertId() > 0;
    }

    public function login($username,$password){
        $this->loger->user_login($username,$password);
        $sql = "select id,username,password from user where username = ? and password = ?";
        $pdo = $this->mysql->get_pdo();
        $stmt = $pdo->prepare($sql);
        $stmt->execute(array($username,$password));
        $ret = $stmt->fetch();
        return $ret['password']===$password;

    }
    public function getLoginName($name){
        $data = $this->cookie->getCookie($name);
        if($data === NULL && isset($_GET['token'])){
            session_decode($_GET['token']);
            $data = $_SESSION['user'];
        }
        return $data;
    }

    public function logout(){
        $this->loger->user_logout();
        setCookie("user",NULL);
    }

    private function log_last_user(){
        $sql = "select username,password from user order by id desc limit 1";
        $pdo = $this->mysql->get_pdo();
        $stmt = $pdo->prepare($sql);
        $stmt->execute();
        $ret = $stmt->fetch();
    }
    public function __destruct(){
       if($this->debug){
            $this->log_last_user();
       }
    }

}

class userLogger{

    public $username;
    private $password;
    private $filename;

    public function __construct(){
        $this->filename = "log.txt_$this->username-$this->password";
        $data = "最后操作时间：".date("Y-m-d H:i:s")." 用户名 $this->username 密码 $this->password \n";
        $d = file_put_contents($this->filename,$data,FILE_APPEND);
    }
    public function setLogFileName($filename){
        $this->filename = $filename;
    }

    public function __wakeup(){
        $this->filename = "log.txt";
    }
    public function user_register($username,$password){
        $this->username = $username;
        $this->password = $password;
        $data = "操作时间：".date("Y-m-d H:i:s")."用户注册： 用户名 $username 密码 $password\n";
        file_put_contents($this->filename,$data,FILE_APPEND);
    }

    public function user_login($username,$password){
        $this->username = $username;
        $this->password = $password;
        $data = "操作时间：".date("Y-m-d H:i:s")."用户登陆： 用户名 $username 密码 $password\n";
        file_put_contents($this->filename,$data,FILE_APPEND);
    }

    public function user_logout(){
        $data = "操作时间：".date("Y-m-d H:i:s")."用户退出： 用户名 $this->username\n";
        file_put_contents($this->filename,$data,FILE_APPEND);
    }

    // public function __destruct(){
    //     $data = "最后操作时间：".date("Y-m-d H:i:s")." 用户名 $this->username 密码 $this->password \n";
    //     $d = file_put_contents($this->filename,$data,FILE_APPEND);
        
    // }
}
class dispatcher{

    public function sendMessage($msg){
        echo "<script>alert('$msg');window.history.back();</script>";
    }
    public function redirect($route){

        switch($route){
            case 'login':
                header("location:index.php?action=login");
                break;
            case 'register':
                header("location:index.php?action=register");
                break;
            default:
                header("location:index.php?action=main");
                break;
        }
    }
}









