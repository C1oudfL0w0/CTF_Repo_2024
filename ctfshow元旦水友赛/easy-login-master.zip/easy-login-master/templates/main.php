<?php

$name =  $app->getLoginName('user');

if($name){
    echo "恭喜你登陆成功 <a href='/index.php?action=logout'>退出登陆</a>";
}else{
    include 'login.html';
}



