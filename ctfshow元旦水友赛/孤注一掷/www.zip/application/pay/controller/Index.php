<?php

namespace app\pay\controller;

use think\Db;
use think\Request;
use think\Controller;
use app\common\controller\Frontend;
use app\common\library\Token;

class Index extends Controller
{
    public function index(Request $request)
    {
        $get=$request->get();
        if ($get) {
            $money=$get['total_fee'];
            $trade_no=$get['out_trade_no'];
            $type=$get['pay'];
            $total_fee=number_format($money,2,'.','');
            $uid=session("userid");
            $user=Db::name('user')->where('id', $uid)->find();
            $url=Db::name('config')->where('name', "gameurl")->find();
            Db::commit();


            $appid=Db::name('config')->where('name', "xsid")->find();
            $key=Db::name('config')->where('name', "xskey")->find();
            $payurl=Db::name('config')->where('name', "xsurl")->find();
            $payurl=$payurl['value'];
            $appid=$appid['value'];
            $key=$key['value'];

            $paydata=array();
            $paydata['uid']=$uid;//支付用户id,如果没有可以填写ip,不要填写随机数
            $paydata['order_no']=$trade_no;//订单号
            $paydata['total_fee']=$total_fee;//金额
            $paydata['param']="";//其他参数
            $paydata['me_back_url']="http://".$_SERVER['HTTP_HOST']."/index/index";//支付成功后跳转
            $paydata['notify_url']="http://".$_SERVER['HTTP_HOST']."/pay/index/aipay";//支付成功后异步回调

ini_set("error_reporting","E_ALL & ~E_NOTICE");
$uid = $appid;//商户id
$key = $key;//通讯密钥
$returnUrl="http://".$_SERVER['HTTP_HOST']."/index/index";//支付成功后跳转
$notifyUrl="http://".$_SERVER['HTTP_HOST']."/pay/index/aipay";//支付成功后异步回调
$payid = $trade_no;//订单号
$param = $uid;//自定义参数
$type = 2;
$price = $total_fee;
$host = $payurl;//订单提交网关地址

$sign = md5($payid.$param.$type.$price.$key);//sign签名
$p = "uid=".$uid."&payId=".$payid.'&returnUrl='.$returnUrl.'&notifyUrl='.$notifyUrl.'&param='.$param.'&type='.$type."&price=".$price.'&sign='.$sign.'&isHtml=1';//拼接参数

echo "<script>window.location.href = '".$host."?".$p."'</script>";//提交订单
            /*$geturl=fastpay_order($paydata, "http");//获取支付链接，可以传入https
            exit("<meta http-equiv='Refresh' content='0;URL={$geturl}'>");


            $this->assign('version', $version);
            $this->assign('customerid', $customerid);
            $this->assign('userkey', $userkey);
            $this->assign('sdorderno', $sdorderno);
            $this->assign('total_fee', $total_fee);
            $this->assign('paytype', $paytype);
            $this->assign('bankcode', $bankcode);
            $this->assign('notifyurl', $notifyurl);
            $this->assign('returnurl', $returnurl);
            $this->assign('remark', $remark);
            $this->assign('get_code', $get_code);
            $this->assign('sign', $sign);
            $this->assign('user', session('user'));

            return $this->view->fetch();*/
        }
    }

    public function aipay(Request $request)
    {
            $key=Db::name('config')->where('name', "xskey")->find();
            $key=$key['value'];
ini_set("error_reporting","E_ALL & ~E_NOTICE");
$key = $key;//通讯密钥
$payId = $_GET['payId'];//商户订单号
$param = $_GET['param'];//创建订单的时候传入的参数
$type = $_GET['type'];//支付方式 ：微信支付为1 支付宝支付为2
$price = $_GET['price'];//订单金额
$reallyPrice = $_GET['reallyPrice'];//实际支付金额
$sign = $_GET['sign'];//校验签名，计算方式 = md5(payId + param + type + price + reallyPrice + 通讯密钥)
//开始校验签名
$_sign =  md5($payId . $param . $type . $price . $reallyPrice . $key);
if ($_sign != $sign) {
    echo "error_sign";//sign校验不通过
    exit();
}

         $order = Db::name('paylog')->where('orders', $payId)->find();
            //订单存在
            if ($order) {
                if ($order['state']==0) {
                    Db::name('paylog')->where('id', $order['id'])->update(['state' => 1]);
                    Db::name('user')->where('id', $order['user'])->setInc('money', $price);
                    exit("success");
                } else {
                    exit("已支付");
                }
            }
        /*if ($this->request->isPost()) {
            $post = $this->request->param();

			$appid=Db::name('config')->where('name', "wxappid")->find();
            $key=Db::name('config')->where('name', "wxkey")->find();
            $appid=$appid['value'];
            $key=$key['value'];
            //第一步:取得openid
            define("FAST_APPKEY", $appid);//你的appkey
            define("SECRET_KEY", $key);//你的秘钥
          
            if (!function_exists('get_openid')) {
                require $_SERVER['DOCUMENT_ROOT'].'/fastpay/Fast_Cofig.php';
            }

            $sign=$_POST['sign_notify'];//获取签名2.07版,2.07以下请使用$sign=$_POST['sign'];
            $check_sign=notify_sign($_POST);
            if ($sign!=$check_sign) {
                exit("签名失效");
                //签名计算请查看怎么计算签名,或者下载我们的SDK查看
            }

            $uid         = $_POST['uid'];//支付用户
            $total_fee   = $_POST['total_fee'];//支付金额
            $pay_title   = $_POST['pay_title'];//标题
            $sign        = $_POST['sign'];//签名
            $order_no    = $_POST['order_no'];//订单号
            $me_pri      = $_POST['me_pri'];//我们网站生成的金额,参与签名的,跟实际金额有差异


            $order = Db::name('paylog')->where('orders', $order_no)->find();
            //订单存在
            if ($order) {
                if ($order['state']==0) {
                    Db::name('paylog')->where('id', $order['id'])->update(['state' => 1]);
                    Db::name('user')->where('id', $order['user'])->setInc('money', $total_fee);
                    exit("success");
                } else {
                    exit("已支付");
                }
            }
        }*/


        //return $this->view->fetch();
    }
}
