<?php

namespace app\admin\controller;


use app\common\controller\Backend;
use think\Db;
use think\Request;


class Collection extends Backend
{
  	public function _initialize()
    {
        parent::_initialize();
    }
  
 	public function josn(Request $request)
    {
      $userTableName = Db::name('user')->getTable();
        $model = Db::name('collection')->alias('c')
          	->join("{$userTableName} u" ,'u.id = c.user_id');
    	$uid = $request->param('uid');
        if ( $uid ) {
            $model = $model->where('user_id', $uid);
        }
       
        $statusMap = ['提现申请，处理中', '提现成功', '提现失败'];
        $params = $model->order("id desc")
          ->field("c.*,u.nickname,u.avatar")
          ->paginate(10, null, array('query' => $request->param()));
        foreach($params as $index => &$item) {
            $status = $item['status'];
            $item['status_text'] = isset($statusMap[$status]) ? $statusMap[$status] : '';
        }
       return $this->result($params);
    }
  
    public function submit(Request $request)
    {
        $collection_id = $request->param("collection_id", 0);
        if( ! $collection_id ) {
            $this->error("缺少参数!");
        }

        $model = $model = Db::name('collection')->where("id", $collection_id)->find();
        if( ! isset($model['id']) ) {
            $this->error("不存在的数据!");
        }
        
        if( $model['status'] != 0) {
            $this->error("该订单已审核，不能继续操作!");
        }

        $params['update_time'] = date("Y-m-d H:i:s");
        $params['description'] = $request->param('description', '');
        $params['status'] = $request->param('status',  0);
      
      	if($params['status'] == 2) {
        	Db::name('user')->where("id", $model['user_id'])->setInc('money', $model['money']);
        }
      
        if($model = Db::name('collection')->where("id", $collection_id)->update($params) === false) {
            $this->error("保存失败!");
        }
        $this->success("保存成功!");
    }
  
}