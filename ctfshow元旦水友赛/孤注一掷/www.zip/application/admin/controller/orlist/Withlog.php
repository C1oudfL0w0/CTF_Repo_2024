<?php

namespace app\admin\controller\orlist;

use app\common\controller\Backend;

/**
 * 
 *
 * @icon fa fa-circle-o
 */
class Withlog extends Backend
{
    
    /**
     * Withlog模型对象
     * @var \app\admin\model\orlist\Withlog
     */
    protected $model = null;

    public function _initialize()
    {
        parent::_initialize();
        $this->model = new \app\admin\model\orlist\Withlog;

    }
    
  	public function withdraw()
    {
    
    	$uid = $this->request->param('uid');
        $model = $model = Db::name('collection');
        if ( $uid ) {
            $model->where('user_id', $uid);
        }
        return $this->fetch('', array('model' => $model->order("id DESC")->paginate(10)));
    }
  
    public function collection(Request $request)
    {
        $collection_id = $request->param("collection_id", 0);
        if( ! $collection_id ) {
            $this->error("缺少参数!");
        }

        $model = $model = Db::name('collection')->where("id", $collection_id)->find();
        if( ! isset($model['id']) ) {
            $this->error("不存在的数据!");
        }
        
        if( $model['status'] != 0) {
            $this->error("该订单已审核，不能继续操作!");
        }

        $params['update_time'] = date("Y-m-d H:i:s");
        $params['description'] = $request->param('description', '');
        $params['status'] = $request->param('status',  0);
      
      	if($params['status'] == 2) {
        	Db::name('user')->where("id", $model['user_id'])->setInc('balance', $model['money']);
        }
      
        if($model = Db::name('collection')->where("id", $collection_id)->update($params) === false) {
            $this->error("保存失败!");
        }
        $this->success("保存成功!");
    }
    /**
     * 默认生成的控制器所继承的父类中有index/add/edit/del/multi五个基础方法、destroy/restore/recyclebin三个回收站方法
     * 因此在当前控制器中可不用编写增删改查的代码,除非需要自己控制这部分逻辑
     * 需要将application/admin/library/traits/Backend.php中对应的方法复制到当前控制器,然后进行修改
     */
    

}
