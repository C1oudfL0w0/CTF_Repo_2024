<?php

return [
    'Account'                        => '开奖',
    'Banker'                         => '庄家',
    'Player'                       => '闲家',
    'money'                        => '金额',
    'Term'                       => '开奖期',
    'Time'                       => '开始时间',
    'Endtime'                       => '结束时间',
    'State'                       => '状态',
];
