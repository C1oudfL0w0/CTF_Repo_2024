<?php

return [
    'Account'                        => '下注',
    'Banker'                         => '庄家',
    'Zjmoney'                       => '中奖金额',
    'money'                        => '金额',
    'Term'                       => '下注期',
    'Time'                       => '下注时间',
    'user'                       => '用户id',
    'State'                       => '状态',
];
