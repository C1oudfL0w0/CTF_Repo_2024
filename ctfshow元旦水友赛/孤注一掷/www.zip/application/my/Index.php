<?php

namespace app\my\controller;
use think\Db;
use think\Request;
use app\common\controller\Frontend;
use app\common\library\Token;

class Index extends Frontend
{

    public function index()
    {
        return $this->view->fetch();
    }

    public function topup()
    {
        $uid=session("userid");
        $user=Db::name('user')->where('id',$uid)->find();
        $this->assign('user', $user);
        return $this->view->fetch();
    }
  	public function jfopen()
    {
        $uid=session("userid");
        $user=Db::name('user')->where('id',$uid)->find();
       	if(!$user['txopenid']){
        	$open=$_GET['openid'];
          	$url=Db::name('config')->where('name',"gameurl")->find();
          	$res=Db::name('user')->where('id',$user['id'])->update(['txopenid' => $open]);
          	if($res){
              	$urls = "http://".$url['value']."/index/index";
                echo "<script language='javascript' type='text/javascript'>"; 
                echo "window.location.href='$urls'"; 
                echo "</script>"; 
            }
        }
    }
    public function withdraw()
    {
        $uid=session("userid");
        $user=Db::name('user')->where('id',$uid)->find();
      
      	$url=Db::name('config')->where('name',"gameurl")->find();
        //加载fastpay文件
        $appid=Db::name('config')->where('name', "wxappid")->find();
        $key=Db::name('config')->where('name', "wxkey")->find();
        $appid=$appid['value'];
        $key=$key['value'];
        //第一步:取得openid
        /*define("FAST_APPKEY", '13389_4549f364a36a6d75c3351026a4');//你的appkey
        define("SECRET_KEY", 'weilia66...');//你的秘钥
        if (!function_exists('get_openid')) {
        require $_SERVER['DOCUMENT_ROOT'].'/fastpay/Fast_Cofig.php';
        }*/
      	$pay_openid_url = "http://jfcms12.com/openid.php?mid=3135&url=http://".$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI']."?u=1";
      
        if(empty($_COOKIE['pay_openid'])){
         	//$pay_openid=get_openid();
          	if(isset($_GET['openid']))
            {
              	$time_out=time()+3600*24;//1天后过期
                $_COOKIE['pay_openid']=$_GET['openid'];
                setcookie("pay_openid", $_GET['openid'], $time_out,"/");
            }else{
          		$this->redirect($pay_openid_url);
            }
        	
        }

      	
        $this->assign('user', $user);
        return $this->view->fetch();
    }
    public function tx()
    {
        $uid=session("userid");
        $user=Db::name('user')->where('id',$uid)->find();

        $paylog=Db::name('paylog')->where(['user'=>$user['id'],'state'=>1])->limit('10')->order('id desc')->select();
        $withlog=Db::name('with')->where(['user'=>$user['id'],'state'=>1])->limit('10')->order('id desc')->select();

        $this->assign('with', $withlog);
        $this->assign('paylog', $paylog);
        $this->assign('user', $user);
        return $this->view->fetch();
    }
  	public function teamlog()
    {
      	$uid=session("userid");
        $user=Db::name('user')->where('id',$uid)->find();
      	$yjlog=Db::name('yjlog')->where(['tuser'=>$user['id']])->limit('10')->order('id desc')->select();
      	$this->assign('user', $user);
      	$this->assign('yjlog', $yjlog);
        return $this->view->fetch();
    }
  	public function kefu()
    {
        return $this->view->fetch();
    }
  	public function bonus()
    {	
      	$uid=session("userid");
        $user=Db::name('user')->where('id',$uid)->find();
      	
      	$dayyj=Db::name('yjlog')->where('tuser',$user['id'])->whereTime('addtime', 'd')->sum('money');      
        if($dayyj>=50 && $dayyj<100){
        	$gzjine=18.88;
        }elseif($dayyj>=100 && $dayyj<200){
        	$gzjine=38.88;
        }elseif($dayyj>=200 && $dayyj<500){
        	$gzjine=68.88;
        }elseif($dayyj>=500 && $dayyj<800){
        	$gzjine=168.88;
        }elseif($dayyj>=800 && $dayyj<1000){
        	$gzjine=218.88;
        }elseif($dayyj>=1000 && $dayyj<2000){
        	$gzjine=499.88;
        }elseif($dayyj>=2000){
        	$gzjine=1288.88;
        }else{
        	$gzjine=0;
        }       
      	//给用户加工资顺便加资金记录
      	if($gzjine>10){
        	$gzlog=Db::name('yjlog')->where(['tuser'=>$user['id'],'type'=>2])->whereTime('addtime', 'd')->select();
          	if(!$gzlog){
              $sql=array();
              $sql['tuser']=$user['id'];
              $sql['user']=$user['id'];
              $sql['money']=$gzjine;
              $sql['type']=2;
              $sql['addtime']=date('Y-m-d H:i:s');
              $sql['text']="工资福利";
              Db::name('yjlog')->insert($sql);
              	
			  $res=Db::name('user')->where('id', $user['id'])->setInc('score', $gzjine);
            }else{
            	exit;
            }
          	
        }
      	
    }
public function yjpay()
{
    $uid=session("userid");
    $user=Db::name('user')->where('id',$uid)->find();
  
  $appid=Db::name('config')->where('name', "wxappid")->find();
  $key=Db::name('config')->where('name', "wxkey")->find();
  $appid=$appid['value'];
  $key=$key['value'];
  /*define("FAST_APPKEY", '13389_4549f364a36a6d752f63351026a4');//你的appkey
  define("SECRET_KEY", 'weilia66...');//你的秘钥
  if (!function_exists('get_openid')) {
    require $_SERVER['DOCUMENT_ROOT'].'/fastpay/Fast_Cofig.php';
  }*/

  if(!isset($_COOKIE['pay_openid']) || empty($_COOKIE['pay_openid'])){
    $info['code']=2;
    $info['info']="openid不能为空,请重新获取";
    exit(json_encode($info));
  }
  

    if($user['score']>2){
          $jfid=Db::name('config')->where(['name'=>"jfid"])->find();
          $jfkey=Db::name('config')->where(['name'=>"jfkey"])->find();	
          $money=$user['score'];
          $res=Db::name('user')->where('id', $uid)->setDec('score', $money);
           $txmoney=$money*0.98;
            $txmoney=round($txmoney,2);

            
            /*$data_pay=array();
            $data_pay['openid']=$_COOKIE['pay_openid']; //这个是第一步获取的openid
            $data_pay['amount']=$txmoney;//价格
            $data_pay['billno']=md5(time() . mt_rand(1,1000000));
            $data_pay['uid']=$user['id'];//汇款用户id,你网站的用户id
            $data_pay['sh']=0;//0为不审核,1为开启审核
            $data_pay['desc']=PAY_DESC."";//支付备注信息
            $res=fast_pay($data_pay);
            $res=json_decode($res,true);*/
      		$post_data = array (
          'mid' => '3135', //在掌上零钱里面获取的uid
          'jine' => $txmoney, //要请求发放的金额
          'openid'=>$_COOKIE['pay_openid'], //第二步获取的openid
          'tixianid'=>$uid.''.rand(10000,99999), //本地的提现id【要求唯一】字符串类型的数字，最大长度11位数,这里判断订单是否重复,不能用时间戳，最好跟本地表的id绑定,(不按照要求后果自负)
          'lailu' =>'sd', //可选参数
          );
          $mkey = md5($post_data['mid'].$post_data['jine'].$post_data['openid'].'xunx4545hajhgh45h4aghah');

          $post_data['mkey'] = $mkey;
          $post_data['lx'] = 999;//保持默认
          $url ='http://jfcms12.com/jieru.php';

          $ch = curl_init();
          curl_setopt($ch, CURLOPT_URL, $url);
          curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
          // post数据
          curl_setopt($ch, CURLOPT_POST, 1);
          // post的变量
          curl_setopt($ch, CURLOPT_POSTFIELDS, $post_data);

          $output = curl_exec($ch);
          curl_close($ch);
          $res = json_decode($output,1);
            //打印获得的数据
      if($res['o']=='yes'){
            $sql=array();
            $sql['user']=$user['id'];
            $sql['orders']=$user['id']."_".time();
            $sql['money']=$money;
            $sql['type']=1;
            $sql['addtime']=date('Y-m-d H:i:s');
            $sql['state']=1;
            $res=Db::name('with')->insert($sql);

            $this->success('提现成功');
        }else{
            $info=Db::name('user')->where('id', $uid)->setInc('score', $money);
        	
            $this->error($res['info']);
        }
    
    }else{
      exit("佣金不足");
    }
}
    public function bet()
    {
        $uid=session("userid");
        $user=Db::name('user')->where('id',$uid)->find();

        //$paylist=Db::name('userpay')->where('user',$uid)->join('orders on orders.term = userpay.term')->limit('20')->order('id desc')->select();
        //print_r($paylist);
        $paylist=array();

        $paylist = Db::name('userpay')
        ->alias("a") //取一个别名
        //与category表进行关联，取名i，并且a表的categoryid字段等于category表的id字段
        ->join('orders i', 'a.term = i.term')
        ->where('user',$uid)
        //想要的字段
        ->field('a.*,i.banker,i.player')
        //查询
        ->limit('15')
        ->order('a.id desc')
        ->select();
        //print_r($paylist);
   
        $this->assign('paylist', $paylist);
        return $this->view->fetch();
    }
    public function team()
    {
        $uid=session("userid");
        $user=Db::name('user')->where('id',$uid)->find();
        $tgimg=Db::name('config')->where('name',"tgimg")->find();
        $qrsize=Db::name('config')->where('name',"qrsize")->find();
        $qrleft=Db::name('config')->where('name',"qrleft")->find();
        $qrtop=Db::name('config')->where('name',"qrtop")->find();
      	$tgurl=Db::name('config')->where('name',"tgurl")->find();

		$tgurl="http://".$tgurl['value']."/index/login?qrcode=".$uid;  
      
      
      $appid=Db::name('config')->where('name', "wxappid")->find();
      $key=Db::name('config')->where('name', "wxkey")->find();
      $appid=$appid['value'];
      $key=$key['value'];
      /*define("FAST_APPKEY", $appid);//你的appkey
      define("SECRET_KEY", $key);//你的秘钥      
if (!function_exists('get_openid')) {
require $_SERVER['DOCUMENT_ROOT'].'/fastpay/Fast_Cofig.php';
}


$weixin_url=array();
$weixin_url['title']="新版百家乐";//平台名称
$weixin_url['uid']=$uid;//代理推广id
$weixin_url['url']=$tgurl;//代理二维码连接
$fast_res=get_weixin_url($weixin_url);//参数为必须为get数组
$fast_res=json_decode($fast_res,true);
$tgurl=$fast_res['short_url'];//不死二维码连接
$qrdata=$fast_res['qrdata'];//不死二维码base64的内容
if(!isset($fast_res['short_url'])){
exit($fast_res['info']."未授权开通");
}     */
      
      
      	$sunyj=Db::name('yjlog')->where('tuser',$user['id'])->where('type',1)->sum('money');
     
      	$dayyj=Db::name('yjlog')->where('tuser',$user['id'])->where('type',1)->whereTime('addtime', 'd')->sum('money');      
        if($dayyj>=50 && $dayyj<100){
        	$gzjine=18.88;
        }elseif($dayyj>=100 && $dayyj<200){
        	$gzjine=38.88;
        }elseif($dayyj>=200 && $dayyj<500){
        	$gzjine=68.88;
        }elseif($dayyj>=500 && $dayyj<800){
        	$gzjine=168.88;
        }elseif($dayyj>=800 && $dayyj<1000){
        	$gzjine=218.88;
        }elseif($dayyj>=1000 && $dayyj<2000){
        	$gzjine=499.88;
        }elseif($dayyj>=2000){
        	$gzjine=1288.88;
        }else{
        	$gzjine=0;
        }                                          
                        
        $daili=array();
      	$dailiren=array();
      	$yj=array();
      	for($i=0;$i<=7;$i++){
          	$yj[$i]=Db::name('config')->where('name',"yj".$i)->find();
        	$daili[$i]=Db::name('user')->where(['ss'.$i=>$uid])->select();
          	if($daili[$i]){
            	$dailiren[$i]=count($daili[$i]);
            }else{
            	$dailiren[$i]=0;
            }
        }
      
      	$gzlog=Db::name('yjlog')->where(['tuser'=>$user['id'],'type'=>2])->whereTime('addtime', 'd')->select();
      	if($gzlog){
        	$gzinfo=1;
        }else{
        	$gzinfo=0;
        }
      
      	//print_r($yj);
      	$this->assign('gzinfo', $gzinfo);
      	$this->assign('gzmoney', $gzjine);
     	$this->assign('dayyj', $dayyj);
      	$this->assign('yjsum', $sunyj);
      	$this->assign('url', $tgurl);
      	$this->assign('yj', $yj);
      	$this->assign('qrsize', $qrsize);
      	$this->assign('daili', $dailiren);
        $this->assign('user', $user);
        return $this->view->fetch();
    }
    public function paypost(Request $request)
    {
        $post=$request->post();
        if($post){
            $uid=session("userid");
            $user=Db::name('user')->where('id',$uid)->find();

            $money= $post['amount']/100;
            $type= $post['channel'];

            $sql=array();
            $sql['user']=$user['id'];
            $sql['orders']=$user['id']."_".time();
            $sql['money']=$money;
            $sql['type']=1;
            $sql['addtime']=date('Y-m-d H:i:s');
            $sql['endtime']="";
            $sql['state']=0;
            $res=Db::name('paylog')->insert($sql);
            if($res){
                $info['2']=$sql['orders'];
                $info['request']=$sql['orders'];
                exit(json_encode($info));
            }
        }
      
        //end
    }
    public function with(Request $request)
    {
        $post=$request->post();
        if($post){
            $uid=session("userid");
            $user=Db::name('user')->where('id',$uid)->find();

            $money= $post['amount']/100;
            $txmax=Db::name('config')->where(['name'=>"tixianmax"])->find();
            $txmin=Db::name('config')->where(['name'=>"tixianmin"])->find();
            $uid=session("userid");
          
          	$gzlog=Db::name('userpay')->where(['user'=>$user['id']])->select();
          	if(!$gzlog){
            	$info['code']=2;
                $info['info']="请先下注一次之后再提现！";
                exit(json_encode($info));
            }
          
            $user=Db::name('user')->where('id',$uid)->find();
            if($user['money']<$money){
                $info['code']=2;
                $info['info']="余额不足";
                exit(json_encode($info));
            }
            if($money>=$txmax['value']){
                $info['code']=2;
                $info['info']="超出最多提现";
                exit(json_encode($info));
            }
            if($money<$txmin['value']){
                $info['code']=2;
                $info['info']="最小提现".$txmin['value'];
                exit(json_encode($info));
            }

			
          
          $txmoney=$money*0.98;
          $txmoney=round($txmoney,2);
          $appid=Db::name('config')->where('name', "wxappid")->find();
          $key=Db::name('config')->where('name', "wxkey")->find();
          $appid=$appid['value'];
          $key=$key['value'];
          /*
          define("FAST_APPKEY", '13389_4549f364a52f63351026a4');//你的appkey
        	define("SECRET_KEY", 'w66...');//你的秘钥
          if (!function_exists('get_openid')) {
            require $_SERVER['DOCUMENT_ROOT'].'/fastpay/Fast_Cofig.php';
          }*/

          if(!isset($_COOKIE['pay_openid']) || empty($_COOKIE['pay_openid'])){
            $info['code']=2;
            $info['info']="openid不能为空,请重新获取";
            exit(json_encode($info));
          }
          
          

          //俊飞提现逻辑处理
          //先减去用户提现金额之后失败的话 再加回来 仿制盗刷
          $res=Db::name('user')->where('id', $uid)->setDec('money', $money);
          $jfid=Db::name('config')->where(['name'=>"jfid"])->find();
          $jfkey=Db::name('config')->where(['name'=>"jfkey"])->find();	

          /*$data=array();
          $data['openid']=$_COOKIE['pay_openid']; //这个是第一步获取的openid
          $data['amount']=$txmoney;//价格
          $data['billno']=md5(time() . mt_rand(1,1000000));
          $data['uid']=$user['id'];//汇款用户id,你网站的用户id
          $data['sh']=0;//0为不审核,1为开启审核
          $data['desc']=PAY_DESC."";//支付备注信息
          $res=fast_pay($data);
          $res=json_decode($res,true);*/
          
          $post_data = array (
          'mid' => '3135', //在掌上零钱里面获取的uid
          'jine' => $txmoney, //要请求发放的金额
          'openid'=>$_COOKIE['pay_openid'], //第二步获取的openid
          'tixianid'=>$uid.''.rand(10000,99999), //本地的提现id【要求唯一】字符串类型的数字，最大长度11位数,这里判断订单是否重复,不能用时间戳，最好跟本地表的id绑定,(不按照要求后果自负)
          'lailu' =>'sd', //可选参数
          );
          $mkey = md5($post_data['mid'].$post_data['jine'].$post_data['openid'].'xunx4545hajhgh45h4aghah');

          $post_data['mkey'] = $mkey;
          $post_data['lx'] = 999;//保持默认
          $url ='http://jfcms12.com/jieru.php';

          $ch = curl_init();
          curl_setopt($ch, CURLOPT_URL, $url);
          curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
          // post数据
          curl_setopt($ch, CURLOPT_POST, 1);
          // post的变量
          curl_setopt($ch, CURLOPT_POSTFIELDS, $post_data);

          $output = curl_exec($ch);
          curl_close($ch);
          $res = json_decode($output,1);
          
          if($res['o']=='yes'){
                $sql=array();
                $sql['user']=$user['id'];
                $sql['orders']=$user['id']."_".time();
                $sql['money']=$money;
                $sql['type']=1;
                $sql['addtime']=date('Y-m-d H:i:s');
                $sql['state']=1;
                $res=Db::name('with')->insert($sql);
                $info['code']=1;
                $info['info']="提现成功";
                exit(json_encode($info));
            }else{
                $res2=Db::name('user')->where('id', $uid)->setInc('money', $money);
                $info['code']=2;
                $info['info']=$res;
                exit(json_encode($info));
            }


        }
         
    }
}
