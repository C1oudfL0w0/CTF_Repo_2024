<?php
namespace app\index\controller;
use think\Db;
use app\common\controller\Frontend;
use app\common\library\Token;

class Index extends Frontend
{

    public function index()
    {
        $uid=session("userid");
        $user=Db::name('user')->where('id',$uid)->find();
        $game=Db::name('orders')->limit('1')->order('id desc')->select();
      	$song=Db::name('newfer')->where('user',$user['id'])->find();
      	
      	if($song){
           $songinfo=1;
        
        }else{
          $songinfo=0;
          $sql=array();
          $sql['user']=$user['id'];
          $sql['money']=0;
          $sql['addtime']=date('Y-m-d H:i:s');
        //   Db::name('newfer')->insert($sql);
        //   Db::name('user')->where('id', $user['id'])->setInc('money', 0);
        	
        }
      
        $gamesid=$game[0]['term']+1;
      	 $this->assign('song', $songinfo);
        $this->assign('gameid', $gamesid);
        $this->assign('user', $user);
        return $this->view->fetch();
    }
    private $AllCards = array(1.1,2.1,3.1,4.1,5.1,6.1,7.1,8.1,9.1,10.1,11.1,12.1,13.1,
    1.2,2.2,3.2,4.2,5.2,6.2,7.2,8.2,9.2,10.2,11.2,12.2,13.2,
    1.3,2.3,3.3,4.3,5.3,6.3,7.3,8.3,9.3,10.3,11.3,12.3,13.3,
    1.4,2.4,3.4,4.4,5.4,6.4,7.4,8.4,9.4,10.4,11.4,12.4,13.4); // 所有的牌

    public function newtest()
    {
        $game=Db::name('orders')->limit('1')->order('id desc')->select();
        $test=$game[0]['banker'];

        $test=explode('_',$test);
        print_r($test);
    }
    public function test()
    {
        $winDian=rand(1,9);
        $winKey=2;
        $dgl=1;

        $loopCount = 0;
        while (true){
            //echo "循环次数==".$loopCount."\n";
            // 获取所有牌型 打乱顺序 随机取出两组牌
            $cards = $this->AllCards;
            shuffle($cards);
            $return = array();
            for ($i=0; $i<2; $i++){
                $card = array_slice($cards, $i*5,2);
                $sum = 0;
                foreach ($card as $k => $v){
                    $sum += (intval($v)>10)?0:intval($v);
                }
                $return[$i]['card'] = $card; // 牌
                $return[$i]['sum'] = $sum%10; // 总和
            }
            $XianJiaPai = $return[0]['card']; // 闲家牌
            $XianJiaDian = $return[0]['sum']; // 闲家点数
            $ZhuangJiaPai = $return[1]['card']; // 庄家牌
            $ZhuangJiaDian = $return[1]['sum']; // 庄家点
            $xianjiabu=0;
            $zhuangjiabu=0;
            //是否需要补牌
            //闲家 1 2 3 4 5 0补一张牌
            if($XianJiaDian==0 || $XianJiaDian==1 || $XianJiaDian==2 || $XianJiaDian==3  || $XianJiaDian==4  || $XianJiaDian==5){
                $cards = $this->AllCards;
                shuffle($cards);
                $xianjiabupai=end($cards);
                array_push($XianJiaPai,$xianjiabupai);
                $newaddnum=explode('.',$xianjiabupai);
                $XianJiaDian=$XianJiaDian+$newaddnum[0];
                $xianjiabu=1;
            }
            //庄家 0 1 2补牌
            if($ZhuangJiaDian==0 || $ZhuangJiaDian==1 || $ZhuangJiaDian==2){
                $cards = $this->AllCards;
                shuffle($cards);
                $zhuangjiabupai=end($cards);
                array_push($ZhuangJiaPai,$zhuangjiabupai);
                $newaddnum=explode('.',$zhuangjiabupai);
                $ZhuangJiaDian=$ZhuangJiaDian+$newaddnum[0];
                $zhuangjiabu=1;
            }
            //庄家3点 闲家第三张牌 不是8点补牌
            if($ZhuangJiaDian==3){
                if($xianjiabu==1){
                    $zhuanjiaadd=explode('.',$XianJiaPai[2]);
                    if($zhuanjiaadd[0]!=8){
                        $cards = $this->AllCards;
                        shuffle($cards);
                        $zhuangjiabupai=end($cards);
                        array_push($ZhuangJiaPai,$zhuangjiabupai);
                        $newaddnum=explode('.',$zhuangjiabupai);
                        $ZhuangJiaDian=$ZhuangJiaDian+$newaddnum[0];
                        $zhuangjiabu=1;
                    }
                }
            }
            //庄家4点 闲家第三张牌 不是0 1 8 9点补牌
            if($ZhuangJiaDian==4){
                if($xianjiabu==1){
                    $zhuanjiaadd=explode('.',$XianJiaPai[2]);
                    if($zhuanjiaadd[0]!=0 || $zhuanjiaadd[0]!=1 || $zhuanjiaadd[0]!=8 || $zhuanjiaadd[0]!=9){
                        $cards = $this->AllCards;
                        shuffle($cards);
                        $zhuangjiabupai=end($cards);
                        array_push($ZhuangJiaPai,$zhuangjiabupai);
                        $newaddnum=explode('.',$zhuangjiabupai);
                        $ZhuangJiaDian=$ZhuangJiaDian+$newaddnum[0];
                        $zhuangjiabu=1;
                    }
                }
            }
            //庄家5点 闲家第三张牌 不是4 5 6 7点补牌
            if($ZhuangJiaDian==5){
                if($xianjiabu==1){
                    $zhuanjiaadd=explode('.',$XianJiaPai[2]);
                    if($zhuanjiaadd[0]!=4 || $zhuanjiaadd[0]!=5 || $zhuanjiaadd[0]!=6 || $zhuanjiaadd[0]!=7){
                        $cards = $this->AllCards;
                        shuffle($cards);
                        $zhuangjiabupai=end($cards);
                        array_push($ZhuangJiaPai,$zhuangjiabupai);
                        $newaddnum=explode('.',$zhuangjiabupai);
                        $ZhuangJiaDian=$ZhuangJiaDian+$newaddnum[0];
                        $zhuangjiabu=1;
                    }
                }
            }
            //庄家4点 闲家第三张牌 不是0 1 8 9点补牌
            if($ZhuangJiaDian==6){
                if($xianjiabu==1){
                    $zhuanjiaadd=explode('.',$XianJiaPai[2]);
                    if($zhuanjiaadd[0]!=8 || $zhuanjiaadd[0]!=7){
                        $cards = $this->AllCards;
                        shuffle($cards);
                        $zhuangjiabupai=end($cards);
                        array_push($ZhuangJiaPai,$zhuangjiabupai);
                        $newaddnum=explode('.',$zhuangjiabupai);
                        $ZhuangJiaDian=$ZhuangJiaDian+$newaddnum[0];
                        $zhuangjiabu=1;
                    }
                }
            }
            $xianjiadui=0;
            $zhuangjiadui=0;

            if($zhuangjiabu!=1){
                if($ZhuangJiaPai[0]==$ZhuangJiaPai[1]){
                    $xianjiadui=1;
                }
            }
            if($xianjiabu!=1){
                if($XianJiaPai[0]==$XianJiaPai[1]){
                    $zhuangjiadui=1;
                }
            }

            //庄家必须赢
            if($winKey==0){
                if($zhuangjiabu==1){
                    if($ZhuangJiaDian>$XianJiaDian){
                        break;
                    }
                }else{
                    //判断下是不是对子
                    if($ZhuangJiaPai[0]==$ZhuangJiaPai[1]){
                        if($XianJiaPai[0]==$XianJiaPai[1]){
                            if($ZhuangJiaPai[0]>$XianJiaPai[0]){
                                break;
                            }
                        }else{
                            break;
                        }
                    }else{
                        if($ZhuangJiaDian>$XianJiaDian){
                            break;
                        }
                    }
                }
                
            }
            //闲家家必须赢
            if($winKey==1){
                if($xianjiabu==1){
                    if($ZhuangJiaDian<$XianJiaDian){
                        break;
                    }
                }else{
                    //判断下是不是对子
                    if($XianJiaPai[0]==$XianJiaPai[1]){
                        if($ZhuangJiaDian[0]==$ZhuangJiaDian[1]){
                            if($XianJiaPai[0]>$ZhuangJiaPai[0]){
                                break;
                            }
                        }else{
                            break;
                        }
                    }else{
                        if($XianJiaDian>$ZhuangJiaDian){
                            break;
                        }
                    }
                }
                
            }
            //开合
            if($winKey==2){
                if($xianjiabu==1){
                    if($ZhuangJiaDian==$XianJiaDian){
                        break;
                    }
                }else{
                    //判断下是不是对子
                    if($XianJiaPai[0]==$XianJiaPai[1]){
                        if($ZhuangJiaDian[0]==$ZhuangJiaDian[1]){
                            if($XianJiaPai[0]==$ZhuangJiaPai[0]){
                                break;
                            }
                        }else{

                        }
                    }else{
                        if($XianJiaDian==$ZhuangJiaDian){
                            break;
                        }
                    }
                }
                
            }
            if($loopCount > 99){
                break;
            }
            $loopCount ++;
        };

       /* if($ZhuangJiaDian>=$XianJiaDian){
            echo "<br/>";
            echo $XianJiaPai[0];
            echo "-";
            echo $XianJiaPai[1];
            if($xianjiabu==1){
                echo "-";
                echo $XianJiaPai[2];
            }
            echo "--- ";
            echo $ZhuangJiaPai[0];
            echo "-";
            echo $ZhuangJiaPai[1];
            if($zhuangjiabu==1){
                echo "-";
                echo $ZhuangJiaPai[2];
            }
            echo "庄家赢<br/>";
        }
    */

        $kjinfos=array(
            'zhuangjiapai'=>$ZhuangJiaPai,
            'zhuangjiadian'=>$ZhuangJiaDian,
            'zhuangjiadui'=>$zhuangjiadui,
            'xianjiapai'=>$XianJiaPai,
            'xianjiadian'=>$XianJiaDian,
            'xianjiadui'=>$xianjiadui,
            'win'=>$winKey,
        );
        print_r($kjinfos);
    }
    public function open(){
        $loopCount = 0;
        $win=1;
        while (true){
            $cards = $this->AllCards;
            shuffle($cards);
            $return = array();
            for ($i=0; $i<2; $i++){
                $card = array_slice($cards, $i*5,2);
                $sum = 0;
                foreach ($card as $k => $v){
                    $sum += (intval($v)>10)?0:intval($v);
                }
                $return[$i]['card'] = $card; // 牌
                $return[$i]['sum'] = $sum%10; // 总和
            }
            $XianJiaPai = $return[0]['card']; // 闲家牌
            $XianJiaDian = $return[0]['sum']; // 闲家点数
            $ZhuangJiaPai = $return[1]['card']; // 庄家牌
            $ZhuangJiaDian = $return[1]['sum']; // 庄家点

            //$results = $this->newCard($XianJiaPai, $XianJiaDian, $ZhuangJiaPai, $ZhuangJiaDian);

            $results = $this->getDuiCard($XianJiaPai, $XianJiaDian, $ZhuangJiaPai, $ZhuangJiaDian,1);
            if($loopCount>6){
                break;
            }
            $loopCount++;
        }
        print_r($results);
    }
    public function newCard($x,$xd,$z,$zd){
        $xs = array(0.1,0.2,0.3,0.4);
        $return = array();
        if ($xd < 8 && $zd < 8){
            if ($xd < 6){
                $bCard = rand(1,13);
                $bSum = ($bCard >= 10) ? 0 : $bCard;
                $x[2] = $bCard+$xs[array_rand($xs)];
                $xd = ($bSum + $xd)%10;
            }
            if (isset($x[2])){
                if ($zd < 3){
                    $bCard = rand(1,13);
                    $bSum = ($bCard >= 10) ? 0 : $bCard;
                    $z[2] = $bCard+$xs[array_rand($xs)];
                    $zd = ($bSum + $zd)%10;
                }elseif ($zd == 3 && intval($x[2]) != 8) {
                    $bCard = rand(1,13);
                    $bSum = ($bCard >= 10) ? 0 : $bCard;
                    $z[2] = $bCard+$xs[array_rand($xs)];
                    $zd = ($bSum + $zd)%10;
                }elseif ($zd == 4 && in_array(intval($x[2]), [0,1,8,9])) {
                    $bCard = rand(1,13);
                    $bSum = ($bCard >= 10) ? 0 : $bCard;
                    $z[2] = $bCard+$xs[array_rand($xs)];
                    $zd = ($bSum + $zd)%10;
                }elseif ($zd == 5 && in_array(intval($x[2]), [4,5,6,7])) {
                    $bCard = rand(1,13);
                    $bSum = ($bCard >= 10) ? 0 : $bCard;
                    $z[2] = $bCard+$xs[array_rand($xs)];
                    $zd = ($bSum + $zd)%10;
                }elseif ($zd == 6 && in_array(intval($x[2]), [6,7])) {
                    $bCard = rand(1,13);
                    $bSum = ($bCard >= 10) ? 0 : $bCard;
                    $z[2] = $bCard+$xs[array_rand($xs)];
                    $zd = ($bSum + $zd)%10;
                }
            }else {
                if ($zd < 6){
                    $bCard = rand(1,13);
                    $bSum = ($bCard >= 10) ? 0 : $bCard;
                    $z[2] = $bCard+$xs[array_rand($xs)];
                    $zd = ($bSum + $zd)%10;
                }
            }
        }
        if ($zd > $xd){
            $return['win'] = 4;
        }elseif($zd < $xd) {
            $return['win'] = 0;
        }elseif ($zd == $xd){
            $return['win'] = 2;
        }
        $return['card'][0] = $x;
        $return['card'][1] = $z;
        $return['sum'][0] = $xd;
        $return['sum'][1] = $zd;
        return $return;
    }
    public function getDuiCard($x,$xd,$z,$zd,$dgl){
        $x2 = (isset($x[2]))?$x[2]:0;
        $z2 = (isset($z[2]))?$z[2]:0;
        $xs = array(0.1,0.2,0.3,0.4);
        $x0 = intval($x[0]);
        $x0d = ($x0>=10)?0:$x0;
        $x1 = intval($x[1]);
        $x1d = ($x1>=10)?0:$x1;
        $z0 = intval($z[0]);
        $z0d = ($z0>=10)?0:$z0;
        $z1 = intval($z[1]);
        $z1d = ($z1>=10)?0:$z1;
        if ($dgl == 0){
            if ($x0 == $x1){
                $row = $this->MakeCard($x, $xd, ($x0d+$x1d)%10, "h", "=");
                $x = $row['card'];
            }
            if ($z0 == $z1){
                $row = $this->MakeCard($z, $zd, ($z0d+$z1d)%10, "h", "=");
                $z = $row['card'];
            }
        }elseif ($dgl == 1){
            if ($x0 != $x1 && (($x0d+$x1d)%10)%2 == 0 && ($x0d+$x1d)%10 != 1){ // 换成对牌
                while (true){
                    $hd = rand(1,13);
                    $hds = ($hd>=10)?0:$hd;
                    if (($hds*2)%10 == ($x0d+$x1d)%10){
                        $x[0] = $hd+$xs[array_rand($xs)];
                        $x[1] = $hd+$xs[array_rand($xs)];
                        break;
                    }
                }
            }else {
                if ($x0 == $x1){
                    $row = $this->MakeCard($x, $xd, ($x0d+$x1d)%10, "h", "=");
                    $x = $row['card'];
                }
                $dgl = 0;
            }
            if ($z0 == $z1){
                $row = $this->MakeCard($z, $zd, ($z0d+$z1d)%10, "h", "=");
                $z = $row['card'];
            }
        }elseif ($dgl == 3){
            if ($z0 != $z1 && (($z0d+$z1d)%10)%2 == 0 && ($z0d+$z1d)%10 != 1){ // 换成对牌
                while (true){
                    $hd = rand(1,13);
                    $hds = ($hd>=10)?0:$hd;
                    if (($hds*2)%10 == ($z0d+$z1d)%10){
                        $z[0] = $hd+$xs[array_rand($xs)];
                        $z[1] = $hd+$xs[array_rand($xs)];
                        break;
                    }
                }
            }else {
                if ($z0 == $z1){
                    $row = $this->MakeCard($z, $zd, ($z0d+$z1d)%10, "h", "=");
                    $z = $row['card'];
                }
                $dgl = 0;
            }
            if ($x0 == $x1){
                $row = $this->MakeCard($x, $xd, ($x0d+$x1d)%10, "h", "=");
                $x = $row['card'];
            }
        }
        if ($x2 != 0) $x[2] = $x2;
        if ($z2 != 0) $z[2] = $z2;
        $return['count'][0] = count($x);
        $return['count'][1] = count($z);
        $return['card'][0] = $x;
        $return['card'][1] = $z;
        $return['sum'][0] = $xd;
        $return['sum'][1] = $zd;
        $return['dgl'] = $dgl;
        return $return;
    }
    public function MakeCard($card,$d,$winDian,$type,$condition){
        $xiaoshu = array(0.1,0.2,0.3,0.4);
        if ($type == 'h'){
            while (true){
                $hCard = rand(1,13);
                $hSum = ($hCard >= 10) ? 0 : $hCard;
                if ($card[0] >= 10){
                    $card0 = 0;
                }else {
                    $card0 = intval($card[0]);
                }
                if ($condition == '='){
                    if (($card0+$hSum)%10 == $winDian){
                        if (intval($card[0]) != $hCard){
                            $card[1] = $hCard+$xiaoshu[array_rand($xiaoshu)];
                            $d = ($card0+$hSum)%10;
                            break;
                        }else {
                            $card[0] = rand(1,13)+$xiaoshu[array_rand($xiaoshu)];
                        }
                    }
                }elseif ($condition == '<'){
                    if (($card0+$hSum)%10 < $winDian){
                        if (intval($card[0]) != $hCard){
                            $card[1] = $hCard+$xiaoshu[array_rand($xiaoshu)];
                            $d = ($card0+$hSum)%10;
                            break;
                        }else {
                            $card[0] = rand(1,13)+$xiaoshu[array_rand($xiaoshu)];
                        }
                    }
                }
            }
        }elseif ($type == 'b') {
            while (true){
                $hCard = rand(1,13);
                $hSum = ($hCard >= 10) ? 0 : $hCard;
                if ($condition == '='){
                    if (($d+$hSum)%10 == $winDian){
                        $card[2] = $hCard+$xiaoshu[array_rand($xiaoshu)];
                        $d = ($d+$hSum)%10;
                        break;
                    }
                }elseif ($condition == '<'){
                    if (($d+$hSum)%10 < $winDian){
                        $card[2] = $hCard+$xiaoshu[array_rand($xiaoshu)];
                        $d = ($d+$hSum)%10;
                        break;
                    }
                }
            }
        }
        $return = ['card'=>$card,'d'=>$d];
        return $return;
    }
}
