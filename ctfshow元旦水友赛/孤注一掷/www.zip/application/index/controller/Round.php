<?php

namespace app\index\controller;
use think\Db;
use think\Request;
use app\common\controller\Frontend;
use app\common\library\Token;
/*
    by luyis
    date 19-5-3
    说明 数据库内
    banker 庄家
    player 闲家
*/

class Round extends Frontend
{

    public function index(Request $request)
    {
        $configs=Db::name('config')->where(['name'=>"pai"])->find();
        $inspai=array(
            '13.1'=>'51',
            '12.1'=>'50',
            '11.1'=>'49',
            '10.1'=>'48',
            '9.1'=>'47',
            '8.1'=>'46',
            '7.1'=>'45',
            '6.1'=>'44',
            '5.1'=>'43',
            '4.1'=>'42',
            '3.1'=>'41',
            '2.1'=>'40',
            '1.1'=>'39',
            '13.2'=>'38',
            '12.2'=>'37',
            '11.2'=>'36',
            '10.2'=>'35',
            '9.2'=>'34',
            '8.2'=>'33',
            '7.2'=>'32',
            '6.2'=>'31',
            '5.2'=>'30',
            '4.2'=>'29',
            '3.2'=>'28',
            '2.2'=>'27',
            '1.2'=>'26',
            '13.3'=>'25',
            '12.3'=>'24',
            '11.3'=>'23',
            '10.3'=>'22',
            '9.3'=>'21',
            '8.3'=>'20',
            '7.3'=>'19',
            '6.3'=>'18',
            '5.3'=>'17',
            '4.3'=>'16',
            '3.3'=>'15',
            '2.3'=>'14',
            '1.3'=>'13',
            '13.4'=>'12',
            '12.4'=>'11',
            '11.4'=>'10',
            '10.4'=>'9',
            '9.4'=>'8',
            '8.4'=>'7',
            '7.4'=>'6',
            '6.4'=>'5',
            '5.4'=>'4',
            '4.4'=>'3',
            '3.4'=>'2',
            '2.4'=>'1',
            '1.4'=>'0',
        );
        $post=$request->post();
        $uid=session("userid");
        $user=Db::name('user')->where('id',$uid)->find();
        //定义总返回
        $msg=array();
        $msg['success']=true;
        $msg['message']="Ok";
        //定义data
        $data=array();
        //$newtimes='2019-05-01T08:26:20.000Z';
        $gameid=$post['gameid'];
        $openids=Db::name('orders')->where(['term'=>$gameid])->find();
        $gamelist=Db::name('orders')->limit('1')->order('id desc')->select();
        //开启时间
        $newtimes=$this->datetimes(time());
        //结束时间
        $opentime=$this->datetimes($gamelist[0]['endtime']);
        $gameopentime=$this->datetimes(time());

        //判断开奖期数据是否存在
        if($openids){
            $latest=array();
            $latest['id']=$openids['term']+1;
            $latest['periodicalId']=$openids['term']+1;

            $zhuangjia=$openids['player'];
            $xianjia=$openids['banker'];
            $xianjia=explode('_',$xianjia);
            $zhuangjia=explode('_',$zhuangjia);
            if(count($xianjia)==3){
                $kaijiangxjpai='[['.$inspai[$xianjia[0]].','.$inspai[$xianjia[1]].','.$inspai[$xianjia[2]].'],';
            }else{
                $kaijiangxjpai='[['.$inspai[$xianjia[0]].','.$inspai[$xianjia[1]].',null],';
            }
            if(count($zhuangjia)==3){
                $kaijiangzjpai='['.$inspai[$zhuangjia[0]].','.$inspai[$zhuangjia[1]].','.$inspai[$zhuangjia[2]].']]';
            }else{
                $kaijiangzjpai='['.$inspai[$zhuangjia[0]].','.$inspai[$zhuangjia[1]].',null]]';
            }
            $game_open_zj=explode('.',$xianjia[0]);
            $game_open_zj1=explode('.',$xianjia[1]);
            $game_open_xj=explode('.',$zhuangjia[0]);
            $game_open_xj1=explode('.',$zhuangjia[1]);

            if($game_open_xj[0]==$game_open_xj1[0]){
                $xianjiadui='yes';
            }else{
                $xianjiadui='no';
            }
            if($game_open_zj[0]==$game_open_zj1[0]){
                $zhuangjiadui='yes';
            }else{
                $zhuangjiadui='no';
            }

            //$latest['cards']="[[0,13,null],[27,51,null]]";

            $latest['cards']=$kaijiangxjpai.$kaijiangzjpai;
            $latest['winner']=$openids['account'];
            $latest['isPlayerPair']=$zhuangjiadui;
            $latest['isBankerPair']=$xianjiadui;
            $latest['betAt']=$openids['term']+1;
            $latest['settledAt']=$gameopentime;
            $latest['periodical']=array(
                'current'=>40,
                'cards'=>$configs['value'],
            );
        }else{
            $latest=array();
            $latest['id']=$gamelist[0]['term']+1;
            $latest['periodicalId']=249930;
            //$latest['cards']="[[44,27,null],[41,4,null]]";
            $latest['cards']=0;
            $latest['winner']='waiting';
            $latest['isPlayerPair']='waiting';
            $latest['isBankerPair']='waiting';
            $latest['betAt']=249930;
            $latest['settledAt']=$opentime;
            $latest['periodical']=array(
                'current'=>40,
                'cards'=>$configs['value'],
            );
        }

        $data['now'] = $newtimes;
      
      
        $data['latest'] = $latest;
        $data['balance'] = $user['money'] * 100;
        $data['bets']=array();
        $data['users']=mt_rand(800,1400);
        $data['counters']=array();
        //历史开奖信息
        $orders=Db::name('orders')->limit('48')->order('id desc')->select();
        $list=array();
        foreach($orders as $value){
            $list_min['id']=$value['term'];
            $list_min['winner']=$value['account'];

            $zhuangjia=$value['player'];
            $xianjia=$value['banker'];
            $xianjia=explode('_',$xianjia);
            $zhuangjia=explode('_',$zhuangjia);
            if(count($xianjia)==3){
                $kaijiangxjpai='[['.$inspai[$xianjia[0]].','.$inspai[$xianjia[1]].','.$inspai[$xianjia[2]].'],';
            }else{
                $kaijiangxjpai='[['.$inspai[$xianjia[0]].','.$inspai[$xianjia[1]].',null],';
            }
            if(count($zhuangjia)==3){
                $kaijiangzjpai='['.$inspai[$zhuangjia[0]].','.$inspai[$zhuangjia[1]].','.$inspai[$zhuangjia[2]].']]';
            }else{
                $kaijiangzjpai='['.$inspai[$zhuangjia[0]].','.$inspai[$zhuangjia[1]].',null]]';
            }

            //$list_min['cards']='[[19,13,null],[25,43,null]]';
            $list_min['cards']=$kaijiangxjpai.$kaijiangzjpai;
            $xianjianum=$value['banker'];
            $zhuangjianum=$value['player'];

            $xianjia=explode('_',$xianjianum);
            $zhuangjia=explode('_',$zhuangjianum);


            $game_open_zj=explode('.',$xianjia[0]);
            $game_open_zj1=explode('.',$xianjia[1]);
            $game_open_xj=explode('.',$zhuangjia[0]);
            $game_open_xj1=explode('.',$zhuangjia[1]);

            if($game_open_xj[0]==$game_open_xj1[0]){
                $xianjiadui='yes';
            }else{
                $xianjiadui='no';
            }
            if($game_open_zj[0]==$game_open_zj1[0]){
                $zhuangjiadui='yes';
            }else{
                $zhuangjiadui='no';
            }

            $list_min['isPlayerPair']=$zhuangjiadui;
            $list_min['isBankerPair']=$xianjiadui;
            array_push($list,$list_min);
        }


        

        $data['histories']=$list;

        $msg['data']=$data;
        exit(json_encode($msg));

    }
    public function counters()
    {
        $paylog=Db::name('userpay')->limit('6')->order('id desc')->select();

        $info=array();
        $info['success']=true;
        $info['message']='ok';
        $suiji=rand(1,4);
        $userpaylog=array();
        foreach($paylog as $value){
            //banker:50: 0
            $userpaylog[$value['account'].':'.$value['money']]=1;
        }
        $info['data']=array(
            'counters'=>$userpaylog,
        );
        exit(json_encode($info));
    }
    public function bet(Request $request)
    {
        $uid=session("userid");
        $user=Db::name('user')->where('id',$uid)->find();
        $data=$request->post();
        if($data){
            $payid=$data['roundId'];
            $money=$data['amount']/100;
            $type=$data['type'];
            if($user['money']<$money){
                $info=array();
                $info['code']="BalanceNotEnough";
                $info['message']="余额不足";
                $info['errors']=array();
                $info['success']=false;
                $http = array ( 
                    400 => "HTTP/1.1 400 Bad Request", 
                ); 
                header($http['400']); 
                exit(json_encode($info));
            }else{
                $res=Db::name('user')->where('id', $uid)->setDec('money', $money);
                if($res){
                    $sql=array();
                    $sql['user']=$uid;
                    $sql['account']=$type;
                    $sql['money']=$money;
                    $sql['zjmoney']=0;
                    $sql['term']=$payid;
                    $sql['type']=1;
                    $sql['time']=time();
                    Db::name('userpay')->insert($sql);
                  	$user=Db::name('user')->where('id',$uid)->find();
                  	$yongjining="";
					//返佣金
                  	for($i=0;$i<=7;$i++){
                    	$yongjining="ss".$i;
                      	$yj=array();
                      	for($s=0;$s<=7;$s++){
                              $yj[$s]=Db::name('config')->where('name',"yj".$s)->find();
                        }
                      	$jibie=$i+1;
                      	$pfmoney=$money*$yj[$i]['value']/100;
                      	if($user[$yongjining]>0){
                          	$sql=array();
                            $sql['tuser']=$user[$yongjining];
                            $sql['user']=$user['id'];
                            $sql['money']=$pfmoney;
                          	$sql['type']=1;
                            $sql['addtime']=date('Y-m-d H:i:s');
                            $sql['text']=$jibie."级返佣".$pfmoney;
                            Db::name('yjlog')->insert($sql);
                        	Db::name('user')->where('id', $user[$yongjining])->setInc('score', $pfmoney);
                        }
                    }
                  
                  	
                   
                    $info=array();
                    $info['data']=array(
                        'balance'=>$user['money']*100,
                    );
                    $info['success']=true;
                    exit(json_encode($info));
                }
                //金额足够end
            }
        }
        

        
        
    }

    public function datetimes($times)
    {
        $time=date('Y-m-d\TH:i:s_\Z',$times);
        $time=explode('_',$time);
        $ntime=explode('.',microtime(true))[1];
        $rtime=$time[0].'.'.$ntime.'Z';
        return $rtime;
    }

}
