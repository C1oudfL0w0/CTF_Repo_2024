<?php


namespace app\index\controller;


use think\Controller;
use think\Request;

class Upload extends Controller
{
    public function image(Request $request)
    {
        $file = $request->file('file');
        if( ! $file ) {
            $this->error("error.");
        }
        $info = $file->move(ROOT_PATH . 'public' . DS . 'uploads');

        $filename = '/uploads/' . str_replace("\\", "/", $info->getSaveName());
        $this->success('', null, $filename);
    }
}