<?php
namespace app\index\controller;

use app\common\controller\Frontend;
use think\Controller;
use think\Config;
use think\Cookie;
use think\Hook;
use think\Db;
use think\Session;
use think\Validate;
use think\Request;

/**
 * 微信登录
 */
class Login extends Controller
{
    public function index()
    {
        $request = Request::instance();
        $appid=Db::name('config')->where('name', "wxappid")->find();
        $key=Db::name('config')->where('name', "wxkey")->find();
        $url=Db::name('config')->where('name', "tgurl")->find();
        $gameurl=Db::name('config')->where('name', "gameurl")->find();
        $gameurl=$gameurl['value'];

        $appid=$appid['value'];
        $key=$key['value'];
        $url=$url['value'];
      

        if ($request->isGet()) {
            $qrcode = $request->get('qrcode');
            //判断是否有上级id

            if ($qrcode) {
                session("tuid", $qrcode);
                $myurl="http://".$_SERVER['HTTP_HOST']."/index/login/open?state=".$qrcode;
                $url="http://".$_SERVER['HTTP_HOST'].'/1.html?appid='.$appid.'&redirect_uri='.$myurl.'&response_type=code&scope=snsapi_userinfo&state='.$qrcode.'#wechat_redirect';
              	// $url = "http://wx.hgq520.top/get-weixin-code.html?appid=wx8a38edc1397fda68&redirect_uri=".urlencode("http://".$_SERVER['HTTP_HOST']."/index/login/open")."&response_type=code&scope=snsapi_userinfo&state={$qrcode}#wechat_redirect";
                $wxurl=$url."?appid=".$appid."&appkey=".$key."&url=".$myurl."&state=".$qrcode;
                //echo "<script>window.location.href = '".$wxurl."'</script>";
                header('location:'.$url);
				exit();
            } else {
                $qrcode=0;
                session("tuid", 0);
                $myurl="http://".$_SERVER['HTTP_HOST']."/index/login/open?state=".$qrcode;
                $url="http://".$_SERVER['HTTP_HOST'].'/1.html?appid='.$appid.'&redirect_uri='.$myurl.'&response_type=code&scope=snsapi_userinfo&state='.$qrcode.'#wechat_redirect';
              	 //$url = "http://cs.3eym.com/1.html?appid=wx8c26971c7e05c169&redirect_uri=".urlencode("http://".$_SERVER['HTTP_HOST']."/index/login/open")."&response_type=code&scope=snsapi_userinfo&state={$qrcode}#wechat_redirect";
                $wxurl=$url."?appid=".$appid."&appkey=".$key."&url=".$myurl."&state=".$qrcode;
                header('location:'.$url);
                //echo "<script>window.location.href = '".$wxurl."'</script>";
                exit();
            }
        }
    }
    public function open()
    {
    //     $gameurl=Db::name('config')->where('name', "gameurl")->find();
    //     $gameurl=$gameurl['value'];
    //     $appid  = $_GET['appid'];
    //   	$key   = $_GET['key'];
    //     $request = Request::instance();
      
          $request = Request::instance();
        $appid=Db::name('config')->where('name', "wxappid")->find();
        $key=Db::name('config')->where('name', "wxkey")->find();
        $url=Db::name('config')->where('name', "tgurl")->find();
        $gameurl=Db::name('config')->where('name', "gameurl")->find();
        $gameurl=$gameurl['value'];



        $appid=$appid['value'];
        $key=$key['value'];
        $url=$url['value'];
      	
      	if(!isset($_GET['code']))
        {
          	$url="http://".$_SERVER['HTTP_HOST']."/index/login/index?state=".$state;
          	header('location:'.$url);
          	exit();
        }
      	$code = $_GET['code'];
      	if(!session('userinfo'))
        {
          $token_url = "https://api.weixin.qq.com/sns/oauth2/access_token?appid=".$appid."&secret=".$key."&code=".$code."&grant_type=authorization_code";
          $data = file_get_contents($token_url);

          $res = json_decode($data,1);

// var_dump($res);
// die();
          //获取用户信息
          $info_url = "https://api.weixin.qq.com/sns/userinfo?access_token=".$res['access_token']."&openid=".$res['openid']."&lang=zh_CN";
          $data = file_get_contents($info_url);
          $userinfo = json_decode($data,1);
          session('userinfo',$userinfo);
        }
      	$userinfo = session('userinfo');

      /*
        //第一步:取得openid
        define("FAST_APPKEY", $appid);//你的appkey
        define("SECRET_KEY", $key);//你的秘钥



        //加载fastpay支付插件
        if (!function_exists('get_openid')) {
            require $_SERVER['DOCUMENT_ROOT'].'/fastpay/Fast_Cofig.php';
        }
      

      
      
        $userinfo=get_openid_info($_GET);//参数为必须为get数组
		
        if (!is_array($userinfo)) {
            $userinfo=json_decode($userinfo, true);
        }*/
		
        $openid =$userinfo['openid'];//用户的openid
        $nickname =$userinfo['nickname'];//用户昵称
        $headimgurl = $userinfo['headimgurl'];//用户头像

        $sex	     = $userinfo['sex'];//性别
        $province  = $userinfo['province'];//省份
        $city      = $userinfo['city'];//城市
        $country   = $userinfo['country'];//国家，如中国为CN
        $privilege   = $userinfo['privilege'];//用户特权信息，json 数组，如微信沃卡用户为
        $openids=$userinfo['openid'];
      	
        //exit;
        $qrcode=$_GET['state'];
        $u=Db::name('user')->where(['openid'=>$openids])->find();
        if ($u) {
            session('userid', $u['id']);
            $this->redirect('index/index', 302);
        } else {
          	
            $user=array();
            $user['group_id']=2;
            $user['username']=$userinfo['nickname'];
            $user['nickname']=$userinfo['nickname'];
            $user['password']=md5(17623);
            $user['salt']='123jn';
            $user['email']='123@13.com';
            $user['mobile']=1008611;
            $user['openid']=$userinfo['openid'];
            $user['avatar']=$userinfo['headimgurl'];
            $user['level']=0;
            $user['gender']=$userinfo['sex'];
            $user['birthday']=date('Y-m-d H:i:s');
            $user['bio']='niubi';
            $user['money']=0;
            $user['score']=0;
            $user['successions']=0;
            $user['maxsuccessions']=0;
            $user['prevtime']=time();
            $user['logintime']=time();
            $user['loginip']=$request->ip();
            $user['loginfailure']=0;
            $user['joinip']=$request->ip();
            $user['jointime']=time();
            $user['status']='normal';
            if ($qrcode) {
                $tguid=Db::name('user')->where('id', $qrcode)->find();
                if (!$tguid) {
                    exit('不存在上级');
                }
                $user['ss0']=$qrcode?:0;
                $user['ss1']=$tguid['ss0']?:0;
                $user['ss2']=$tguid['ss1']?:0;
                $user['ss3']=$tguid['ss2']?:0;
                $user['ss4']=$tguid['ss3']?:0;
                $user['ss5']=$tguid['ss4']?:0;
                $user['ss6']=$tguid['ss5']?:0;
                $user['ss7']=$tguid['ss6']?:0;
            }
            $user=Db::name('user')->insert($user);
            session('userid', $user['id']);
            $this->redirect('index/index', 302);
        }
    }
    public function login()
    {
        $url = $this->request->request('url');
        if ($this->auth->id) {
            $this->success(__('You\'ve logged in, do not login again'), $url ? $url : url('user/index'));
        }
        if ($this->request->isPost()) {
            $account = $this->request->post('account');
            $password = $this->request->post('password');
            $keeplogin = (int)$this->request->post('keeplogin');
            $token = $this->request->post('__token__');
            $rule = [
                'account'   => 'require|length:3,50',
                'password'  => 'require|length:6,30',
                '__token__' => 'token',
            ];

            $msg = [
                'account.require'  => 'Account can not be empty',
                'account.length'   => 'Account must be 3 to 50 characters',
                'password.require' => 'Password can not be empty',
                'password.length'  => 'Password must be 6 to 30 characters',
            ];
            $data = [
                'account'   => $account,
                'password'  => $password,
                '__token__' => $token,
            ];
            $validate = new Validate($rule, $msg);
            $result = $validate->check($data);
            if (!$result) {
                $this->error(__($validate->getError()), null, ['token' => $this->request->token()]);
                return false;
            }
            if ($this->auth->login($account, $password)) {
                $this->success(__('Logged in successful'), $url ? $url : url('user/index'));
            } else {
                $this->error($this->auth->getError(), null, ['token' => $this->request->token()]);
            }
        }
        //判断来源
        $referer = $this->request->server('HTTP_REFERER');
        if (!$url && (strtolower(parse_url($referer, PHP_URL_HOST)) == strtolower($this->request->host()))
            && !preg_match("/(user\/login|user\/register)/i", $referer)) {
            $url = $referer;
        }
        $this->view->assign('url', $url);
        $this->view->assign('title', __('Login'));
        return $this->view->fetch();
    }
    public function http_curl($url)
    {
        //用curl传参
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);

        //关闭ssl验证
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);


        curl_setopt($ch, CURLOPT_HEADER, 0);
        $output = curl_exec($ch);
        curl_close($ch);
        return json_decode($output, true);
    }
}
