<?php

namespace app\index\controller;


use app\common\controller\Frontend;
use think\Db;
use think\Request;


class Collection extends Frontend{

    private $userInfo = null;

    public function _initialize()
    {
        parent::_initialize();
        $this->userInfo = Db::name('user')->where('id', session('userid'))->find();
        if( ! $this->userInfo ) {
            $this->redirect('index/weixin/index');
            exit();
        }
    }

    public function index()
    {
        return $this->fetch('', array('model' => $this->userInfo));
    }

    public function lists(Request $request)
    {
        if( ! $request->isAjax() ){
            return $this->fetch('', array('model' => $this->userInfo));
        }

        $model = Db::name('collection')
            ->where('user_id', $this->userInfo['id'])
            ->paginate(10, null, array('query' => $request->param()));


        $statusMap = ['提现申请，处理中', '提现成功', '提现失败'];

        foreach($model as $index => &$item) {
            $status = $item['status'];
            $item['status_text'] = isset($statusMap[$status]) ? $statusMap[$status] : '';
        }


        return $this->result($model);
    }

    public function submit(Request $request)
    {
        $money = floatval($request->param("money", 0));
        if( ! $money ) {
            $this->error("请输入提现金额!");
        }

        if( floatval($money) < 20 ) {
            $this->error("填金额最低为 20 元!");
        }

        $cover_url = $request->param("cover_url", false);
        if( ! $cover_url ) {
            $this->error("请上传收款二维码!");
        }

        if(floatval($this->userInfo['money']) < $money) {
            $this->error("提现余额不足!");
        }

        $user_id = $this->userInfo['id'];
        $model = Db::name('collection');
        if($model->insert(array(
            'user_id' => $user_id,
            'trade_no' => "T" . date("YmdHis") . rand(10000, 99999),
            'money' => $money,
            'cover_url' => $cover_url,
            'create_time' => date("Y-m-d H:i:s"),
            'update_time' => date("Y-m-d H:i:s"),
        )) === false) {
            $this->error("提现申请失败!");
        }

      	
        Db::name('user')->where('id', $user_id)->setDec('money', $money);
        $this->success("提现申请成功!");
    }

}