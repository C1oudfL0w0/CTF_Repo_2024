<?php

return array (
  'name' => '葡京百家楽',
  'beian' => '',
  'cdnurl' => '',
  'version' => '1.0.2',
  'timezone' => 'Asia/Shanghai',
  'forbiddenip' => '',
  'fixedpage' => 'dashboard',
  'categorytype' => 
  array (
    'default' => 'Default',
    'page' => 'Page',
    'article' => 'Article',
    'test' => 'Test',
  ),
  'configgroup' => 
  array (
    'basic' => 'Basic',
    'email' => 'Email',
    'dictionary' => 'Dictionary',
    'user' => 'User',
    'example' => 'Example',
  ),
  'mail_type' => '1',
  'mail_smtp_host' => 'smtp.qq.com',
  'mail_smtp_port' => '465',
  'mail_smtp_user' => '10000',
  'mail_smtp_pass' => 'password',
  'mail_verify_type' => '2',
  'mail_from' => '10000@qq.com',
  'fengkong' => '0',
  'yj0' => '8',
  'yj1' => '5',
  'yj2' => '3',
  'yj3' => '2',
  'yj4' => '1',
  'yj5' => '1',
  'yj6' => '0.5',
  'yj7' => '0.5',
  'kefus' => '/uploads/20190503/6c097e90146eb8eedeb6cae8e2f6a29b.jpeg',
  'tixianmax' => '200',
  'tixianmin' => '2',
  'tixianoff' => '1',
  'jfid' => '1691',
  'jfkey' => 'nfc9macz82',
  'gonggao' => '        <p class="line">★葡京百家楽，微信版重磅上线★</p>
         <p class="line">★面向全网火热招代理★</p>
         <p class="line">★1秒成为代理，3天日收破千★</p>
         <p class="line">★福利多多，以小博大，官方直营★</p>
         <p class="line">★充值提现秒到，无人工审核★</p>
         <p class="line">★请保存游戏二维码，以免入口丢失★</p>
         <p class="line">———————————————</p>
         <p class="line">代理福利</p>
         <p class="line">每日收益50元以上，次日线上领取工资</p>
<p class="line">每天佣金50以上工资群488现金</p>
         <p class="line">———————————————</p>
         <p class="line"></p>',
  'pai' => '174',
  'tgimg' => '/uploads/20190507/0f2f1ee8c20f2ee798f54e1828adc955.png',
  'qrsize' => '10',
  'qrleft' => '100',
  'qrtop' => '100',
  'wxappid' => 'wx8c26971c7e05c169',
  'wxkey' => 'c738163b4fe2760d8afe14c173d9f5ff',
  'tgurl' => 'cs.3eym.com',
  'gameurl' => 'cs.3eym.com',
);