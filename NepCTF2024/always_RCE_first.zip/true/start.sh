#!/bin/bash

# 删除启动脚本
rm /start.sh

# 将 GZCTF_FLAG 写入 /flag 文件
echo "$GZCTF_FLAG" > /flag

# 设置 GZCTF_FLAG 环境变量为 not_flag
export GZCTF_FLAG=not_flag

# 执行 /cnb/process/web
/cnb/process/web