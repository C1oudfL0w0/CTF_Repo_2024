require("@nomicfoundation/hardhat-toolbox");

/** @type import('hardhat/config').HardhatUserConfig */
module.exports = {
  solidity: "0.8.26",
  networks: {
    hardhat: {
      accounts: [
        {
          privateKey: "",
          balance: "20000000000000000000000"  
        },
        {
          privateKey: "0x4b609fde92771ee750dac4d0aace6c9cf34e341229dbda382e49c492ad206e5e",//attacker
          balance: "10000000000000000000"  
        },
        {
          privateKey: "",
          balance: "10000000000000000000000" 
        }
      ]
},
    localhost: {
      url: "http://127.0.0.1:8545",
      // 本地网络通常不需要配置账户
    },
  },
  defaultNetwork: "localhost",
};
