import subprocess
import time
import re
from web3 import Web3
from solcx import compile_source, install_solc
import os
# 安装特定版本的solc
install_solc('0.8.26')

# 启动Hardhat节点并将输出重定向到文件
with open("hardhat_node_output.txt", "w") as outfile:
    node_process = subprocess.Popen(
        ["npx", "hardhat", "node", "--hostname", "0.0.0.0"],
        stdout=outfile,
        stderr=subprocess.PIPE,
        text=True
    )

time.sleep(30)  # 等待节点启动

# 读取节点输出以获取账户信息
with open("hardhat_node_output.txt", "r") as infile:
    output = infile.read()

# 解析Hardhat节点的输出以获取账户信息
accounts = re.findall(r'0x[a-fA-F0-9]{40}', output)

if len(accounts) < 2:
    node_process.kill()
    raise Exception("无法获取足够的账户信息")

deployer_account_address = accounts[0]
attacker_account_address = accounts[1]

# 使用默认私钥初始化Web3实例
w3 = Web3(Web3.HTTPProvider('http://127.0.0.1:8545'))

# 确保连接成功
if not w3.is_connected():
    node_process.kill()
    raise Exception("无法连接到以太坊节点")

# 设置部署者和攻击者账户的私钥
deployer_private_key = ""
attacker_private_key = ""

deployer_account = {
    "address": deployer_account_address,
    "private_key": deployer_private_key
}

attacker_account = {
    "address": attacker_account_address,
    "private_key": attacker_private_key
}

# Solidity合约代码
solidity_code = '''
// SPDX-License-Identifier: MIT
pragma solidity ^0.8.0;

contract Bank {
    mapping(address => uint256) public balanceOf;
    string private flag;
    uint256 public flagPrice = 50 ether;

    // 事件日志
    event Deposit(address indexed user, uint256 amount);
    event Withdraw(address indexed user, uint256 amount);
    event TransferFailed(address indexed user, uint256 amount);
    event FlagPurchased(address indexed buyer, string flag);

    constructor(string memory _flag) {
        flag = _flag;
    }

    // 存入ether，并更新余额
    function deposit() external payable {
        balanceOf[msg.sender] += msg.value;
        emit Deposit(msg.sender, msg.value);
    }

     // 提取msg.sender的全部ether
    function withdraw() external {
        uint256 balance = balanceOf[msg.sender]; // 获取余额
        require(balance > 0, "Insufficient balance");
        (bool success, ) = msg.sender.call{value: balance}("");
        require(success, "Failed to send Ether");
        // 更新余额
        balanceOf[msg.sender] = 0;
    }


    // 获取银行合约的余额
    function getBalance() external view returns (uint256) {
        return address(this).balance;
    }

    // 获取flag
    function getFlag() external view returns (string memory) {
        require(balanceOf[msg.sender] >= flagPrice, "Insufficient balance to get flag");
        return flag;
    }
}

'''

# 编译Solidity合约
compiled_sol = compile_source(solidity_code)

# 从编译后的内容中获取正确的键值
contract_id, contract_interface = compiled_sol.popitem()
# 创建合约对象
Bank = w3.eth.contract(abi=contract_interface['abi'], bytecode=contract_interface['bin'])

# 构造交易
nonce = w3.eth.get_transaction_count(deployer_account["address"])

T=0
def get_flag():
    while T<200:
        flag = os.getenv('GZCTF_FLAG')
        if flag is not None:
            return flag
        print("Environment variable 'GZCTF_FLAG' is not set. Waiting for 1 minute...")
        time.sleep(1)  # Wait for 1 minute

# Retrieve the flag
flag = get_flag()

# Create the transaction using the flag from the environment variable
transaction = Bank.constructor(flag).build_transaction({
    'chainId': 31337,
    'gas': 2000000,
    'gasPrice': w3.to_wei('50', 'gwei'),
    'nonce': nonce,
})
# 签署交易
signed_txn = w3.eth.account.sign_transaction(transaction, private_key=deployer_account["private_key"])

# 发送交易
tx_hash = w3.eth.send_raw_transaction(signed_txn.rawTransaction)

# 获取交易回执
tx_receipt = w3.eth.wait_for_transaction_receipt(tx_hash)

# 输出合约地址和ABI
bank_contract_address = tx_receipt.contractAddress
print(f'Bank合约部署成功，地址为: {bank_contract_address}')
print(f'Bank合约ABI: {contract_interface["abi"]}')
time.sleep(2)
subprocess.Popen(["python3", "2.py"])

import socket

def start_tcp_server(host, port, message):
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.bind((host, port))
        s.listen()
        print(f"Listening on {host}:{port}")
        while True:
            conn, addr = s.accept()
            with conn:
                print(f"Connected by {addr}")
                conn.sendall(message.encode())


message = f"Bank合约部署成功，地址与测试账号私钥为: {bank_contract_address} {attacker_account['private_key']}\n"
start_tcp_server('0.0.0.0', 65432, message)
