-- Adminer 4.8.1 MySQL 8.0.36-0ubuntu0.22.04.1 dump

SET NAMES utf8;
SET time_zone = '+00:00';
SET foreign_key_checks = 0;
SET sql_mode = 'NO_AUTO_VALUE_ON_ZERO';

SET NAMES utf8mb4;

CREATE DATABASE `data` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `data`;

DROP TABLE IF EXISTS `license`;
CREATE TABLE `license` (
  `id` int NOT NULL,
  `name` varchar(99) NOT NULL,
  `license` bigint NOT NULL,
  `public_key` bigint NOT NULL,
  `private_key` bigint NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO `license` (`id`, `name`, `license`, `public_key`, `private_key`) VALUES
(13,	'数据安全理论',	55313236,	943,	943),
(67,	'数字中国运维课',	19257524,	568,	568),
(93,	'隐私计算导论',	17483920,	130,	130),
(114,	'渗透攻防技术',	25474935,	195,	195),
(232,	'线性代数',	41103426,	674,	674);

DROP TABLE IF EXISTS `scores`;
CREATE TABLE `scores` (
  `id` int NOT NULL,
  `name` varchar(255) NOT NULL,
  `score` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO `scores` (`id`, `name`, `score`) VALUES
(1,	'学生1',	85),
(2,	'学生2',	75),
(3,	'学生3',	65),
(4,	'学生4',	95),
(5,	'学生5',	91);

DROP TABLE IF EXISTS `user_login`;
CREATE TABLE `user_login` (
  `id` int NOT NULL,
  `username` varchar(99) NOT NULL,
  `password` varchar(99) NOT NULL,
  `commitment` varchar(99) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `r` varchar(99) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO `user_login` (`id`, `username`, `password`, `commitment`, `r`) VALUES
(1,	'user1',	'e9ac35ef51e56e5bd1ac27f2ad41d8b2',	'19188',	'9453');

-- 2024-05-20 13:38:54
