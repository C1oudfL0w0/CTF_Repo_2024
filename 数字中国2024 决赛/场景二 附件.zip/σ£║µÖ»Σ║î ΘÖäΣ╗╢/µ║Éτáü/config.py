db_config = {
    'user': 'root',
    'password': 'sql2024',
    'host': 'localhost',
    'port': 3306,  # 默认是3306，如果不同请修改
    'database': ''
}
