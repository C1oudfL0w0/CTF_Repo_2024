from flask import Flask
from views.zkp import zkp_bp
from views.ot import ot_bp
from views.he import he_bp

app = Flask(__name__)

app.register_blueprint(zkp_bp, url_prefix='/001/zkp')
app.register_blueprint(ot_bp, url_prefix='/002/ot')
app.register_blueprint(he_bp, url_prefix='/003/he')

@app.route('/')
def index():
    return "Service started successfully."

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=8080, debug=True)
