from flask import Blueprint, request, jsonify
from db import get_db_connection
import hashlib

zkp_bp = Blueprint('zkp', __name__)



@zkp_bp.route('/')
def zkp():
    #数据库连接验证测试
    connection = get_db_connection()
    connection.close()
    return "zkp Service started successfully."


@zkp_bp.route('/login', methods=['POST'])
def login():
    data = request.get_json()
    username = data.get('username')
    password = data.get('password')

    if not username or not password:
        return jsonify({"login_success": False}), 400

    hashed_password = hashlib.md5(password.encode()).hexdigest()

    connection = get_db_connection()
    cursor = connection.cursor(dictionary=True)

    cursor.execute("SELECT * FROM user_login WHERE username = %s AND password = %s", (username, hashed_password))
    user = cursor.fetchone()

    cursor.close()
    connection.close()

    if user:
        return jsonify({"login_success": True})
    else:
        return jsonify({"login_success": False})


@zkp_bp.route('/login_zkp')
def login_zkp():
    password = "C8e#1d$2"
    commitment_reg = 19188
    r = 9453
    '''
    请根据提供的算法以及json开发格式规范，实现该接口的功能
    直接在当前函数里开发
    '''
    return "待开发"

@zkp_bp.route('/commitment')
def commitment():
    '''
    请根据提供的算法以及json开发格式规范，实现该接口的功能
    直接在当前函数里开发
    '''
    return "待开发"



def simple_hash(message):
    return sum(ord(char) for char in message) % 100