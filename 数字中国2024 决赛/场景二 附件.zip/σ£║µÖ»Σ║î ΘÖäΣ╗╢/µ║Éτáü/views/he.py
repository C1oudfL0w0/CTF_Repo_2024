
from flask import Blueprint
from flask import Flask, request, jsonify
from db import get_db_connection


he_bp = Blueprint('he', __name__)

@he_bp.route('/')
def he():
    return "he Service started successfully."

@he_bp.route('/get_score', methods=['POST'])
def get_score():
    data = request.get_json()
    student_id = data.get('id')

    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT id, name, score FROM scores WHERE id = %s", (student_id,))
    data = cursor.fetchone()
    conn.close()

    if data:
        response = {'id': data[0], 'name': data[1], 'score': data[2]}
    else:
        response = {'error': 'Student not found'}
    return jsonify(response)


@he_bp.route('/get_score_sum', methods=['POST'])
def get_score_sum():
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT SUM(score) FROM scores")
    sum_score = cursor.fetchone()[0]
    conn.close()
    response = {'sum': int(sum_score)}
    return jsonify(response)


@he_bp.route('/get_score_he')
def get_score_he():
    '''
    请根据提供的算法以及json开发格式规范，实现该接口的功能
    直接在当前函数里开发
    '''
    return "待开发"

@he_bp.route('/get_score_sum_he')
def get_score_sum_he():
    '''
    请根据提供的算法以及json开发格式规范，实现该接口的功能
    直接在当前函数里开发
    '''
    return "待开发"