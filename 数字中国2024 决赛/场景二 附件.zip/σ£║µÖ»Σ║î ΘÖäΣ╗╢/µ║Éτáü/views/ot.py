from flask import Blueprint, request, jsonify
from db import get_db_connection
import random

ot_bp = Blueprint('ot', __name__)

@ot_bp.route('/')
def ot():
    return "Oblivious Transfer endpoint."

@ot_bp.route('/get_license', methods=['GET'])

def get_license():
    connection = get_db_connection()
    cursor = connection.cursor()
    cursor.execute("SELECT id, name, license FROM license")
    data = cursor.fetchall()
    connection.close()
    response = [{'id': row[0], 'name': row[1], 'license': row[2]} for row in data]
    return jsonify(response)


@ot_bp.route('/get_pubkey')
def get_pubkey():
    '''
    请根据提供的算法以及json开发格式规范，实现该接口的功能
    直接在当前函数里开发
    '''
    return "待开发"


@ot_bp.route('/get_ot_license')
def get_ot_license():
    '''
    请根据提供的算法以及json开发格式规范，实现该接口的功能
    直接在当前函数里开发
    '''
    return "待开发"
