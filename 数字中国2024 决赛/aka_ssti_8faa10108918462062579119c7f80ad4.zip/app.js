var express = require('express');
var app = express();

var mongoose =require('mongoose');
var path = require('path');
var bodyParser = require('body-parser');
var fs = require('fs');
var lodash = require('lodash');
var session = require('express-session');
var randomize = require('randomatic');

app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'ejs');
app.use(express.static(path.join(__dirname, 'static'))); 

app.get('/', (req, res, next) => {
    res.redirect('/home?page=Home');
});

app.all('/home', function(req, res) {
    res.render('home', req.query);
});

app.all('/about', function(req, res) {
    res.render('about', req.query);
});

// catch 404 and forward to error handler
app.use(function(req, res, next) {
  var err = new Error('Not Found');
  err.status = 404;
  next(err);
});

// error handler
app.use(function(err, req, res, next) {
  // render the error page
  res.status(err.status || 500);
  res.render('error', {status:err.status, message:err.message});
});

var server = app.listen(80, '0.0.0.0', function () {

    var host = server.address().address;
    var port = server.address().port;

    console.log("listening on http://%s:%s", host, port);
});